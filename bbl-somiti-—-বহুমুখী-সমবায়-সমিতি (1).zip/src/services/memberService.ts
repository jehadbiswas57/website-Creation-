import {
  MemberRecord,
  MemberLoan,
  PaymentRequest,
  ProfileUpdateRequest,
  OfficialReceipt,
  PaymentMethod,
} from '../types/member';
import { TransactionRecord } from '../types/dashboard';
import { calculateLoan } from './loanCalculator';

// Storage keys
const STORAGE_MEMBERS = 'bbl_somiti_members_v1';
const STORAGE_LOANS = 'bbl_somiti_loans_v1';
const STORAGE_PAYMENT_REQUESTS = 'bbl_somiti_payment_requests_v1';
const STORAGE_PROFILE_REQUESTS = 'bbl_somiti_profile_requests_v1';
const STORAGE_RECEIPTS = 'bbl_somiti_receipts_v1';
const STORAGE_AUDIT_LOGS = 'bbl_somiti_member_audits_v1';

export interface MemberAuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  targetId: string;
  details: string;
}

/**
 * SHA-256 Secure Password Hash
 * Plaintext passwords are never stored or logged.
 */
export async function hashPassword(plainText: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(plainText + '_bbl_somiti_salt_secure_2026');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Memory cache with localStorage sync
class MemberRepository {
  private members: MemberRecord[] = [];
  private loans: MemberLoan[] = [];
  private paymentRequests: PaymentRequest[] = [];
  private profileRequests: ProfileUpdateRequest[] = [];
  private receipts: OfficialReceipt[] = [];
  private auditLogs: MemberAuditLog[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const m = localStorage.getItem(STORAGE_MEMBERS);
      this.members = m ? JSON.parse(m) : [];

      const l = localStorage.getItem(STORAGE_LOANS);
      this.loans = l ? JSON.parse(l) : [];

      const p = localStorage.getItem(STORAGE_PAYMENT_REQUESTS);
      this.paymentRequests = p ? JSON.parse(p) : [];

      const pr = localStorage.getItem(STORAGE_PROFILE_REQUESTS);
      this.profileRequests = pr ? JSON.parse(pr) : [];

      const r = localStorage.getItem(STORAGE_RECEIPTS);
      this.receipts = r ? JSON.parse(r) : [];

      const a = localStorage.getItem(STORAGE_AUDIT_LOGS);
      this.auditLogs = a ? JSON.parse(a) : [];
    } catch {
      this.members = [];
      this.loans = [];
      this.paymentRequests = [];
      this.profileRequests = [];
      this.receipts = [];
      this.auditLogs = [];
    }

    // Auto-heal and sync existing member accounts with active 0.5% insurance settings
    this.syncAllMembersFeeSettings();
  }

  public getSettingRates(): {
    insuranceRatePercent: number;
    admissionFeeDefault: number;
    initialSavingsRatePercent: number;
  } {
    try {
      const raw = localStorage.getItem('bbl_branding_settings');
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          insuranceRatePercent: typeof parsed.insuranceRatePercent === 'number' ? parsed.insuranceRatePercent : 0.5,
          admissionFeeDefault: typeof parsed.admissionFeeDefault === 'number' ? parsed.admissionFeeDefault : 100,
          initialSavingsRatePercent: typeof parsed.initialSavingsRatePercent === 'number' ? parsed.initialSavingsRatePercent : 5.0,
        };
      }
    } catch {}
    return {
      insuranceRatePercent: 0.5,
      admissionFeeDefault: 100,
      initialSavingsRatePercent: 5.0,
    };
  }

  public syncAllMembersFeeSettings(settings?: {
    admissionFeeDefault?: number;
    insuranceRatePercent?: number;
    initialSavingsRatePercent?: number;
  }) {
    const effective = settings || this.getSettingRates();
    const insuranceRate = effective.insuranceRatePercent ?? 0.5;
    let changed = false;

    this.members.forEach((m) => {
      const loanAmount =
        m.requestedInitialLoanAmount ||
        (m.activeLoanId ? this.loans.find((l) => l.id === m.activeLoanId)?.approvedAmount : 50000) ||
        50000;
      
      const expectedInsurance = Math.round(loanAmount * (insuranceRate / 100));

      // Correct outdated insurance fee required (e.g. old 750 or 500 when 0.5% on 50,000 should be 250)
      if (m.insuranceFeeRequired !== expectedInsurance && !m.insuranceFeeWaived) {
        m.insuranceFeeRequired = expectedInsurance;
        changed = true;
      }

      // Sync status
      if (m.insuranceFeePaid >= m.insuranceFeeRequired) {
        if (m.insuranceStatus !== 'PAID') {
          m.insuranceStatus = 'PAID';
          changed = true;
        }
      } else if (m.insuranceStatus === 'PAID' && m.insuranceFeePaid < m.insuranceFeeRequired) {
        m.insuranceStatus = 'DUE';
        changed = true;
      }

      if (m.admissionFeePaid >= m.admissionFeeRequired) {
        if (m.admissionFeeStatus !== 'PAID') {
          m.admissionFeeStatus = 'PAID';
          changed = true;
        }
      }

      if (m.initialSavingsPaid >= m.initialSavingsRequired) {
        if (m.initialSavingsStatus !== 'PAID') {
          m.initialSavingsStatus = 'PAID';
          changed = true;
        }
      }
    });

    if (changed) {
      this.saveMembers();
    }
  }

  private saveMembers() {
    try {
      localStorage.setItem(STORAGE_MEMBERS, JSON.stringify(this.members));
    } catch {}
  }

  private saveLoans() {
    try {
      localStorage.setItem(STORAGE_LOANS, JSON.stringify(this.loans));
    } catch {}
  }

  private savePaymentRequests() {
    try {
      localStorage.setItem(STORAGE_PAYMENT_REQUESTS, JSON.stringify(this.paymentRequests));
    } catch {}
  }

  private saveProfileRequests() {
    try {
      localStorage.setItem(STORAGE_PROFILE_REQUESTS, JSON.stringify(this.profileRequests));
    } catch {}
  }

  private saveReceipts() {
    try {
      localStorage.setItem(STORAGE_RECEIPTS, JSON.stringify(this.receipts));
    } catch {}
  }

  private saveAuditLogs() {
    try {
      localStorage.setItem(STORAGE_AUDIT_LOGS, JSON.stringify(this.auditLogs));
    } catch {}
  }

  public logAudit(actor: string, action: string, targetId: string, details: string) {
    const entry: MemberAuditLog = {
      id: `AUD-${Date.now()}-${Math.floor(Math.random() * 899 + 100)}`,
      timestamp: new Date().toLocaleString('bn-BD', { hour12: true }),
      actor,
      action,
      targetId,
      details,
    };
    this.auditLogs.unshift(entry);
    this.saveAuditLogs();
  }

  public getAuditLogs(): MemberAuditLog[] {
    return [...this.auditLogs];
  }

  // Member CRUD
  public getAllMembers(): MemberRecord[] {
    return [...this.members];
  }

  public getMemberById(id: string): MemberRecord | undefined {
    return this.members.find((m) => m.id === id);
  }

  public getMemberByUserId(userId: string): MemberRecord | undefined {
    return this.members.find((m) => m.userId?.toLowerCase() === userId.toLowerCase());
  }

  public createMember(memberData: Omit<MemberRecord, 'id' | 'createdAt' | 'updatedAt'>, actor: string): MemberRecord {
    // Generate next unique Member ID
    const count = this.members.length + 1;
    const id = `BBL-${String(count).padStart(3, '0')}`;

    const newMember: MemberRecord = {
      ...memberData,
      id,
      totalLoansTakenCount: 0,
      totalLoanDisbursedAmount: 0,
      totalLoanPrincipalPaid: 0,
      totalLoanProfitPaid: 0,
      currentLoanOutstanding: 0,
      totalSavingsDeposits: 0,
      totalSavingsWithdrawals: 0,
      currentSavingsBalance: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.members.unshift(newMember);
    this.saveMembers();

    this.logAudit(actor, 'সদস্য অন্তর্ভুক্তি', id, `${newMember.fullNameBn} (${id}) নতুন সদস্য হিসেবে নিবন্ধিত`);
    return newMember;
  }

  public updateMember(id: string, updates: Partial<MemberRecord>, actor: string): MemberRecord | null {
    const idx = this.members.findIndex((m) => m.id === id);
    if (idx === -1) return null;

    const existing = this.members[idx];
    const updated: MemberRecord = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    this.members[idx] = updated;
    this.saveMembers();

    this.logAudit(actor, 'সদস্য তথ্য আপডেট', id, `${updated.fullNameBn}-এর প্রোফাইল তথ্য পরিবর্তন করা হয়েছে`);
    return updated;
  }

  // Member Deletion, Deactivation, and Archiving with Financial Integrity
  public deleteMember(
    id: string,
    actor: string
  ): { success: boolean; canDelete: boolean; message: string; blockedReason?: string } {
    const member = this.getMemberById(id);
    if (!member) {
      return { success: false, canDelete: false, message: 'সদস্য পাওয়া যায়নি।' };
    }

    // Financial Safety Integrity Check:
    const activeLoans = this.loans.filter((l) => l.memberId === id && (l.loanStatus === 'ACTIVE' || l.loanStatus === 'OVERDUE'));
    const allLoans = this.loans.filter((l) => l.memberId === id);
    const hasOutstandingLoan = member.currentLoanOutstanding > 0 || activeLoans.length > 0;
    const hasSavingsBalance = member.currentSavingsBalance > 0 || member.totalSavingsDeposits > 0;
    const hasReceipts = this.receipts.some((r) => r.memberId === id);
    const hasPaymentRequests = this.paymentRequests.some((p) => p.memberId === id);

    if (hasOutstandingLoan || hasSavingsBalance || hasReceipts || allLoans.length > 0 || hasPaymentRequests) {
      const reasons: string[] = [];
      if (hasOutstandingLoan) reasons.push(`চলমান বকেয়া ঋণ (৳ ${member.currentLoanOutstanding})`);
      if (hasSavingsBalance) reasons.push(`সঞ্চয় হিসাব স্থিতি (৳ ${member.currentSavingsBalance})`);
      if (hasReceipts || hasPaymentRequests) reasons.push('লেজারে অনুমোদিত আর্থিক লেনদেন বা রশিদ');

      return {
        success: false,
        canDelete: false,
        message: 'আর্থিক নিরাপত্তা বিধিমালার কারণে এই সদস্যকে সরাসরি মুছে ফেলা যাবে না।',
        blockedReason: `কারণ: সদস্যের নামে ${reasons.join(', ')} বিদ্যমান। অডিট ট্রেইল ও লেজার ব্যালেন্স অক্ষত রাখতে সদস্যকে 'নিষ্ক্রিয় (Deactivate)' বা 'আর্কাইভ (Archive)' করুন।`,
      };
    }

    // Clean member with zero financial records can be safely deleted
    this.members = this.members.filter((m) => m.id !== id);
    this.saveMembers();

    this.logAudit(actor, 'সদস্য রেকর্ড ডিলিট', id, `${member.fullNameBn} (${id})-এর প্রাথমিক রেকর্ড সিস্টেম থেকে মুছে ফেলা হয়েছে`);

    return {
      success: true,
      canDelete: true,
      message: `${member.fullNameBn} (${id})-এর রেকর্ড সফলভাবে মুছে ফেলা হয়েছে।`,
    };
  }

  public deactivateMember(id: string, actor: string, reason?: string): { success: boolean; message: string } {
    const member = this.getMemberById(id);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };
    member.status = 'INACTIVE';
    if (member.hasLoginAccount) member.loginStatus = 'INACTIVE';
    member.updatedAt = new Date().toISOString();
    this.saveMembers();
    this.logAudit(actor, 'সদস্য নিষ্ক্রিয়করণ', id, `সদস্য নিষ্ক্রিয় করা হয়েছে। কারণ: ${reason || 'প্রশাসনিক নির্দেশ'}`);
    return { success: true, message: 'সদস্য সফলভাবে নিষ্ক্রিয় করা হয়েছে।' };
  }

  public archiveMember(id: string, actor: string): { success: boolean; message: string } {
    const member = this.getMemberById(id);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };
    member.status = 'ARCHIVED';
    member.updatedAt = new Date().toISOString();
    this.saveMembers();
    this.logAudit(actor, 'সদস্য আর্কাইভ', id, 'সদস্যকে সক্রিয় তালিকা থেকে আর্কাইভে স্থানান্তর করা হয়েছে');
    return { success: true, message: 'সদস্যকে সফলভাবে আর্কাইভে স্থানান্তর করা হয়েছে।' };
  }

  public reactivateMember(id: string, actor: string): { success: boolean; message: string } {
    const member = this.getMemberById(id);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };
    member.status = 'ACTIVE';
    if (member.hasLoginAccount) member.loginStatus = 'ACTIVE';
    member.updatedAt = new Date().toISOString();
    this.saveMembers();
    this.logAudit(actor, 'সদস্য পুনরায় সক্রিয়করণ', id, 'সদস্য সক্রিয় তালিকায় পুনরুদ্ধার করা হয়েছে');
    return { success: true, message: 'সদস্য সফলভাবে পুনরায় সক্রিয় করা হয়েছে।' };
  }

  public waiveFeeRequirement(
    id: string,
    feeType: 'ADMISSION' | 'INSURANCE' | 'INITIAL_SAVINGS',
    actor: string,
    reason: string
  ): { success: boolean; message: string } {
    const member = this.getMemberById(id);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };
    if (feeType === 'ADMISSION') {
      member.admissionFeeWaived = true;
      member.admissionFeeStatus = 'WAIVED';
    } else if (feeType === 'INSURANCE') {
      member.insuranceFeeWaived = true;
      member.insuranceStatus = 'WAIVED';
    } else if (feeType === 'INITIAL_SAVINGS') {
      member.initialSavingsWaived = true;
      member.initialSavingsStatus = 'WAIVED';
    }
    member.updatedAt = new Date().toISOString();
    this.saveMembers();
    this.logAudit(actor, 'ফি মওকুফ অনুমোদন', id, `${feeType} ফি মওকুফ করা হয়েছে। কারণ: ${reason}`);
    return { success: true, message: 'শর্ত সফলভাবে মওকুফ করা হয়েছে।' };
  }

  public calculateInitialFees(
    requestedLoanAmount: number,
    settings?: { admissionFeeDefault?: number; insuranceRatePercent?: number; initialSavingsRatePercent?: number }
  ) {
    const admissionFee = settings?.admissionFeeDefault ?? 100;
    const insuranceRate = settings?.insuranceRatePercent ?? 0.5;
    const initialSavingsRate = settings?.initialSavingsRatePercent ?? 5.0;

    const insuranceFee = requestedLoanAmount > 0 ? Math.round(requestedLoanAmount * (insuranceRate / 100)) : 100;
    const initialSavings = requestedLoanAmount > 0 ? Math.round(requestedLoanAmount * (initialSavingsRate / 100)) : 500;
    const totalRequired = admissionFee + insuranceFee + initialSavings;

    return {
      requestedLoanAmount,
      admissionFee,
      insuranceFee,
      initialSavings,
      totalRequired,
      insuranceRate,
      initialSavingsRate,
    };
  }

  // Account creation & password management
  public async createMemberLoginAccount(
    memberId: string,
    userId: string,
    plainPassword: string,
    actor: string
  ): Promise<{ success: boolean; message: string }> {
    const member = this.getMemberById(memberId);
    if (!member) {
      return { success: false, message: 'সদস্য পাওয়া যায়নি।' };
    }

    const cleanUserId = userId.trim().toLowerCase();
    if (!cleanUserId || cleanUserId.length < 3) {
      return { success: false, message: 'ইউজার আইডি অন্তত ৩ অক্ষরের হতে হবে।' };
    }

    // Check unique userId across existing accounts
    const existing = this.members.find(
      (m) => m.id !== memberId && m.userId?.toLowerCase() === cleanUserId
    );
    if (existing) {
      return { success: false, message: 'এই ইউজার আইডিটি ইতিমধ্যে অন্য সদস্যের জন্য ব্যবহৃত।' };
    }

    // Eligibility check for account creation (admission fee paid & approved)
    if (member.admissionFeeStatus !== 'PAID') {
      return { success: false, message: 'লগইন একাউন্ট তৈরির পূর্বে ভর্তি ফি পরিশোধ নিশ্চিত করতে হবে।' };
    }

    const passwordHash = await hashPassword(plainPassword);

    member.userId = cleanUserId;
    member.hasLoginAccount = true;
    member.loginStatus = 'ACTIVE';
    member.passwordHash = passwordHash;
    member.forcePasswordChange = true;
    member.updatedAt = new Date().toISOString();

    this.saveMembers();
    this.logAudit(actor, 'লগইন একাউন্ট সৃষ্টি', memberId, `ইউজার আইডি ${cleanUserId} সফলভাবে সক্রিয় করা হয়েছে`);

    return { success: true, message: 'সদস্যের লগইন একাউন্ট সফলভাবে সক্রিয় করা হয়েছে।' };
  }

  public async resetMemberPassword(
    memberId: string,
    newPlainPassword: string,
    actor: string
  ): Promise<{ success: boolean; message: string }> {
    const member = this.getMemberById(memberId);
    if (!member || !member.hasLoginAccount) {
      return { success: false, message: 'লগইন একাউন্ট পাওয়া যায়নি।' };
    }

    const passwordHash = await hashPassword(newPlainPassword);
    member.passwordHash = passwordHash;
    member.forcePasswordChange = true;
    member.loginStatus = 'ACTIVE';
    member.updatedAt = new Date().toISOString();

    this.saveMembers();
    this.logAudit(actor, 'পাসওয়ার্ড রিসেট', memberId, `ইউজার আইডি ${member.userId}-এর পাসওয়ার্ড রিসেট করা হয়েছে`);

    return { success: true, message: 'সদস্যের পাসওয়ার্ড সফলভাবে রিসেট করা হয়েছে।' };
  }

  public async verifyMemberLogin(
    userId: string,
    plainPassword: string
  ): Promise<{ success: boolean; member?: MemberRecord; message: string }> {
    const cleanUserId = userId.trim().toLowerCase();
    const member = this.getMemberByUserId(cleanUserId);

    if (!member || !member.hasLoginAccount || !member.passwordHash) {
      return { success: false, message: 'ইউজার আইডি বা পাসওয়ার্ড সঠিক নয়।' };
    }

    if (member.loginStatus === 'LOCKED' || member.loginStatus === 'INACTIVE') {
      return { success: false, message: 'আপনার একাউন্টটি বর্তমানে স্থগিত বা লক অবস্থায় আছে।' };
    }

    const inputHash = await hashPassword(plainPassword);
    if (inputHash !== member.passwordHash) {
      return { success: false, message: 'ইউজার আইডি বা পাসওয়ার্ড সঠিক নয়।' };
    }

    return { success: true, member, message: 'লগইন সফল হয়েছে।' };
  }

  // Loan Eligibility Check
  public updateMemberFeeAccounts(
    memberId: string,
    updates: {
      admissionFeeRequired?: number;
      admissionFeePaid?: number;
      insuranceFeeRequired?: number;
      insuranceFeePaid?: number;
      initialSavingsRequired?: number;
      initialSavingsPaid?: number;
    },
    actor: string
  ): { success: boolean; message: string } {
    const member = this.getMemberById(memberId);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };

    if (typeof updates.admissionFeeRequired === 'number') {
      member.admissionFeeRequired = Math.max(0, updates.admissionFeeRequired);
    }
    if (typeof updates.admissionFeePaid === 'number') {
      member.admissionFeePaid = Math.max(0, updates.admissionFeePaid);
    }
    member.admissionFeeStatus = member.admissionFeePaid >= member.admissionFeeRequired ? 'PAID' : 'DUE';

    if (typeof updates.insuranceFeeRequired === 'number') {
      member.insuranceFeeRequired = Math.max(0, updates.insuranceFeeRequired);
    }
    if (typeof updates.insuranceFeePaid === 'number') {
      member.insuranceFeePaid = Math.max(0, updates.insuranceFeePaid);
    }
    member.insuranceStatus = member.insuranceFeePaid >= member.insuranceFeeRequired ? 'PAID' : 'DUE';

    if (typeof updates.initialSavingsRequired === 'number') {
      member.initialSavingsRequired = Math.max(0, updates.initialSavingsRequired);
    }
    if (typeof updates.initialSavingsPaid === 'number') {
      member.initialSavingsPaid = Math.max(0, updates.initialSavingsPaid);
    }
    member.initialSavingsStatus = member.initialSavingsPaid >= member.initialSavingsRequired ? 'PAID' : 'DUE';

    member.updatedAt = new Date().toISOString();
    this.saveMembers();

    this.logAudit(
      actor,
      'ফি ও আমানত হিসাব হালনাগাদ',
      memberId,
      `অনুমোদিত খাত সম্পাদনা: ভর্তি ফি ৳${member.admissionFeeRequired} (পরিশোধ ৳${member.admissionFeePaid}), ইনস্যুরেন্স ৳${member.insuranceFeeRequired} (পরিশোধ ৳${member.insuranceFeePaid}), সঞ্চয় ৳${member.initialSavingsRequired} (পরিশোধ ৳${member.initialSavingsPaid})`
    );

    return { success: true, message: 'খাতসমূহের হিসাব সফলভাবে হালনাগাদ করা হয়েছে।' };
  }

  public recalculateMemberInsuranceFee(memberId: string, customRate?: number): { success: boolean; newRequired: number } {
    const member = this.getMemberById(memberId);
    if (!member) return { success: false, newRequired: 0 };

    const rate = typeof customRate === 'number' ? customRate : this.getSettingRates().insuranceRatePercent;
    const loanAmount =
      member.requestedInitialLoanAmount ||
      (member.activeLoanId ? this.loans.find((l) => l.id === member.activeLoanId)?.approvedAmount : 50000) ||
      50000;

    const newRequired = Math.round(loanAmount * (rate / 100));
    member.insuranceFeeRequired = newRequired;
    if (member.insuranceFeePaid >= member.insuranceFeeRequired) {
      member.insuranceStatus = 'PAID';
    } else {
      member.insuranceStatus = 'DUE';
    }
    member.updatedAt = new Date().toISOString();
    this.saveMembers();

    return { success: true, newRequired };
  }

  public checkLoanEligibility(
    memberId: string,
    customSettings?: { admissionFeeDefault?: number; insuranceRatePercent?: number; initialSavingsRatePercent?: number }
  ): {
    isEligible: boolean;
    isLoanAccountComplete: boolean;
    admissionPaid: boolean;
    insurancePaid: boolean;
    initialSavingsPaid: boolean;
    missingReasons: string[];
    totalDueAmount: number;
  } {
    const member = this.getMemberById(memberId);
    if (!member) {
      return {
        isEligible: false,
        isLoanAccountComplete: false,
        admissionPaid: false,
        insurancePaid: false,
        initialSavingsPaid: false,
        missingReasons: ['সদস্য রেকর্ড পাওয়া যায়নি।'],
        totalDueAmount: 0,
      };
    }

    // Dynamic fee requirement check based on current setting (e.g. 0.5% on 50,000 = 250)
    const settings = customSettings || this.getSettingRates();
    const loanAmount =
      member.requestedInitialLoanAmount ||
      50000;
    const insRate = settings.insuranceRatePercent ?? 0.5;
    const currentCalculatedInsurance = Math.round(loanAmount * (insRate / 100));

    // Auto-sync outdated insurance fee required (e.g. old 750 or 500 instead of 250 for 50,000 at 0.5%)
    if (member.insuranceFeeRequired > currentCalculatedInsurance && !member.insuranceFeeWaived) {
      member.insuranceFeeRequired = currentCalculatedInsurance;
      if (member.insuranceFeePaid >= member.insuranceFeeRequired) {
        member.insuranceStatus = 'PAID';
      }
      this.saveMembers();
    }

    const missingReasons: string[] = [];
    let totalDue = 0;

    const admissionPaid =
      member.admissionFeeStatus === 'PAID' ||
      member.admissionFeeWaived === true ||
      member.admissionFeePaid >= member.admissionFeeRequired;
    if (!admissionPaid) {
      const due = Math.max(0, member.admissionFeeRequired - member.admissionFeePaid);
      if (due > 0) {
        totalDue += due;
        missingReasons.push(`ভর্তি ফি বকেয়া রয়েছে: ৳ ${due}`);
      }
    }

    const insurancePaid =
      member.insuranceStatus === 'PAID' ||
      member.insuranceFeeWaived === true ||
      member.insuranceFeePaid >= member.insuranceFeeRequired;
    if (!insurancePaid) {
      const due = Math.max(0, member.insuranceFeeRequired - member.insuranceFeePaid);
      if (due > 0) {
        totalDue += due;
        missingReasons.push(`ইনস্যুরেন্স ফান্ড জমা বকেয়া: ৳ ${due}`);
      }
    }

    const initialSavingsPaid =
      member.initialSavingsStatus === 'PAID' ||
      member.initialSavingsWaived === true ||
      member.initialSavingsPaid >= member.initialSavingsRequired;
    if (!initialSavingsPaid) {
      const due = Math.max(0, member.initialSavingsRequired - member.initialSavingsPaid);
      if (due > 0) {
        totalDue += due;
        missingReasons.push(`প্রাথমিক বাধ্যতামূলক সঞ্চয় বকেয়া: ৳ ${due}`);
      }
    }

    const isComplete = admissionPaid && insurancePaid && initialSavingsPaid;

    return {
      isEligible: isComplete,
      isLoanAccountComplete: isComplete,
      admissionPaid,
      insurancePaid,
      initialSavingsPaid,
      missingReasons,
      totalDueAmount: totalDue,
    };
  }

  // Loans
  public getAllLoans(): MemberLoan[] {
    return [...this.loans];
  }

  public getLoanById(id: string): MemberLoan | undefined {
    return this.loans.find((l) => l.id === id);
  }

  public getLoansByMemberId(memberId: string): MemberLoan[] {
    return this.loans.filter((l) => l.memberId === memberId);
  }

  public applyLoan(
    memberId: string,
    params:
      | {
          requestedAmount: number;
          tenureMonths?: number;
          installmentCount?: number;
          profitRatePercent?: number;
          calculationMethod?: 'FLAT' | 'REDUCING';
          firstInstallmentDate?: string;
          purpose: string;
          supportingDocuments?: string[];
        }
      | number,
    legacyTenureMonths?: number,
    legacyPurpose?: string,
    legacyDocs?: string[]
  ): { success: boolean; loan?: MemberLoan; message: string } {
    const member = this.getMemberById(memberId);
    if (!member) return { success: false, message: 'সদস্য পাওয়া যায়নি।' };

    // Eligibility validation
    const eligibility = this.checkLoanEligibility(memberId);
    if (!eligibility.isEligible) {
      return {
        success: false,
        message: `ঋণ আবেদনের প্রাথমিক শর্ত পূরণ হয়নি: ${eligibility.missingReasons.join(', ')}`,
      };
    }

    let requestedAmount = 50000;
    let installmentCount = 12;
    let profitRatePercent = 10;
    let calculationMethod: 'FLAT' | 'REDUCING' = 'FLAT';
    let firstInstallmentDate = new Date().toISOString().split('T')[0];
    let purpose = 'ব্যবসায়িক বিনিয়োগ';
    let supportingDocuments: string[] = [];

    if (typeof params === 'object') {
      requestedAmount = params.requestedAmount;
      installmentCount = params.installmentCount ?? params.tenureMonths ?? 12;
      profitRatePercent = params.profitRatePercent ?? 10;
      calculationMethod = params.calculationMethod ?? 'FLAT';
      firstInstallmentDate = params.firstInstallmentDate ?? new Date().toISOString().split('T')[0];
      purpose = params.purpose;
      supportingDocuments = params.supportingDocuments ?? [];
    } else {
      requestedAmount = params;
      installmentCount = legacyTenureMonths ?? 12;
      purpose = legacyPurpose || 'ব্যবসায়িক বিনিয়োগ';
      supportingDocuments = legacyDocs || [];
    }

    const calc = calculateLoan({
      principal: requestedAmount,
      profitRatePercent,
      installmentCount,
      calculationMethod,
      firstInstallmentDate,
    });

    const loanId = `LN-${String(this.loans.length + 1).padStart(6, '0')}`;

    const newLoan: MemberLoan = {
      id: loanId,
      memberId,
      memberName: member.fullNameBn,
      requestedAmount,
      approvedAmount: requestedAmount,
      tenureMonths: Math.ceil(installmentCount),
      installmentCount,
      calculationMethod,
      firstInstallmentDate,
      profitRatePercent,
      totalProfitAmount: calc.totalProfitAmount,
      totalPayableAmount: calc.totalPayableAmount,
      monthlyInstallmentAmount: calc.regularInstallmentAmount,
      regularInstallmentAmount: calc.regularInstallmentAmount,
      lastInstallmentAmount: calc.lastInstallmentAmount,
      totalInstallments: calc.totalPaymentCount,
      installmentsPaidCount: 0,
      schedule: calc.schedule,
      loanStatus: 'SUBMITTED',
      purpose,
      totalPrincipalRepaid: 0,
      totalProfitRepaid: 0,
      outstandingPrincipal: requestedAmount,
      outstandingTotal: calc.totalPayableAmount,
      supportingDocuments,
      memberConsentStatus: 'PENDING',
    };

    this.loans.unshift(newLoan);
    this.saveLoans();

    this.logAudit(
      member.fullNameBn,
      'ঋণ আবেদন জমা',
      loanId,
      `৳ ${requestedAmount} টাকার ঋণ আবেদন দাখিল করা হয়েছে (${installmentCount} কিস্তি, মোট পরিশোধযোগ্য: ৳ ${calc.totalPayableAmount})`
    );

    return { success: true, loan: newLoan, message: 'ঋণ আবেদন সফলভাবে দাখিল হয়েছে।' };
  }

  public updateLoanProposal(
    loanId: string,
    params: {
      requestedAmount: number;
      installmentCount: number;
      profitRatePercent: number;
      calculationMethod: 'FLAT' | 'REDUCING';
      firstInstallmentDate: string;
      purpose?: string;
      actor: string;
      editReason?: string;
    }
  ): { success: boolean; loan?: MemberLoan; message: string } {
    const loan = this.getLoanById(loanId);
    if (!loan) return { success: false, message: 'ঋণ ফাইল পাওয়া যায়নি।' };
    if (loan.loanStatus !== 'SUBMITTED' && loan.loanStatus !== 'PENDING_APPROVAL') {
      return { success: false, message: 'অনুমোদিত বা সক্রিয় ঋণ ফাইল সম্পাদনা করা যাবে না।' };
    }

    const calc = calculateLoan({
      principal: params.requestedAmount,
      profitRatePercent: params.profitRatePercent,
      installmentCount: params.installmentCount,
      calculationMethod: params.calculationMethod,
      firstInstallmentDate: params.firstInstallmentDate,
    });

    loan.requestedAmount = params.requestedAmount;
    loan.approvedAmount = params.requestedAmount;
    loan.installmentCount = params.installmentCount;
    loan.tenureMonths = Math.ceil(params.installmentCount);
    loan.profitRatePercent = params.profitRatePercent;
    loan.calculationMethod = params.calculationMethod;
    loan.firstInstallmentDate = params.firstInstallmentDate;
    loan.totalProfitAmount = calc.totalProfitAmount;
    loan.totalPayableAmount = calc.totalPayableAmount;
    loan.monthlyInstallmentAmount = calc.regularInstallmentAmount;
    loan.regularInstallmentAmount = calc.regularInstallmentAmount;
    loan.lastInstallmentAmount = calc.lastInstallmentAmount;
    loan.totalInstallments = calc.totalPaymentCount;
    loan.outstandingPrincipal = params.requestedAmount;
    loan.outstandingTotal = calc.totalPayableAmount;
    loan.schedule = calc.schedule;
    if (params.purpose) loan.purpose = params.purpose;

    // Reset consent to PENDING because terms have changed
    loan.memberConsentStatus = 'PENDING';
    loan.memberConsentDate = undefined;
    loan.memberConsentNote = undefined;

    this.saveLoans();

    this.logAudit(
      params.actor,
      'ঋণ প্রস্তাবনা সম্পাদনা',
      loanId,
      `ঋণ পরিমাণ ৳ ${params.requestedAmount}, কিস্তি ${params.installmentCount}, মোট পরিশোধযোগ্য ৳ ${calc.totalPayableAmount} এ হালনাগাদ করা হয়েছে। কারণ: ${params.editReason || 'প্রশাসনিক পুনর্বিবেচনা'}`
    );

    return { success: true, loan, message: 'ঋণ প্রস্তাবনা সফলভাবে হালনাগাদ করা হয়েছে।' };
  }

  public recordMemberConsent(
    loanId: string,
    actor: string,
    note?: string
  ): { success: boolean; message: string; loan?: MemberLoan } {
    const loan = this.getLoanById(loanId);
    if (!loan) return { success: false, message: 'ঋণ ফাইল পাওয়া যায়নি।' };

    loan.memberConsentStatus = 'CONSENTED';
    loan.memberConsentDate = new Date().toISOString();
    loan.memberConsentGivenBy = actor;
    loan.memberConsentNote = note || 'সদস্য কর্তৃক সকল আর্থিক শর্ত ও কিস্তির হিসাব পড়ে সম্মতি প্রদান করা হয়েছে।';

    this.saveLoans();

    this.logAudit(
      actor,
      'সদস্যের ঋণ সম্মতি রেকর্ড',
      loanId,
      `সদস্য কর্তৃক ৳ ${loan.totalPayableAmount} মোট পরিশোধযোগ্য অর্থের কিস্তি সময়সূচিতে সম্মতি নথিভুক্ত করা হয়েছে।`
    );

    return { success: true, message: 'সদস্যের ঋণ সম্মতিপত্র সফলভাবে রেকর্ড করা হয়েছে।', loan };
  }

  public approveAndDisburseLoan(
    loanId: string,
    actor: string,
    options?: {
      disbursementMethod?: PaymentMethod;
      disbursementRef?: string;
      notes?: string;
    }
  ): { success: boolean; message: string; transaction?: TransactionRecord } {
    const loan = this.getLoanById(loanId);
    if (!loan) return { success: false, message: 'ঋণ ফাইল পাওয়া যায়নি।' };
    if (loan.loanStatus !== 'SUBMITTED' && loan.loanStatus !== 'PENDING_APPROVAL') {
      return { success: false, message: 'এই ঋণ ফাইলটি বর্তমানে অনুমোদনের উপযোগী অবস্থায় নেই।' };
    }

    // Blocker 1: Incomplete Loan Account check (admission fee, insurance, savings)
    const eligibility = this.checkLoanEligibility(loan.memberId);
    if (!eligibility.isEligible) {
      return {
        success: false,
        message: `ঋণ বিতরণ স্থগিত: লোন একাউন্ট অসম্পূর্ণ। ${eligibility.missingReasons.join('; ')}। পূর্বে বকেয়া পূরণ অথবা মওকুফ করুন।`,
      };
    }

    // Blocker 2: Member Consent check
    if (loan.memberConsentStatus !== 'CONSENTED') {
      return {
        success: false,
        message: 'ঋণ বিতরণ স্থগিত: সদস্যের আনুষ্ঠানিক সম্মতি (Consent) এখনও রেকর্ড করা হয়নি। বিতরণের পূর্বে সদস্যের সম্মতি গ্রহণ করুন।',
      };
    }

    const disbursementMethod = options?.disbursementMethod || 'CASH';
    const disbursementRef = options?.disbursementRef || `DISB-${Date.now().toString().slice(-6)}`;

    loan.loanStatus = 'ACTIVE';
    loan.approvedBy = actor;
    loan.finalApprovedBy = actor;
    loan.approvalDate = new Date().toISOString().split('T')[0];
    loan.disbursementDate = new Date().toISOString().split('T')[0];
    loan.disbursedBy = actor;
    loan.disbursementMethod = disbursementMethod;
    loan.disbursementRef = disbursementRef;

    // Next installment due date
    const firstDue = loan.schedule?.[0]?.dueDate;
    if (firstDue) {
      loan.nextInstallmentDueDate = firstDue;
    } else {
      const nextDate = new Date();
      nextDate.setDate(nextDate.getDate() + 30);
      loan.nextInstallmentDueDate = nextDate.toISOString().split('T')[0];
    }

    // Update member record snapshot
    const member = this.getMemberById(loan.memberId);
    if (member) {
      member.activeLoanId = loan.id;
      member.totalLoansTakenCount = (member.totalLoansTakenCount || 0) + 1;
      member.totalLoanDisbursedAmount = (member.totalLoanDisbursedAmount || 0) + loan.approvedAmount;
      member.currentLoanOutstanding = (member.currentLoanOutstanding || 0) + loan.approvedAmount;
      member.nextInstallmentDate = loan.nextInstallmentDueDate;
      member.nextInstallmentAmount = loan.regularInstallmentAmount || loan.monthlyInstallmentAmount;
      this.saveMembers();
    }

    this.saveLoans();

    // Financial Posting: Loan Disbursement
    const trxId = `TRX-${Date.now().toString().slice(-6)}`;
    const rcpId = `RCP-${Date.now().toString().slice(-6)}`;
    const trx: TransactionRecord = {
      id: trxId,
      date: new Date().toISOString().split('T')[0],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      referenceType: 'LOAN',
      referenceId: loan.id,
      referenceName: `${loan.memberName} (${loan.memberId})`,
      transactionType: 'ঋণ বিতরণ (Disbursement)',
      amount: loan.approvedAmount,
      paymentMethod: disbursementMethod,
      debitAccount: '1201-Principal Receivable',
      creditAccount: disbursementMethod === 'CASH' ? '1001-Cash in Hand' : '1002-Bank Account',
      approvalStatus: 'POSTED',
      approvedBy: actor,
      postedBy: 'সুপার এডমিন অটো-পোস্টিং',
      receiptNumber: rcpId,
      auditTrail: `Disbursed ৳${loan.approvedAmount} for loan ${loan.id} via ${disbursementMethod} (Ref: ${disbursementRef}) approved by ${actor}. ${options?.notes || ''}`,
    };

    // Official Disbursement Receipt/Voucher
    const receipt: OfficialReceipt = {
      receiptNumber: rcpId,
      transactionId: trxId,
      memberId: loan.memberId,
      memberName: loan.memberName,
      type: 'LOAN_INSTALLMENT',
      loanId: loan.id,
      amount: loan.approvedAmount,
      paymentMethod: disbursementMethod,
      paymentDate: new Date().toISOString().split('T')[0],
      paymentTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      transactionReference: disbursementRef,
      receivedBy: actor,
      postedStatus: 'POSTED',
      detailsNote: `ঋণ বিতরণ ভাউচার (Principal Disbursed: ৳ ${loan.approvedAmount}, মোট কিস্তি: ${loan.installmentCount})`,
      principalComponent: loan.approvedAmount,
      profitComponent: 0,
    };
    this.receipts.unshift(receipt);
    this.saveReceipts();

    this.logAudit(
      actor,
      'ঋণ চূড়ান্ত অনুমোদন ও বিতরণ',
      loanId,
      `৳ ${loan.approvedAmount} ঋণ সফলভাবে অনুমোদিত ও বিতরণ হয়েছে (ভাউচার: ${rcpId}, মেথড: ${disbursementMethod})`
    );

    return { success: true, message: 'ঋণ সফলভাবে অনুমোদিত ও বিতরণ করা হয়েছে।', transaction: trx };
  }

  // Backwards compatibility alias
  public approveLoan(
    loanId: string,
    actor: string,
    notes?: string
  ): { success: boolean; message: string; transaction?: TransactionRecord } {
    return this.approveAndDisburseLoan(loanId, actor, { notes });
  }

  // Payment Requests with Idempotency Protection
  public getAllPaymentRequests(): PaymentRequest[] {
    return [...this.paymentRequests];
  }

  public getPaymentRequestsByMember(memberId: string): PaymentRequest[] {
    return this.paymentRequests.filter((p) => p.memberId === memberId);
  }

  public submitPaymentRequest(params: {
    idempotencyKey: string;
    memberId: string;
    memberName: string;
    memberUserId?: string;
    loanId?: string;
    type: 'LOAN_INSTALLMENT' | 'SAVINGS_DEPOSIT' | 'ADMISSION_FEE' | 'INSURANCE_FEE';
    installmentNumber?: number;
    dueAmount: number;
    requestedAmount: number;
    paymentMethod: PaymentMethod;
    transactionReference?: string;
    paymentEvidenceUrl?: string;
  }): { success: boolean; request: PaymentRequest; isDuplicate: boolean; message: string } {
    // 1. Double-submit / Idempotency protection check
    const existing = this.paymentRequests.find(
      (p) => p.idempotencyKey === params.idempotencyKey
    );
    if (existing) {
      return {
        success: true,
        request: existing,
        isDuplicate: true,
        message: 'অনুরোধটি আগেই সফলভাবে জমা হয়েছে (Duplicate protected)।',
      };
    }

    const reqId = `REQ-PAY-${Date.now().toString().slice(-6)}`;
    const now = new Date();

    const newRequest: PaymentRequest = {
      id: reqId,
      idempotencyKey: params.idempotencyKey,
      memberId: params.memberId,
      memberName: params.memberName,
      memberUserId: params.memberUserId,
      loanId: params.loanId,
      type: params.type,
      installmentNumber: params.installmentNumber,
      dueAmount: params.dueAmount,
      requestedAmount: params.requestedAmount,
      paymentMethod: params.paymentMethod,
      transactionReference: params.transactionReference?.trim() || undefined,
      paymentEvidenceUrl: params.paymentEvidenceUrl,
      submittedDate: now.toISOString().split('T')[0],
      submittedTime: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'PENDING',
    };

    this.paymentRequests.unshift(newRequest);
    this.savePaymentRequests();

    this.logAudit(
      params.memberName,
      'কিস্তি জমার অনুরোধ দাখিল',
      reqId,
      `${params.paymentMethod}-এ ৳ ${params.requestedAmount} জমার অনুরোধ পাঠানো হয়েছে`
    );

    return {
      success: true,
      request: newRequest,
      isDuplicate: false,
      message: 'পেমেন্ট অনুরোধ সফলভাবে জমা হয়েছে। এডমিন যাচাই করে অনুমোদন করবেন।',
    };
  }

  // Atomic Financial Posting on Super Admin Approval
  public approvePaymentRequest(
    requestId: string,
    actor: string,
    reviewNote?: string
  ): {
    success: boolean;
    message: string;
    receipt?: OfficialReceipt;
    transaction?: TransactionRecord;
  } {
    const req = this.paymentRequests.find((p) => p.id === requestId);
    if (!req) {
      return { success: false, message: 'পেমেন্ট অনুরোধ পাওয়া যায়নি।' };
    }

    // Double-posting protection
    if (req.status !== 'PENDING') {
      return { success: false, message: 'এই অনুরোধটি ইতিমধ্যে প্রক্রিয়াধীন বা নিষ্পত্তি করা হয়েছে।' };
    }

    const member = this.getMemberById(req.memberId);
    if (!member) {
      return { success: false, message: 'সংশ্লিষ্ট সদস্য রেকর্ড পাওয়া যায়নি।' };
    }

    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const trxId = `TRX-${Date.now().toString().slice(-6)}`;
    const receiptNo = `RCP-${Date.now().toString().slice(-6)}`;

    let principalComp = 0;
    let profitComp = 0;

    // Financial posting based on request type
    if (req.type === 'LOAN_INSTALLMENT') {
      const loan = req.loanId ? this.getLoanById(req.loanId) : (member.activeLoanId ? this.getLoanById(member.activeLoanId) : undefined);
      
      // Calculate principal and profit breakdown (approx 90% principal, 10% profit)
      profitComp = Math.round(req.requestedAmount * 0.1);
      principalComp = req.requestedAmount - profitComp;

      if (loan) {
        loan.totalPrincipalRepaid += principalComp;
        loan.totalProfitRepaid += profitComp;
        loan.outstandingPrincipal = Math.max(0, loan.outstandingPrincipal - principalComp);
        loan.outstandingTotal = Math.max(0, loan.outstandingTotal - req.requestedAmount);
        loan.installmentsPaidCount += 1;

        if (loan.outstandingTotal <= 0) {
          loan.loanStatus = 'COMPLETED';
          member.activeLoanId = undefined;
        } else {
          // Advance next due date by 30 days
          const nextDate = new Date();
          nextDate.setDate(nextDate.getDate() + 30);
          loan.nextInstallmentDueDate = nextDate.toISOString().split('T')[0];
          member.nextInstallmentDate = loan.nextInstallmentDueDate;
        }
        this.saveLoans();
      }

      // Update member snapshot
      member.totalLoanPrincipalPaid += principalComp;
      member.totalLoanProfitPaid += profitComp;
      member.currentLoanOutstanding = Math.max(0, member.currentLoanOutstanding - principalComp);
    } else if (req.type === 'SAVINGS_DEPOSIT') {
      member.totalSavingsDeposits += req.requestedAmount;
      member.currentSavingsBalance += req.requestedAmount;
      if (member.initialSavingsStatus !== 'PAID') {
        member.initialSavingsPaid += req.requestedAmount;
        if (member.initialSavingsPaid >= member.initialSavingsRequired) {
          member.initialSavingsStatus = 'PAID';
        }
      }
    } else if (req.type === 'ADMISSION_FEE') {
      member.admissionFeePaid += req.requestedAmount;
      if (member.admissionFeePaid >= member.admissionFeeRequired) {
        member.admissionFeeStatus = 'PAID';
      }
      member.admissionReceiptRef = receiptNo;
    } else if (req.type === 'INSURANCE_FEE') {
      member.insuranceFeePaid += req.requestedAmount;
      if (member.insuranceFeePaid >= member.insuranceFeeRequired) {
        member.insuranceStatus = 'PAID';
      }
      member.insuranceReceiptRef = receiptNo;
    }

    member.updatedAt = now.toISOString();
    this.saveMembers();

    // Mark Request Approved
    req.status = 'APPROVED';
    req.reviewedBy = actor;
    req.reviewedAt = `${dateStr} ${timeStr}`;
    req.adminReviewNote = reviewNote;
    req.postedTransactionId = trxId;
    req.generatedReceiptNumber = receiptNo;
    this.savePaymentRequests();

    // Create Official Receipt
    const officialReceipt: OfficialReceipt = {
      receiptNumber: receiptNo,
      transactionId: trxId,
      memberId: member.id,
      memberName: member.fullNameBn,
      memberMobile: member.mobileNumber,
      type: req.type,
      loanId: req.loanId,
      installmentNumber: req.installmentNumber,
      amount: req.requestedAmount,
      paymentMethod: req.paymentMethod,
      paymentDate: dateStr,
      paymentTime: timeStr,
      transactionReference: req.transactionReference,
      receivedBy: actor,
      postedStatus: 'POSTED',
      detailsNote: reviewNote || `অনুমোদিত ও পোস্টকৃত (${req.paymentMethod})`,
      principalComponent: principalComp > 0 ? principalComp : undefined,
      profitComponent: profitComp > 0 ? profitComp : undefined,
    };

    this.receipts.unshift(officialReceipt);
    this.saveReceipts();

    // Journal Transaction Record
    const trx: TransactionRecord = {
      id: trxId,
      date: dateStr,
      timestamp: timeStr,
      referenceType: req.type === 'LOAN_INSTALLMENT' ? 'LOAN' : req.type === 'SAVINGS_DEPOSIT' ? 'SAVINGS' : req.type === 'ADMISSION_FEE' ? 'ADMISSION' : 'INSURANCE',
      referenceId: req.loanId || member.id,
      referenceName: `${member.fullNameBn} (${member.id})`,
      transactionType: req.type === 'LOAN_INSTALLMENT' ? 'ঋণ কিস্তি আদায় (Principal & Profit)' : req.type === 'SAVINGS_DEPOSIT' ? 'সঞ্চয় আমানত গ্রহণ' : req.type === 'ADMISSION_FEE' ? 'ভর্তি ফি রাজস্ব' : 'ইনস্যুরেন্স ফান্ড জমা',
      amount: req.requestedAmount,
      paymentMethod: req.paymentMethod,
      debitAccount: req.paymentMethod === 'CASH' ? '1001-Cash in Hand' : req.paymentMethod === 'BANK' ? '1002-Bank Account' : '1004-MFS Mobile Wallet',
      creditAccount: req.type === 'LOAN_INSTALLMENT' ? '1201-Principal & 4001-Profit' : req.type === 'SAVINGS_DEPOSIT' ? '2001-Member Savings Liability' : req.type === 'ADMISSION_FEE' ? '4002-Admission Revenue' : '2003-Insurance Reserve',
      approvalStatus: 'POSTED',
      approvedBy: actor,
      postedBy: 'সিস্টেম অটো-পোস্টিং',
      receiptNumber: receiptNo,
      auditTrail: `Payment request ${req.id} approved by ${actor}. Receipt ${receiptNo} generated.`,
    };

    this.logAudit(
      actor,
      'পেমেন্ট অনুমোদন ও আর্থিক পোস্টিং',
      req.id,
      `৳ ${req.requestedAmount} পোস্টিং সম্পন্ন। রশিদ: ${receiptNo}`
    );

    return {
      success: true,
      message: 'পেমেন্ট সফলভাবে অনুমোদিত এবং লেজারে পোস্ট হয়েছে। রশিদ তৈরি সম্পন্ন।',
      receipt: officialReceipt,
      transaction: trx,
    };
  }

  public rejectPaymentRequest(
    requestId: string,
    actor: string,
    reason: string
  ): { success: boolean; message: string } {
    const req = this.paymentRequests.find((p) => p.id === requestId);
    if (!req) return { success: false, message: 'অনুরোধ পাওয়া যায়নি।' };
    if (req.status !== 'PENDING') return { success: false, message: 'অনুরোধটি ইতিমধ্যে নিষ্পত্তি হয়েছে।' };

    req.status = 'REJECTED';
    req.reviewedBy = actor;
    req.reviewedAt = new Date().toISOString();
    req.adminReviewNote = reason;
    this.savePaymentRequests();

    this.logAudit(actor, 'পেমেন্ট অনুরোধ বাতিল', requestId, `কারণ: ${reason}`);

    return { success: true, message: 'পেমেন্ট অনুরোধ বাতিল করা হয়েছে।' };
  }

  // Profile Update Requests
  public getAllProfileRequests(): ProfileUpdateRequest[] {
    return [...this.profileRequests];
  }

  public getProfileRequestsByMember(memberId: string): ProfileUpdateRequest[] {
    return this.profileRequests.filter((p) => p.memberId === memberId);
  }

  public submitProfileUpdateRequest(params: {
    memberId: string;
    memberName: string;
    requestType: 'PHOTO' | 'NID' | 'CONTACT_INFO' | 'NOMINEE' | 'GUARANTOR' | 'DOCUMENT';
    oldValue: string;
    proposedValue: string;
    supportingDocumentUrl?: string;
  }): { success: boolean; message: string } {
    // Check if there's already a pending request of the same type for this member
    const existingPending = this.profileRequests.find(
      (r) => r.memberId === params.memberId && r.requestType === params.requestType && r.status === 'PENDING'
    );
    if (existingPending) {
      return { success: false, message: 'এই বিষয়ের একটি আবেদন ইতিমধ্যেই অনুমোদনের অপেক্ষায় আছে।' };
    }

    const reqId = `REQ-PRF-${Date.now().toString().slice(-6)}`;
    const newReq: ProfileUpdateRequest = {
      id: reqId,
      memberId: params.memberId,
      memberName: params.memberName,
      requestType: params.requestType,
      oldValue: params.oldValue,
      proposedValue: params.proposedValue,
      supportingDocumentUrl: params.supportingDocumentUrl,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'PENDING',
    };

    this.profileRequests.unshift(newReq);
    this.saveProfileRequests();

    this.logAudit(params.memberName, 'প্রোফাইল সংশোধন আবেদন', reqId, `${params.requestType} সংশোধনের আবেদন দাখিল`);
    return { success: true, message: 'প্রোফাইল সংশোধনের আবেদন সফলভাবে দাখিল হয়েছে।' };
  }

  public approveProfileUpdateRequest(
    requestId: string,
    actor: string,
    notes?: string
  ): { success: boolean; message: string } {
    const req = this.profileRequests.find((r) => r.id === requestId);
    if (!req) return { success: false, message: 'আবেদনটি পাওয়া যায়নি।' };
    if (req.status !== 'PENDING') return { success: false, message: 'আবেদনটি ইতিমধ্যে নিষ্পত্তি হয়েছে।' };

    const member = this.getMemberById(req.memberId);
    if (member) {
      if (req.requestType === 'PHOTO') {
        member.photoUrl = req.proposedValue;
      } else if (req.requestType === 'CONTACT_INFO') {
        try {
          const parsed = JSON.parse(req.proposedValue);
          if (parsed.mobileNumber) member.mobileNumber = parsed.mobileNumber;
          if (parsed.address) member.address = parsed.address;
        } catch {
          member.address = req.proposedValue;
        }
      } else if (req.requestType === 'NID') {
        member.nidNumber = req.proposedValue;
      } else if (req.requestType === 'NOMINEE') {
        try {
          member.nominee = JSON.parse(req.proposedValue);
        } catch {}
      } else if (req.requestType === 'GUARANTOR') {
        try {
          member.guarantor = JSON.parse(req.proposedValue);
        } catch {}
      }
      member.updatedAt = new Date().toISOString();
      this.saveMembers();
    }

    req.status = 'APPROVED';
    req.reviewedBy = actor;
    req.reviewedAt = new Date().toISOString();
    req.adminReviewNote = notes;
    this.saveProfileRequests();

    this.logAudit(actor, 'প্রোফাইল সংশোধন অনুমোদন', requestId, `${req.memberName}-এর তথ্য মূল প্রোফাইলে হালনাগাদ করা হয়েছে`);
    return { success: true, message: 'সংশোধন অনুমোদিত এবং মূল প্রোফাইলে হালনাগাদ করা হয়েছে।' };
  }

  public rejectProfileUpdateRequest(
    requestId: string,
    actor: string,
    reason: string
  ): { success: boolean; message: string } {
    const req = this.profileRequests.find((r) => r.id === requestId);
    if (!req) return { success: false, message: 'আবেদনটি পাওয়া যায়নি।' };
    if (req.status !== 'PENDING') return { success: false, message: 'আবেদনটি ইতিমধ্যে নিষ্পত্তি হয়েছে।' };

    req.status = 'REJECTED';
    req.reviewedBy = actor;
    req.reviewedAt = new Date().toISOString();
    req.adminReviewNote = reason;
    this.saveProfileRequests();

    this.logAudit(actor, 'প্রোফাইল সংশোধন বাতিল', requestId, `বাতিলের কারণ: ${reason}`);
    return { success: true, message: 'সংশোধন আবেদন বাতিল করা হয়েছে।' };
  }

  // Receipts
  public getAllReceipts(): OfficialReceipt[] {
    return [...this.receipts];
  }

  public getReceiptsByMember(memberId: string): OfficialReceipt[] {
    return this.receipts.filter((r) => r.memberId === memberId);
  }

  public getReceiptByNumber(receiptNumber: string): OfficialReceipt | undefined {
    return this.receipts.find((r) => r.receiptNumber === receiptNumber);
  }

  // Documents
  public addMemberDocument(
    memberId: string,
    doc: Omit<MemberRecord['documents'][0], 'id' | 'uploadedAt'>,
    actor: string
  ): boolean {
    const member = this.getMemberById(memberId);
    if (!member) return false;

    const newDoc = {
      ...doc,
      id: `DOC-${Date.now().toString().slice(-6)}`,
      uploadedAt: new Date().toISOString().split('T')[0],
      uploadedBy: actor,
    };

    member.documents.unshift(newDoc);
    member.updatedAt = new Date().toISOString();
    this.saveMembers();

    this.logAudit(actor, 'ডকুমেন্ট আপলোড', memberId, `${doc.title} ডকুমেন্ট আপলোড করা হয়েছে`);
    return true;
  }

  // Compute 12 Real Financial Metrics from Posted Data
  public getDashboardMetrics(): {
    totalMembers: number;
    activeMembers: number;
    inactiveMembers: number;
    totalLoanDisbursed: number;
    totalLoanPrincipalRecovered: number;
    totalLoanProfitRecovered: number;
    totalOutstandingLoanPrincipal: number;
    totalAdmissionFeesCollected: number;
    totalInsuranceCollected: number;
    totalSavingsDeposits: number;
    totalSavingsWithdrawals: number;
    currentSavingsBalance: number;
  } {
    const totalMembers = this.members.length;
    const activeMembers = this.members.filter((m) => m.status === 'ACTIVE').length;
    const inactiveMembers = this.members.filter((m) => m.status === 'INACTIVE' || m.status === 'SUSPENDED').length;

    // Derived strictly from members and approved loans/receipts
    let totalLoanDisbursed = 0;
    let totalLoanPrincipalRecovered = 0;
    let totalLoanProfitRecovered = 0;
    let totalOutstandingLoanPrincipal = 0;
    let totalAdmissionFeesCollected = 0;
    let totalInsuranceCollected = 0;
    let totalSavingsDeposits = 0;
    let totalSavingsWithdrawals = 0;

    this.loans.forEach((loan) => {
      if (loan.loanStatus === 'ACTIVE' || loan.loanStatus === 'COMPLETED' || loan.loanStatus === 'OVERDUE') {
        totalLoanDisbursed += loan.approvedAmount;
        totalLoanPrincipalRecovered += loan.totalPrincipalRepaid;
        totalLoanProfitRecovered += loan.totalProfitRepaid;
        totalOutstandingLoanPrincipal += loan.outstandingPrincipal;
      }
    });

    this.members.forEach((m) => {
      totalAdmissionFeesCollected += m.admissionFeePaid;
      totalInsuranceCollected += m.insuranceFeePaid;
      totalSavingsDeposits += m.totalSavingsDeposits;
      totalSavingsWithdrawals += m.totalSavingsWithdrawals;
    });

    const currentSavingsBalance = totalSavingsDeposits - totalSavingsWithdrawals;

    return {
      totalMembers,
      activeMembers,
      inactiveMembers,
      totalLoanDisbursed,
      totalLoanPrincipalRecovered,
      totalLoanProfitRecovered,
      totalOutstandingLoanPrincipal,
      totalAdmissionFeesCollected,
      totalInsuranceCollected,
      totalSavingsDeposits,
      totalSavingsWithdrawals,
      currentSavingsBalance,
    };
  }
}

export const memberService = new MemberRepository();
