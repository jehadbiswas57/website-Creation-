import { LoanScheduleInstallment } from '../types/member';

export type LoanCalculationMethod = 'FLAT' | 'REDUCING';

export interface LoanCalculationParams {
  principal: number;
  profitRatePercent: number; // e.g. 10%
  installmentCount: number; // e.g. 11, 11.5, 12, 12.5, 13, 15, 18, 24
  calculationMethod: LoanCalculationMethod;
  firstInstallmentDate: string; // YYYY-MM-DD
}

export interface LoanCalculationResult {
  principal: number;
  profitRatePercent: number;
  installmentCount: number;
  calculationMethod: LoanCalculationMethod;
  firstInstallmentDate: string;
  totalProfitAmount: number;
  totalPayableAmount: number;
  regularInstallmentAmount: number;
  lastInstallmentAmount: number;
  totalPaymentCount: number;
  isFractional: boolean;
  schedule: LoanScheduleInstallment[];
}

/**
 * Helper to add N months to a date string (YYYY-MM-DD)
 */
function addMonths(dateStr: string, monthsToAdd: number): string {
  try {
    const parts = dateStr.split('-');
    if (parts.length !== 3) {
      const now = new Date();
      now.setMonth(now.getMonth() + monthsToAdd);
      return now.toISOString().split('T')[0];
    }
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // 0-based
    const day = parseInt(parts[2], 10);

    const targetDate = new Date(year, month + monthsToAdd, day);
    // Adjust if month rolled over (e.g. Feb 30 -> Mar 2)
    if (targetDate.getDate() !== day) {
      targetDate.setDate(0); // last day of intended month
    }
    return targetDate.toISOString().split('T')[0];
  } catch {
    const d = new Date();
    d.setMonth(d.getMonth() + monthsToAdd);
    return d.toISOString().split('T')[0];
  }
}

/**
 * Formats numbers in Bengali digits
 */
export function toBnNumber(num: number | string): string {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[parseInt(d, 10)]);
}

/**
 * Calculates loan repayments with support for fractional installments (e.g. 11.5, 12.5)
 * and exact rounding adjustment on the final installment.
 */
export function calculateLoan(params: LoanCalculationParams): LoanCalculationResult {
  const {
    principal = 50000,
    profitRatePercent = 10,
    installmentCount = 12,
    calculationMethod = 'FLAT',
    firstInstallmentDate = new Date().toISOString().split('T')[0],
  } = params;

  const validPrincipal = Math.max(1000, Number(principal) || 0);
  const validRate = Math.max(0, Number(profitRatePercent) || 0);
  const validInstallmentCount = Math.max(1, Number(installmentCount) || 12);

  // Check if fractional installment count (e.g., 11.5, 12.5)
  const isFractional = validInstallmentCount % 1 !== 0;
  const fullInstallmentsCount = Math.floor(validInstallmentCount);

  let totalProfitAmount = 0;
  let totalPayableAmount = 0;

  if (calculationMethod === 'FLAT') {
    // Somiti Flat Profit: Profit = Principal * (Rate / 100) (10% profit for the term, e.g., 11.5 installments)
    totalProfitAmount = Math.round(validPrincipal * (validRate / 100));
    totalPayableAmount = validPrincipal + totalProfitAmount;
  } else {
    // Reducing balance calculation
    const monthlyRate = (validRate / 100) / 12;
    if (monthlyRate > 0) {
      const emi =
        (validPrincipal * monthlyRate * Math.pow(1 + monthlyRate, validInstallmentCount)) /
        (Math.pow(1 + monthlyRate, validInstallmentCount) - 1);
      totalPayableAmount = Math.round(emi * validInstallmentCount);
      totalProfitAmount = Math.max(0, totalPayableAmount - validPrincipal);
    } else {
      totalPayableAmount = validPrincipal;
      totalProfitAmount = 0;
    }
  }

  let regularInstallmentAmount = 0;
  let lastInstallmentAmount = 0;
  let totalPaymentCount = 0;

  if (isFractional) {
    // e.g. 11.5: 11 full installments + 1 half installment
    // Base unit payment = totalPayable / installmentCount (e.g. 57,500 / 11.5 = 5,000)
    totalPaymentCount = fullInstallmentsCount + 1;
    regularInstallmentAmount = Math.round(totalPayableAmount / validInstallmentCount);
    // Last half installment is totalPayable minus the sum of full installments
    lastInstallmentAmount = Math.max(0, totalPayableAmount - (regularInstallmentAmount * fullInstallmentsCount));
  } else {
    // Standard integer installments (e.g. 11, 12, 24)
    totalPaymentCount = fullInstallmentsCount;
    regularInstallmentAmount = Math.round(totalPayableAmount / validInstallmentCount);
    // Last installment adjusts rounding difference so sum equals totalPayable exactly
    lastInstallmentAmount = Math.max(
      0,
      totalPayableAmount - (regularInstallmentAmount * (totalPaymentCount - 1))
    );
  }

  // Generate schedule installments
  const schedule: LoanScheduleInstallment[] = [];
  let remainingPayable = totalPayableAmount;
  let remainingPrincipal = validPrincipal;

  for (let i = 1; i <= totalPaymentCount; i++) {
    const isLast = i === totalPaymentCount;
    const isHalfInstallment = isFractional && isLast;
    const installmentAmount = isLast ? lastInstallmentAmount : regularInstallmentAmount;

    // Prorate principal and profit parts
    let principalPart = 0;
    let profitPart = 0;

    if (isLast) {
      principalPart = remainingPrincipal;
      profitPart = Math.max(0, installmentAmount - principalPart);
    } else {
      const ratio = validPrincipal / totalPayableAmount;
      principalPart = Math.min(remainingPrincipal, Math.round(installmentAmount * ratio));
      profitPart = Math.max(0, installmentAmount - principalPart);
    }

    remainingPayable = Math.max(0, remainingPayable - installmentAmount);
    remainingPrincipal = Math.max(0, remainingPrincipal - principalPart);

    const dueDate = addMonths(firstInstallmentDate, i - 1);

    let label = `কিস্তি নং ${toBnNumber(i)}`;
    if (isHalfInstallment) {
      label = `শেষ কিস্তি (${toBnNumber(i)}ম - অর্ধেক কিস্তি)`;
    } else if (isLast) {
      label = `শেষ কিস্তি (${toBnNumber(i)}ম কিস্তি)`;
    }

    schedule.push({
      installmentNumber: i,
      label,
      dueDate,
      isFractional: isHalfInstallment,
      fractionWeight: isHalfInstallment ? 0.5 : 1,
      principalAmount: principalPart,
      profitAmount: profitPart,
      totalAmount: installmentAmount,
      paidAmount: 0,
      status: 'PENDING',
    });
  }

  return {
    principal: validPrincipal,
    profitRatePercent: validRate,
    installmentCount: validInstallmentCount,
    calculationMethod,
    firstInstallmentDate,
    totalProfitAmount,
    totalPayableAmount,
    regularInstallmentAmount,
    lastInstallmentAmount,
    totalPaymentCount,
    isFractional,
    schedule,
  };
}
