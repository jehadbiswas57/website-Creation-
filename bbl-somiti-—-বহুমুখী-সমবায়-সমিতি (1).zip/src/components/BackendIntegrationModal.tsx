import React, { useState } from 'react';
import { Server, X, ShieldAlert, CheckCircle2, Copy, Check, ExternalLink } from 'lucide-react';
import { Language } from '../types';

interface BackendIntegrationModalProps {
  lang: Language;
  submittedUserId?: string;
  onClose: () => void;
  onEnterDashboard?: () => void;
}

export const BackendIntegrationModal: React.FC<BackendIntegrationModalProps> = ({
  lang,
  submittedUserId,
  onClose,
  onEnterDashboard,
}) => {
  const isBn = lang === 'bn';
  const [copied, setCopied] = useState(false);

  const samplePayload = JSON.stringify(
    {
      action: 'login',
      userId: submittedUserId || '01XXXXXXXXX',
      timestamp: new Date().toISOString(),
      platform: 'BBL_SOMITI_WEB_V1',
    },
    null,
    2
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(samplePayload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-amber-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'ব্যাকএন্ড ইন্টিগ্রেশন নোটিশ' : 'Backend Integration Notice'}
              </h3>
              <p className="text-xs text-amber-900 font-bengali">
                {isBn ? 'প্রোডাকশন ফ্রন্টএন্ড সংযোগ স্ট্যাটাস' : 'Production Frontend Connectivity Status'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-slate-700 font-bengali">
          {/* Status Box */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 text-emerald-800 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{isBn ? 'ফ্রন্টএন্ড ভ্যালিডেশন: সফল ও প্রস্তুত' : 'Frontend Validation: Active & Complete'}</span>
            </div>
            {submittedUserId && (
              <p className="text-xs text-slate-600">
                {isBn ? 'গৃহীত ইউজার আইডি / মোবাইল:' : 'Captured User ID / Mobile:'}{' '}
                <strong className="text-slate-900 font-mono">{submittedUserId}</strong>
              </p>
            )}
            <div className="flex items-start gap-2 text-amber-800 text-xs pt-1 border-t border-slate-200/70">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                {isBn
                  ? 'আপনার নির্দেশনানুযায়ী কোনো ভুয়া ব্যালেন্স বা ভুয়া সদস্য রেকর্ড তৈরি করা হয়নি। আপনার আসল Google Apps Script বা REST API এন্ডপয়েন্ট সংযুক্ত হলে সদস্যদের আসল অ্যাকাউন্টে লগইন হবে।'
                  : 'Per your prompt specifications, no fabricated fake member profiles, fake balances, or fake financial transactions have been injected. Real member authentication activates once your live Google Apps Script or REST API URL is bound.'}
              </p>
            </div>
          </div>

          {/* Integration Specs */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                {isBn ? 'প্রস্তুতকৃত রিকোয়েস্ট পেলোড:' : 'Prepared API Payload Schema:'}
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 hover:text-blue-800"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি কোড' : 'Copy')}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-emerald-400 rounded-xl text-xs font-mono overflow-x-auto">
              {samplePayload}
            </pre>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            {isBn
              ? 'আপনার Google Apps Script ওয়েব অ্যাপ URL বা সার্ভার API লিংক প্রদান করতে পারেন সেটিংস মেনু থেকে।'
              : 'You can configure your Google Apps Script Web App URL or API endpoint via the Settings menu.'}
          </p>

          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs font-bengali transition-colors cursor-pointer"
            >
              {isBn ? 'লগইন পেজে থাকুন' : 'Stay on Login'}
            </button>
            {onEnterDashboard && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onEnterDashboard();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs font-bengali transition-all shadow-md shadow-blue-700/20 cursor-pointer"
              >
                {isBn ? 'সুপার এডমিন ড্যাশবোর্ডে প্রবেশ করুন →' : 'Enter Super Admin Dashboard →'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
