import React from 'react';
import {
  Info,
  BookOpen,
  Calculator,
  PhoneCall,
  ShieldAlert,
} from 'lucide-react';
import { Language, ActiveModal } from '../types';
import { getT } from '../translations';

interface FooterProps {
  lang: Language;
  onOpenModal: (modal: ActiveModal) => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onOpenModal }) => {
  const t = getT(lang);

  return (
    <footer className="w-full bg-[#064e3b] text-emerald-50 border-t border-emerald-900/60 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs sm:text-sm">
          {/* Left: Navigation links with icons */}
          <nav className="flex flex-wrap items-center justify-center md:justify-start gap-3 sm:gap-6">
            <button
              onClick={() => onOpenModal('about')}
              className="inline-flex items-center gap-1.5 text-emerald-100 hover:text-white transition-colors py-1 cursor-pointer font-medium font-bengali"
            >
              <Info className="w-4 h-4 text-emerald-400" />
              <span>{t.footerAbout}</span>
            </button>

            <span className="text-emerald-700 hidden sm:inline">|</span>

            <button
              onClick={() => onOpenModal('rules')}
              className="inline-flex items-center gap-1.5 text-emerald-100 hover:text-white transition-colors py-1 cursor-pointer font-medium font-bengali"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>{t.footerRules}</span>
            </button>

            <span className="text-emerald-700 hidden sm:inline">|</span>

            <button
              onClick={() => onOpenModal('calculator')}
              className="inline-flex items-center gap-1.5 text-emerald-100 hover:text-white transition-colors py-1 cursor-pointer font-medium font-bengali"
            >
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span>{t.footerCalculator}</span>
            </button>

            <span className="text-emerald-700 hidden sm:inline">|</span>

            <button
              onClick={() => onOpenModal('contact')}
              className="inline-flex items-center gap-1.5 text-emerald-100 hover:text-white transition-colors py-1 cursor-pointer font-medium font-bengali"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>{t.footerContact}</span>
            </button>

            <span className="text-emerald-700 hidden sm:inline">|</span>

            <button
              onClick={() => onOpenModal('backend_info')}
              className="inline-flex items-center gap-1.5 text-emerald-300/80 hover:text-white transition-colors py-1 cursor-pointer font-medium font-bengali text-xs"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'bn' ? 'সিস্টেম স্ট্যাটাস' : 'System Status'}</span>
            </button>
          </nav>

          {/* Right: Copyright & Branding */}
          <div className="flex flex-col sm:flex-row items-center gap-1.5 sm:gap-3 text-center md:text-right">
            <span className="font-bold tracking-wide text-white font-display">
              BBL SOMITI
            </span>
            <span className="text-emerald-400 hidden sm:inline">·</span>
            <span className="text-emerald-200/90 font-bengali">
              {t.copyright}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
