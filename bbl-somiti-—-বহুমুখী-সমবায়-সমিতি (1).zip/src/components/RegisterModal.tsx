import React, { useState } from 'react';
import { UserPlus, X, CheckCircle, FileText } from 'lucide-react';
import { Language } from '../types';

interface RegisterModalProps {
  lang: Language;
  onClose: () => void;
}

export const RegisterModal: React.FC<RegisterModalProps> = ({ lang, onClose }) => {
  const isBn = lang === 'bn';
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    mobile: '',
    nid: '',
    accountType: 'savings',
    nomineeName: '',
    address: '',
    termsAgreed: false,
  });
  const [validationError, setValidationError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.mobile.trim() || !formData.nid.trim()) {
      setValidationError(
        isBn
          ? 'অনুগ্রহ করে পূর্ণ নাম, মোবাইল নম্বর এবং জাতীয় পরিচয়পত্র নম্বর প্রদান করুন।'
          : 'Please enter your Full Name, Mobile Number, and NID Number.'
      );
      return;
    }
    if (!formData.termsAgreed) {
      setValidationError(
        isBn
          ? 'সমিতির নিয়মাবলী ও শর্তাবলীতে সম্মতি প্রদান করুন।'
          : 'Please agree to the cooperative terms & by-laws.'
      );
      return;
    }
    setValidationError('');
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-emerald-50/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'নতুন সদস্য আবেদন' : 'Member Registration'}
              </h3>
              <p className="text-xs text-emerald-800 font-bengali">
                BBL SOMITI — {isBn ? 'বহুমুখী সমবায় সমিতি' : 'Cooperative Society'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle className="w-9 h-9" />
              </div>
              <h4 className="text-xl font-bold text-slate-900 font-bengali">
                {isBn ? 'আবেদন সফলভাবে গৃহীত হয়েছে!' : 'Application Submitted Successfully!'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 font-bengali leading-relaxed max-w-md mx-auto">
                {isBn
                  ? 'আপনার প্রাথমিক সদস্যপদের তথ্য রেকর্ড করা হয়েছে। যাচাইকরণের পর BBL SOMITI থেকে এসএমএসের মাধ্যমে আপনার লগইন ইউজার আইডি ও পাসওয়ার্ড জানিয়ে দেওয়া হবে।'
                  : 'Your preliminary membership information has been recorded. Once verified by the branch committee, your official User ID and password will be delivered via SMS.'}
              </p>

              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-left text-xs space-y-1.5 font-bengali">
                <div className="flex justify-between text-slate-700">
                  <span>{isBn ? 'আবেদনকারীর নাম:' : 'Applicant Name:'}</span>
                  <span className="font-bold text-slate-900">{formData.fullName}</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>{isBn ? 'মোবাইল নম্বর:' : 'Mobile Number:'}</span>
                  <span className="font-bold text-slate-900">{formData.mobile}</span>
                </div>
                <div className="flex justify-between text-slate-700">
                  <span>{isBn ? 'আবেদনের রেফারেন্স নং:' : 'Reference No:'}</span>
                  <span className="font-mono font-bold text-emerald-800">BBL-2026-REG-{(Math.floor(Math.random() * 8999) + 1000)}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm transition-colors font-bengali"
              >
                {isBn ? 'লগইন পেজে ফিরে যান' : 'Return to Login'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {validationError && (
                <div className="p-3 rounded-xl bg-rose-50 text-rose-800 text-xs font-medium border border-rose-200">
                  {validationError}
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'পূর্ণ নাম (জাতীয় পরিচয়পত্র অনুযায়ী)' : 'Full Name (as per NID)'} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder={isBn ? 'উদা: মো: জাহাঙ্গীর আলম' : 'e.g. Md. Jahangir Alam'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Mobile */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'মোবাইল নম্বর' : 'Mobile Number'} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                    placeholder="01XXXXXXXXX"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                  />
                </div>

                {/* NID */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'জাতীয় পরিচয়পত্র (NID)' : 'National ID (NID)'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.nid}
                    onChange={(e) => setFormData({ ...formData, nid: e.target.value })}
                    placeholder={isBn ? '১০ বা ১৭ ডিজিটের NID' : '10 or 17 digit NID'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                  />
                </div>
              </div>

              {/* Account Type */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'সদস্যপদ / হিসাবের ধরন' : 'Account Type'}
                </label>
                <select
                  value={formData.accountType}
                  onChange={(e) => setFormData({ ...formData, accountType: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100 bg-white"
                >
                  <option value="savings">{isBn ? 'সাধারণ সঞ্চয় হিসাব (General Savings)' : 'General Savings'}</option>
                  <option value="dps">{isBn ? 'মাসিক ডিপিএস হিসাব (Monthly DPS Scheme)' : 'Monthly DPS Scheme'}</option>
                  <option value="shareholder">{isBn ? 'শেয়ারহোল্ডার সদস্য (Share Member)' : 'Share Capital Member'}</option>
                </select>
              </div>

              {/* Nominee */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'নমিনীর নাম ও সম্পর্ক' : 'Nominee Name & Relationship'}
                </label>
                <input
                  type="text"
                  value={formData.nomineeName}
                  onChange={(e) => setFormData({ ...formData, nomineeName: e.target.value })}
                  placeholder={isBn ? 'উদা: মোসা: নাসরিন আক্তার (স্ত্রী)' : 'e.g. Nasreen Akter (Spouse)'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100"
                />
              </div>

              {/* Terms agreement */}
              <label className="flex items-start gap-2.5 pt-1 cursor-pointer text-xs text-slate-600">
                <input
                  type="checkbox"
                  checked={formData.termsAgreed}
                  onChange={(e) => setFormData({ ...formData, termsAgreed: e.target.checked })}
                  className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="font-bengali leading-relaxed">
                  {isBn
                    ? 'আমি ঘোষণা করছি যে প্রদত্ত সমস্ত তথ্য সঠিক এবং আমি BBL SOMITI-এর সমবায় নীতিমালা মেনে চলতে বাধ্য থাকব।'
                    : 'I certify that the provided information is accurate and I agree to abide by BBL SOMITI cooperative by-laws.'}
                </span>
              </label>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-700/20 transition-all flex items-center justify-center gap-2 cursor-pointer font-bengali"
              >
                <FileText className="w-4 h-4" />
                <span>{isBn ? 'আবেদন জমা দিন' : 'Submit Application'}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
