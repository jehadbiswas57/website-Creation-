import React from 'react';
import { Calendar, MapPin, Sparkles, SlidersHorizontal } from 'lucide-react';
import { Language } from '../types';
import { getT } from '../translations';

// Import generated images
import plantSaplingImg from '../assets/images/hand_holding_plant_sapling_1792600582330.jpg';
import defaultLogoImg from '../assets/images/bbl_somiti_crest_logo_1792600597030.jpg';

interface BrandingPanelProps {
  lang: Language;
  customLogoUrl: string | null;
  onOpenSettings: () => void;
}

export const BrandingPanel: React.FC<BrandingPanelProps> = ({
  lang,
  customLogoUrl,
  onOpenSettings,
}) => {
  const t = getT(lang);
  const currentLogo = customLogoUrl || defaultLogoImg;

  return (
    <div className="relative flex flex-col justify-between overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-50/90 via-sky-50/70 to-teal-100/80 p-8 sm:p-10 lg:p-12 shadow-xl border border-white/60 min-h-[640px] lg:min-h-[720px]">
      {/* Subtle Background Pattern & Bangladesh Map Silhouette */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.09] z-0 flex items-center justify-center">
        <svg
          viewBox="0 0 600 750"
          className="w-full h-full object-contain text-emerald-900 fill-current"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Stylized outline of Bangladesh map */}
          <path d="M 280,60 C 310,50 350,75 365,110 C 380,140 420,165 410,210 C 400,245 440,280 435,320 C 430,360 415,390 440,430 C 460,470 480,520 460,560 C 440,590 390,620 360,610 C 330,600 310,640 280,650 C 250,660 210,630 190,610 C 160,580 180,540 160,500 C 140,460 110,430 120,380 C 130,330 150,290 180,260 C 210,230 200,180 230,130 Z" />
          {/* Subtle network circles representing branches across divisions */}
          <circle cx="290" cy="330" r="14" fill="#047857" opacity="0.4" />
          <circle cx="210" cy="270" r="10" fill="#0284c7" opacity="0.4" />
          <circle cx="390" cy="250" r="10" fill="#047857" opacity="0.4" />
          <circle cx="380" cy="460" r="12" fill="#0284c7" opacity="0.4" />
          <circle cx="210" cy="480" r="11" fill="#047857" opacity="0.4" />
          <circle cx="280" cy="180" r="9" fill="#0284c7" opacity="0.4" />
          <circle cx="330" cy="540" r="10" fill="#047857" opacity="0.4" />
        </svg>
      </div>

      {/* Top Branding Section */}
      <div className="relative z-10">
        <div className="flex items-start justify-between gap-4">
          {/* Somiti Logo with Quick Edit Affordance */}
          <div className="group relative">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-white p-1.5 shadow-md shadow-emerald-950/10 border border-emerald-100 flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
              <img
                src={currentLogo}
                alt="BBL SOMITI Logo"
                className="w-full h-full object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <button
              onClick={onOpenSettings}
              title={t.changeLogo}
              className="absolute -bottom-2 -right-2 bg-emerald-700 hover:bg-emerald-800 text-white p-1.5 rounded-full shadow-md transition-all duration-200 opacity-90 hover:opacity-100 scale-90 group-hover:scale-100"
              aria-label={t.changeLogo}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Nationwide Tag / Trust Marker */}
          <div className="flex flex-col items-end gap-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100/90 border border-emerald-300/80 text-emerald-900 text-xs font-semibold shadow-xs">
              <MapPin className="w-3.5 h-3.5 text-emerald-700" />
              <span>{t.nationwideLabel}</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100/90 border border-sky-300/80 text-sky-900 text-xs font-medium">
              <Calendar className="w-3.5 h-3.5 text-sky-700" />
              <span>{t.establishedLabel} {t.establishedDate}</span>
            </div>
          </div>
        </div>

        {/* Title, Bengali Name & Slogan */}
        <div className="mt-6 space-y-2">
          <div className="flex items-center gap-2">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 font-display">
              BBL SOMITI
            </h1>
          </div>
          <p className="text-xl sm:text-2xl font-bold text-emerald-800 font-bengali">
            {t.orgType}
          </p>
          <div className="pt-2 flex items-center gap-2">
            <span className="w-8 h-1 bg-emerald-600 rounded-full"></span>
            <p className="text-sm sm:text-base font-semibold text-slate-700 tracking-wide font-bengali">
              {t.slogan}
            </p>
          </div>
        </div>
      </div>

      {/* Middle Illustration - Cupped Hands Nurturing Plant Sapling */}
      <div className="relative z-10 my-4 flex flex-col items-center justify-center">
        <div className="relative group">
          {/* Subtle Ambient Halo */}
          <div className="absolute -inset-4 bg-gradient-to-r from-emerald-300/40 via-teal-300/40 to-sky-300/40 rounded-full blur-xl opacity-70 group-hover:opacity-90 transition-opacity"></div>
          
          <div className="relative w-48 h-48 sm:w-56 sm:h-56 lg:w-64 lg:h-64 rounded-full p-2 bg-white/80 backdrop-blur-xs border-2 border-emerald-200/80 shadow-lg shadow-emerald-900/10 overflow-hidden flex items-center justify-center">
            <img
              src={plantSaplingImg}
              alt="Hands holding green plant sprout"
              className="w-full h-full object-cover rounded-full transition-transform duration-500 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Inspiring Bottom Motto */}
        <div className="mt-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 backdrop-blur-xs border border-emerald-200 shadow-xs">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span className="text-sm sm:text-base font-bold text-emerald-950 font-bengali">
              {t.empoweringMotto}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Layered Wave Curves in Dark Green & Navy Blue */}
      <div className="absolute bottom-0 left-0 right-0 w-full overflow-hidden leading-none z-0 pointer-events-none">
        <svg
          viewBox="0 0 1200 240"
          preserveAspectRatio="none"
          className="relative block w-full h-28 sm:h-36 opacity-95"
        >
          {/* Layer 1: Navy Blue Wave */}
          <path
            d="M 0,110 C 200,160 420,70 650,130 C 880,190 1050,100 1200,140 L 1200,240 L 0,240 Z"
            fill="#0f3d6b"
            opacity="0.85"
          />
          {/* Layer 2: Deep Forest Green Wave */}
          <path
            d="M 0,140 C 240,80 480,180 720,110 C 960,50 1100,150 1200,120 L 1200,240 L 0,240 Z"
            fill="#064e3b"
            opacity="0.95"
          />
          {/* Layer 3: Vibrant Emerald Accent Wave */}
          <path
            d="M 0,175 C 300,140 600,200 900,160 C 1050,140 1150,180 1200,170 L 1200,240 L 0,240 Z"
            fill="#047857"
            opacity="0.7"
          />
        </svg>
      </div>
    </div>
  );
};
