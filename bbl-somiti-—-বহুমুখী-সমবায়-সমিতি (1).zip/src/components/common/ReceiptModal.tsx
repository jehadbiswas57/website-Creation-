import React from 'react';
import { X, Printer, Download, CheckCircle2, ShieldCheck } from 'lucide-react';
import { OfficialReceipt } from '../../types/member';
import { formatCurrency } from '../../utils/formatters';
import { Language } from '../../types';

interface ReceiptModalProps {
  receipt: OfficialReceipt;
  lang: Language;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ receipt, lang, onClose }) => {
  const isBn = lang === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh]">
        {/* Modal Top Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 print:hidden">
          <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{isBn ? 'অফিসিয়াল লেনদেন মানি রিসিট' : 'Official Money Receipt'}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-1 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{isBn ? 'প্রিন্ট' : 'Print'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Receipt Body */}
        <div className="p-8 space-y-6 overflow-y-auto bg-white text-slate-900" id="official-money-receipt">
          {/* Header */}
          <div className="text-center space-y-1 border-b-2 border-slate-900 pb-4">
            <span className="text-[10px] font-mono font-bold tracking-widest text-emerald-800 uppercase block">
              COOPERATIVE DIGITAL RECEIPT
            </span>
            <h2 className="text-xl font-extrabold tracking-tight font-display text-slate-900">
              BBL SOMITI
            </h2>
            <p className="text-xs font-semibold text-slate-600">
              বহুমুখী সমবায় সমিতি লিঃ · সততা, সেবা, একতা, প্রগতি
            </p>
            <p className="text-[10px] text-slate-400">
              স্থাপিত: ০১ জুন ২০২৬ · লাইসেন্স নং: সমবায়-৪১৮৯
            </p>
          </div>

          {/* Receipt Meta Row */}
          <div className="flex items-center justify-between text-xs font-mono bg-slate-50 p-3 rounded-2xl border border-slate-200">
            <div>
              <span className="text-slate-400 block text-[10px]">RECEIPT NO:</span>
              <strong className="text-blue-700 font-extrabold text-sm">{receipt.receiptNumber}</strong>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block text-[10px]">DATE & TIME:</span>
              <span className="font-semibold text-slate-700">{receipt.paymentDate} · {receipt.paymentTime}</span>
            </div>
          </div>

          {/* Member Details */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-slate-400 block">সদস্যের নাম:</span>
              <span className="font-bold text-slate-900 text-sm block">{receipt.memberName}</span>
            </div>
            <div className="space-y-1 text-right">
              <span className="text-slate-400 block">সদস্য আইডি:</span>
              <span className="font-mono font-bold text-slate-900 text-sm block">{receipt.memberId}</span>
            </div>
            {receipt.loanId && (
              <div className="space-y-1">
                <span className="text-slate-400 block">ঋণ ফাইল আইডি:</span>
                <span className="font-mono font-bold text-blue-700 block">{receipt.loanId}</span>
              </div>
            )}
            <div className="space-y-1 text-right">
              <span className="text-slate-400 block">পেমেন্ট মেথড:</span>
              <span className="font-mono font-bold text-slate-800 block">{receipt.paymentMethod}</span>
            </div>
          </div>

          {/* Particulars Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-slate-100 border-b border-slate-200 font-bold">
                <tr>
                  <th className="py-2.5 px-3 text-left">খাত / বিবরণ</th>
                  <th className="py-2.5 px-3 text-right">পরিমাণ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-3 px-3">
                    <span className="font-bold block">
                      {receipt.type === 'LOAN_INSTALLMENT'
                        ? 'ঋণ কিস্তি আদায়'
                        : receipt.type === 'SAVINGS_DEPOSIT'
                        ? 'সঞ্চয় আমানত জমা'
                        : receipt.type === 'ADMISSION_FEE'
                        ? 'ভর্তি ফি রাজস্ব'
                        : 'ইনস্যুরেন্স ফান্ড জমা'}
                    </span>
                    <span className="text-[10px] text-slate-500">{receipt.detailsNote}</span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-sm">
                    {formatCurrency(receipt.amount, lang)}
                  </td>
                </tr>
                {receipt.principalComponent !== undefined && receipt.profitComponent !== undefined && (
                  <tr className="bg-slate-50/70 text-[11px] text-slate-600 font-mono">
                    <td className="py-1.5 px-3">
                      মূলধন: ৳{receipt.principalComponent} · মুনাফা: ৳{receipt.profitComponent}
                    </td>
                    <td className="py-1.5 px-3 text-right">
                      ব্রেকডাউন
                    </td>
                  </tr>
                )}
                <tr className="bg-slate-50 font-extrabold border-t border-slate-200">
                  <td className="py-3 px-3 text-slate-900">সর্বমোট প্রাপ্ত টাকা:</td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-800 text-base">
                    {formatCurrency(receipt.amount, lang)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Posting Status & Transaction ID */}
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-900 font-semibold">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>লেজারে সফলভাবে পোস্টকৃত (Status: {receipt.postedStatus})</span>
            </div>
            <span className="font-mono text-emerald-800 font-bold">{receipt.transactionId}</span>
          </div>

          {/* Signatures */}
          <div className="pt-8 grid grid-cols-2 gap-8 text-center text-xs text-slate-500 border-t border-slate-200">
            <div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold text-slate-700">
                সদস্যের স্বাক্ষর
              </div>
            </div>
            <div>
              <div className="border-t border-dashed border-slate-400 pt-1 font-semibold text-slate-700">
                অনুমোদনকারী (ক্যাশিয়ার / সুপার এডমিন)
              </div>
              <span className="text-[10px] text-slate-400 block">{receipt.receivedBy}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
