import React from 'react';
import { Info, X, Check, Award, Users, Shield, TrendingUp } from 'lucide-react';
import { Language } from '../types';

interface AboutModalProps {
  lang: Language;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ lang, onClose }) => {
  const isBn = lang === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-emerald-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'আমাদের সম্পর্কে — BBL SOMITI' : 'About Us — BBL SOMITI'}
              </h3>
              <p className="text-xs text-emerald-900 font-bengali">
                {isBn ? 'বহুমুখী সমবায় সমিতি লিঃ' : 'Multipurpose Cooperative Society Ltd.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-slate-700 text-sm font-bengali">
          <div>
            <h4 className="text-base font-bold text-slate-900 mb-1.5 flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              <span>{isBn ? 'প্রতিষ্ঠা ও মূল উদ্দেশ্য' : 'Establishment & Mission'}</span>
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {isBn
                ? 'BBL SOMITI (বিবি এল সমিতি) দেশের প্রান্তিক ও কর্মঠ মানুষের অর্থনৈতিক স্বাবলম্বিতা অর্জনের লক্ষ্যে প্রতিষ্ঠিত একটি নিবন্ধিত বহুমুখী সমবায় সমিতি। ক্ষুদ্র সঞ্চয় গড়ে তোলা, সহজ শর্তে সমবায় ঋণ সহায়তা এবং সদস্যদের মধ্যে পারস্পরিক আর্থিক নিরাপত্তা বিধান করাই আমাদের অঙ্গীকার।'
                : 'BBL SOMITI is a registered multipurpose cooperative society founded to empower members with financial self-reliance, systematic savings, low-interest microcredit facilities, and shared socioeconomic growth.'}
            </p>
          </div>

          {/* 4 Pillars */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
              {isBn ? 'আমাদের মূল চারটি স্তম্ভ' : 'Our 4 Core Pillars'}
            </h5>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <div>
                  <span className="font-bold text-slate-900 block text-xs">{isBn ? 'সততা (Honesty)' : 'Honesty'}</span>
                  <span className="text-[11px] text-slate-500">{isBn ? 'শতভাগ স্বচ্ছ হিসাব ব্যবস্থাপনা' : '100% transparent accounting'}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <div>
                  <span className="font-bold text-slate-900 block text-xs">{isBn ? 'সেবা (Service)' : 'Service'}</span>
                  <span className="text-[11px] text-slate-500">{isBn ? 'সদস্যবান্ধব সার্বক্ষণিক সেবা' : 'Dedicated member assistance'}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <div>
                  <span className="font-bold text-slate-900 block text-xs">{isBn ? 'একতা (Unity)' : 'Unity'}</span>
                  <span className="text-[11px] text-slate-500">{isBn ? 'সমবায়ের শক্তিতে ঐক্যবদ্ধ' : 'United cooperative power'}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <div>
                  <span className="font-bold text-slate-900 block text-xs">{isBn ? 'প্রগতি (Progress)' : 'Progress'}</span>
                  <span className="text-[11px] text-slate-500">{isBn ? 'টেকসই আর্থিক প্রবৃদ্ধি' : 'Sustainable financial growth'}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs pt-1">
            <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200">
              <span className="text-blue-900 font-bold block">{isBn ? 'প্রতিষ্ঠা তারিখ:' : 'Founding Date:'}</span>
              <span className="text-slate-600">{isBn ? '০১ জুন ২০২৬' : '01 June 2026'}</span>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
              <span className="text-emerald-950 font-bold block">{isBn ? 'কার্যপরিধি:' : 'Jurisdiction:'}</span>
              <span className="text-slate-600">{isBn ? 'সমগ্র বাংলাদেশ' : 'Nationwide Bangladesh'}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm transition-colors"
          >
            {isBn ? 'বুঝেছি' : 'Understood'}
          </button>
        </div>
      </div>
    </div>
  );
};
