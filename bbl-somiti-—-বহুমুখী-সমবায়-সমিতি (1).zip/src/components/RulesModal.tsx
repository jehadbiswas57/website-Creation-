import React from 'react';
import { BookOpen, X, CheckSquare } from 'lucide-react';
import { Language } from '../types';

interface RulesModalProps {
  lang: Language;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ lang, onClose }) => {
  const isBn = lang === 'bn';

  const rulesListBn = [
    'প্রত্যেক সদস্যকে সমিতির অনুমোদিত আবেদনপত্রের মাধ্যমে বৈধ সদস্যপদ গ্রহণ করতে হবে।',
    'নিয়মিত সাপ্তাহিক বা মাসিক সঞ্চয় নির্ধারিত সময়ের মধ্যে জমা প্রদান বাধ্যতামূলক।',
    'ঋণ সুবিধার জন্য ন্যূনতম ৩ মাস নিয়মিত সঞ্চয় ও শেয়ার মূলধন জমা থাকা আবশ্যক।',
    'ঋণের কিস্তি প্রতি মাসের ০১ থেকে ১০ তারিখের মধ্যে পরিশোধ করতে হবে।',
    'সদস্যপদ প্রত্যাহারের ক্ষেত্রে ন্যুনতম ৩০ দিন পূর্বে লিখিত নোটিশ প্রদান করতে হবে।',
    'সমিতির বার্ষিক সাধারণ সভায় (AGM) প্রতি সদস্য একটি ভোটের অধিকারী হবেন।',
  ];

  const rulesListEn = [
    'Every member must hold valid membership through the officially approved application form.',
    'Regular weekly or monthly savings deposits must be submitted within the scheduled window.',
    'To be eligible for credit assistance, at least 3 months of regular active savings are required.',
    'Loan installments must be deposited between the 1st and 10th of each calendar month.',
    'Voluntary withdrawal of membership requires a minimum 30-day prior written notice.',
    'Each member holds one vote in the Annual General Meeting (AGM) as per cooperative bylaws.',
  ];

  const list = isBn ? rulesListBn : rulesListEn;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-emerald-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'সমিতির নিয়মাবলী ও নীতিমালা' : 'Rules & Cooperative By-Laws'}
              </h3>
              <p className="text-xs text-emerald-900 font-bengali">
                {isBn ? 'সদস্যগণের অবশ্য পালনীয় নির্দেশিকা' : 'Essential guidelines for registered members'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of rules */}
        <div className="p-6 space-y-4">
          <ul className="space-y-3">
            {list.map((rule, idx) => (
              <li key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-slate-700 font-bengali leading-relaxed">
                <CheckSquare className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                <span>{rule}</span>
              </li>
            ))}
          </ul>

          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-bengali leading-relaxed">
            {isBn
              ? 'বিশেষ দ্রষ্টব্য: বাংলাদেশ সমবায় অধিদপ্তর ও সমবায় আইন ২০০১ (সংশোধিত ২০১৩)-এর বিধিমালা অনুযায়ী সমিতি পরিচালিত হয়।'
              : 'Note: Managed strictly in compliance with Bangladesh Cooperative Societies Act 2001 (Amended 2013).'}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm transition-colors font-bengali"
          >
            {isBn ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
