import React from 'react';
import { PhoneCall, X, MapPin, Mail, Clock, Headphones } from 'lucide-react';
import { Language } from '../types';

interface ContactModalProps {
  lang: Language;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ lang, onClose }) => {
  const isBn = lang === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-emerald-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'যোগাযোগ ও হেল্পডেস্ক' : 'Contact & Helpdesk'}
              </h3>
              <p className="text-xs text-emerald-900 font-bengali">
                {isBn ? 'BBL SOMITI কেন্দ্রীয় সহায়তা কেন্দ্র' : 'BBL SOMITI Central Support Center'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-slate-700 font-bengali">
          {/* Head Office */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <MapPin className="w-5 h-5 text-emerald-700 mt-0.5 shrink-0" />
            <div className="text-xs sm:text-sm">
              <span className="font-bold text-slate-900 block">
                {isBn ? 'প্রধান কার্যালয়:' : 'Head Office:'}
              </span>
              <p className="text-slate-600 text-xs mt-0.5">
                {isBn
                  ? 'প্লট-২৪, ব্লক-বি, সমবায় ভবন রোড, ঢাকা-১২১৬, বাংলাদেশ'
                  : 'Plot-24, Block-B, Somobay Bhaban Road, Dhaka-1216, Bangladesh'}
              </p>
            </div>
          </div>

          {/* Hotline */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <Headphones className="w-5 h-5 text-emerald-700 mt-0.5 shrink-0" />
            <div className="text-xs sm:text-sm">
              <span className="font-bold text-slate-900 block">
                {isBn ? 'কেন্দ্রীয় হটলাইন ও হোয়াটসঅ্যাপ:' : 'Central Hotline & WhatsApp:'}
              </span>
              <p className="text-slate-700 font-mono font-semibold text-xs mt-0.5">
                +880 1711-000000 / +880 2-9876543
              </p>
            </div>
          </div>

          {/* Email */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <Mail className="w-5 h-5 text-emerald-700 mt-0.5 shrink-0" />
            <div className="text-xs sm:text-sm">
              <span className="font-bold text-slate-900 block">
                {isBn ? 'ইমেইল যোগাযোগ:' : 'Official Email:'}
              </span>
              <p className="text-slate-700 font-mono text-xs mt-0.5">
                support@bblsomiti.org.bd / info@bblsomiti.org.bd
              </p>
            </div>
          </div>

          {/* Hours */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
            <Clock className="w-5 h-5 text-emerald-700 mt-0.5 shrink-0" />
            <div className="text-xs sm:text-sm">
              <span className="font-bold text-slate-900 block">
                {isBn ? 'সেবা সময়সূচি:' : 'Service Hours:'}
              </span>
              <p className="text-slate-600 text-xs mt-0.5">
                {isBn
                  ? 'শনিবার থেকে বৃহস্পতিবার: সকাল ৯:০০ টা থেকে বিকাল ৫:০০ টা (শুক্রবার বন্ধ)'
                  : 'Saturday to Thursday: 9:00 AM – 5:00 PM (Friday Closed)'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm transition-colors"
          >
            {isBn ? 'ঠিক আছে' : 'OK'}
          </button>
        </div>
      </div>
    </div>
  );
};
