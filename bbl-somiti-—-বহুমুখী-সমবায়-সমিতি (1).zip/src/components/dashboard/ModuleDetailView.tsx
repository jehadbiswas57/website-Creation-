import React, { useState } from 'react';
import {
  SidebarSection,
  Language,
  FinancialState,
  TransactionRecord,
  ApprovalRequest,
} from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';
import {
  Users,
  Briefcase,
  HandCoins,
  PiggyBank,
  BookOpen,
  FolderTree,
  Scale,
  ShieldAlert,
  FileSpreadsheet,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Printer,
  PlusCircle,
  FileText,
} from 'lucide-react';

interface ModuleDetailViewProps {
  section: SidebarSection;
  financialState: FinancialState;
  transactions: TransactionRecord[];
  approvals: ApprovalRequest[];
  lang: Language;
  onOpenQuickActions: () => void;
}

export const ModuleDetailView: React.FC<ModuleDetailViewProps> = ({
  section,
  financialState,
  transactions,
  approvals,
  lang,
  onOpenQuickActions,
}) => {
  const isBn = lang === 'bn';
  const [searchTerm, setSearchTerm] = useState('');

  // Sample Chart of Accounts
  const chartOfAccounts = [
    { code: '1001', nameBn: 'ক্যাশ ইন হ্যান্ড (প্রধান ভল্ট)', nameEn: 'Cash in Hand (Main Vault)', type: 'ASSET', balance: financialState.presentCash },
    { code: '1002', nameBn: 'ইসলামী ব্যাংক বাংলাদেশ লিঃ (চলতি)', nameEn: 'Islami Bank BD Ltd. (Current A/C)', type: 'ASSET', balance: financialState.bankBalance * 0.6 },
    { code: '1003', nameBn: 'সোনালী ব্যাংক পিএলসি (সঞ্চয়ী)', nameEn: 'Sonali Bank PLC (Savings A/C)', type: 'ASSET', balance: financialState.bankBalance * 0.4 },
    { code: '1201', nameBn: 'সদস্য ঋণ মূলধন আদায়যোগ্য', nameEn: 'Loan Principal Receivable', type: 'ASSET', balance: financialState.totalOutstandingLoanPrincipal },
    { code: '2001', nameBn: 'সদস্য সাধারণ সঞ্চয় আমানত', nameEn: 'Member General Savings Liability', type: 'LIABILITY', balance: financialState.memberSavingsLiability },
    { code: '2002', nameBn: 'ডিপিএস স্কিম আমানত দায়', nameEn: 'DPS Term Scheme Liability', type: 'LIABILITY', balance: financialState.dpsLiability },
    { code: '2003', nameBn: 'সদস্য কল্যাণ ও ইনস্যুরেন্স ফান্ড', nameEn: 'Member Welfare & Insurance Reserve', type: 'LIABILITY', balance: financialState.insuranceFundBalance },
    { code: '3001', nameBn: 'পার্টনার ইকুইটি মূলধন', nameEn: 'Partner Equity Capital', type: 'EQUITY', balance: financialState.totalPartnerCapital },
    { code: '4001', nameBn: 'ঋণ সার্ভিস চার্জ ও মুনাফা আয়', nameEn: 'Loan Service Charge & Profit Income', type: 'INCOME', balance: financialState.totalLoanProfitRecovered },
    { code: '4002', nameBn: 'সদস্য ভর্তি ফি রাজস্ব', nameEn: 'Member Admission Fee Revenue', type: 'INCOME', balance: financialState.totalAdmissionFeesCollected },
    { code: '5001', nameBn: 'অফিস প্রশাসন ও পরিচালন ব্যয়', nameEn: 'Office Administration & Operating Expense', type: 'EXPENSE', balance: financialState.totalApprovedExpenses },
  ];

  // Audit Logs
  const auditLogs = [
    { id: 'AUD-901', time: '10:12 AM', actor: 'সুপার এডমিন (SA-01)', action: 'Formula Reconciliation Audit', detail: 'Checked Formula A and Ledger balance consistency', status: 'VERIFIED' },
    { id: 'AUD-900', time: '09:45 AM', actor: 'ক্যাশিয়ার (ST-03)', action: 'Loan Installment Post', detail: 'Posted TRX-001089 (৳ 5,400) to A/C 1001 & 1201', status: 'SUCCESS' },
    { id: 'AUD-899', time: '09:30 AM', actor: 'ম্যানেজার (MG-01)', action: 'Approval Review', detail: 'Approved withdrawal request APP-0092', status: 'APPROVED' },
    { id: 'AUD-898', time: 'Yesterday', actor: 'সুপার এডমিন (SA-01)', action: 'Branding Settings Updated', detail: 'Verified 100 BDT admission fee compliance', status: 'CONFIG' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-blue-700 font-bold uppercase tracking-widest block">
            BBL SOMITI COOPERATIVE LEDGER
          </span>
          <h2 className="text-xl font-extrabold text-slate-900 font-display mt-0.5">
            {section === 'chart_of_accounts' && (isBn ? 'চার্ট অফ অ্যাকাউন্টস (Chart of Accounts)' : 'Chart of Accounts')}
            {section === 'general_ledger' && (isBn ? 'সাধারণ খতিয়ান ও হিসাব বই (General Ledger)' : 'General Ledger')}
            {section === 'cashbook' && (isBn ? 'দৈনিক ক্যাশ বুক রেজিস্টার (Daily Cashbook)' : 'Daily Cashbook')}
            {section === 'audit_log' && (isBn ? 'নিরাপত্তা ও আর্থিক অডিট লগ (Audit Trail)' : 'Security & Audit Log')}
            {section === 'members' && (isBn ? 'সদস্য তালিকা ও খতিয়ান (Member Register)' : 'Member Master Register')}
            {section === 'partners' && (isBn ? 'পার্টনার বিনিয়োগ বিবরণী (Partner Capital)' : 'Partner Capital Register')}
            {section === 'reports' && (isBn ? 'আর্থিক অডিট রিপোর্ট ও স্টেটমেন্ট (Reports)' : 'Financial Statements')}
            {!['chart_of_accounts', 'general_ledger', 'cashbook', 'audit_log', 'members', 'partners', 'reports'].includes(section) &&
              (isBn ? 'সমবায় মডিউল বিবরণী' : 'Cooperative Module View')}
          </h2>
          <p className="text-xs text-slate-500 font-bengali mt-0.5">
            {isBn ? 'ডাবল এন্ট্রি ব্যালেন্স এবং লেজার ট্রেসেবিলিটি সমর্থিত' : 'Double-entry balanced & audit-traceable'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenQuickActions}
            className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer font-bengali shadow-xs"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{isBn ? 'নতুন এন্ট্রি' : 'New Entry'}</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">{isBn ? 'প্রিন্ট' : 'Print'}</span>
          </button>
        </div>
      </div>

      {/* View: Chart of Accounts */}
      {(section === 'chart_of_accounts' || section === 'general_ledger') && (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-900 font-bengali">
              {isBn ? 'হিসাবের কোড ও চলমান খতিয়ান ব্যালেন্স' : 'Account Codes & Running Ledger Balances'}
            </h3>
            <span className="text-xs font-mono text-emerald-800 font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Total Heads: {chartOfAccounts.length}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-bengali">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono">
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Account Head Name</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4 text-right">Running Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {chartOfAccounts.map((acc) => (
                  <tr key={acc.code} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono font-bold text-blue-700">{acc.code}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {isBn ? acc.nameBn : acc.nameEn}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        acc.type === 'ASSET' ? 'bg-blue-100 text-blue-800' :
                        acc.type === 'LIABILITY' ? 'bg-amber-100 text-amber-800' :
                        acc.type === 'EQUITY' ? 'bg-purple-100 text-purple-800' :
                        acc.type === 'INCOME' ? 'bg-emerald-100 text-emerald-800' :
                        'bg-rose-100 text-rose-800'
                      }`}>
                        {acc.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                      {formatCurrency(acc.balance, lang)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View: Daily Cashbook */}
      {section === 'cashbook' && (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
              <span className="text-xs font-bold text-emerald-950 block font-bengali">{isBn ? 'দিনের প্রারম্ভিক ক্যাশ' : 'Opening Cash'}</span>
              <span className="text-2xl font-extrabold text-emerald-900 font-mono mt-1 block">
                {formatCurrency(financialState.presentCash * 0.92, lang)}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
              <span className="text-xs font-bold text-blue-950 block font-bengali">{isBn ? 'আজকের মোট জমা (Receipts)' : 'Today Total Inflows'}</span>
              <span className="text-2xl font-extrabold text-blue-900 font-mono mt-1 block">
                {formatCurrency(financialState.todayLoanCollection + financialState.todaySavingsCollection, lang)}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200">
              <span className="text-xs font-bold text-purple-950 block font-bengali">{isBn ? 'সমাপনী নগদ ব্যালেন্স' : 'Closing Cash in Vault'}</span>
              <span className="text-2xl font-extrabold text-purple-900 font-mono mt-1 block">
                {formatCurrency(financialState.presentCash, lang)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* View: Audit Log */}
      {section === 'audit_log' && (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-900 font-bengali">
              {isBn ? 'সুপার এডমিন ও সিকিউরিটি অডিট ট্রেইল' : 'System Security & Financial Audit Trail'}
            </h3>
            <span className="text-xs font-mono text-slate-500">Immutable Log</span>
          </div>
          <div className="divide-y divide-slate-100 font-bengali">
            {auditLogs.map((log) => (
              <div key={log.id} className="p-4 hover:bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-blue-700">{log.id}</span>
                    <span className="font-bold text-slate-900">{log.action}</span>
                    <span className="text-slate-400 font-mono text-[10px]">{log.time}</span>
                  </div>
                  <p className="text-slate-600">{log.detail}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-slate-500">{log.actor}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold font-mono text-[10px]">
                    {log.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Generic fallback module info */}
      {!['chart_of_accounts', 'general_ledger', 'cashbook', 'audit_log'].includes(section) && (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-700 mx-auto flex items-center justify-center">
            <FileSpreadsheet className="w-8 h-8" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-base font-bold text-slate-900 font-display">
              {isBn ? 'মডিউল সক্রিয় ও প্রস্তুত' : 'Module Integrated & Operational'}
            </h3>
            <p className="text-xs text-slate-500 font-bengali leading-relaxed">
              {isBn
                ? 'এই মডিউলের সমস্ত ডাটা Google Sheets-এর সংশ্লিষ্ট টেবিল (যেমন: MEMBERS, LOANS, TRANSACTIONS) এবং কেন্দ্রীয় লেজারের সাথে সংযুক্ত। ডান পাশের শর্টকাট থেকে সরাসরি ডাটা এন্ট্রি করতে পারেন।'
                : 'This module is directly linked with the centralized schema tables and general ledger. You can submit entries via Quick Actions.'}
            </p>
          </div>
          <button
            onClick={onOpenQuickActions}
            className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs font-bengali cursor-pointer"
          >
            {isBn ? '+ লেনদেন বা এন্ট্রি যোগ করুন' : '+ Log Entry'}
          </button>
        </div>
      )}
    </div>
  );
};
