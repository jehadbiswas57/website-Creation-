import React, { useState } from 'react';
import {
  SidebarSection,
  Language,
  DateRange,
  DataMode,
  Role,
  BrandingSettings,
  FinancialFormulaConfig,
  FinancialState,
  TransactionRecord,
  ApprovalRequest,
} from '../../types/dashboard';
import { Sidebar } from './Sidebar';
import { HeaderBar } from './HeaderBar';
import { DashboardMainView } from './DashboardMainView';
import { SettingsView } from './SettingsView';
import { ModuleDetailView } from './ModuleDetailView';
import { QuickActionsModal } from './QuickActionsModal';
import { GoogleSheetsSchemaModal } from './GoogleSheetsSchemaModal';
import { AdminMemberDashboard } from './members/AdminMemberDashboard';
import { MemberProfileDetail } from './members/MemberProfileDetail';
import { AdminPaymentApprovalsView } from './members/AdminPaymentApprovalsView';
import { ReceiptModal } from '../common/ReceiptModal';
import { memberService } from '../../services/memberService';
import { OfficialReceipt } from '../../types/member';

interface DashboardLayoutProps {
  lang: Language;
  onToggleLang: () => void;
  branding: BrandingSettings;
  formulaConfig: FinancialFormulaConfig;
  onSaveBranding: (updated: BrandingSettings) => void;
  onSaveFormulaConfig: (updated: FinancialFormulaConfig) => void;
  financialState: FinancialState;
  onUpdateFinancialState: (updated: FinancialState) => void;
  transactions: TransactionRecord[];
  approvals: ApprovalRequest[];
  dataMode: DataMode;
  onToggleDataMode: () => void;
  onLogout: () => void;
  onAddTransaction: (trx: TransactionRecord) => void;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  onRevisionRequest: (id: string) => void;
  onSubmitTransactionRequest: (data: {
    type: string;
    targetId: string;
    amount: number;
    paymentMethod: string;
    reference: string;
    notes: string;
  }) => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  lang,
  onToggleLang,
  branding,
  formulaConfig,
  onSaveBranding,
  onSaveFormulaConfig,
  financialState,
  onUpdateFinancialState,
  transactions,
  approvals,
  dataMode,
  onToggleDataMode,
  onLogout,
  onAddTransaction,
  onApproveRequest,
  onRejectRequest,
  onRevisionRequest,
  onSubmitTransactionRequest,
}) => {
  const [currentSection, setCurrentSection] = useState<SidebarSection>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [dateRange, setDateRange] = useState<DateRange>('month');
  const [showQuickActions, setShowQuickActions] = useState<boolean>(false);
  const [showSheetsSchema, setShowSheetsSchema] = useState<boolean>(false);

  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  const [activeReceipt, setActiveReceipt] = useState<OfficialReceipt | null>(null);

  const pendingApprovalsCount = 
    approvals.filter((a) => a.status === 'PENDING').length +
    memberService.getAllPaymentRequests().filter((p) => p.status === 'PENDING').length;

  const handleSelectSection = (section: SidebarSection) => {
    if (section === 'members') {
      setSelectedMemberId(null);
    }
    if (section === 'sheets_schema') {
      setShowSheetsSchema(true);
    } else {
      setCurrentSection(section);
    }
    setMobileMenuOpen(false);
  };

  return (
    <div
      className="min-h-screen flex flex-col lg:flex-row bg-[#F4F8FC] text-[#17212B] font-sans antialiased"
      style={{
        // Dynamically injected custom CSS variables from settings
        ['--color-primary-blue' as any]: branding.primaryBlue,
        ['--color-primary-green' as any]: branding.primaryGreen,
        backgroundColor: branding.lightBackground || '#F4F8FC',
        color: branding.darkText || '#17212B',
      }}
    >
      {/* Desktop Collapsible Sidebar */}
      <div className="hidden lg:flex shrink-0">
        <Sidebar
          currentSection={currentSection}
          onSelectSection={handleSelectSection}
          lang={lang}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          pendingApprovalsCount={pendingApprovalsCount}
          onLogout={onLogout}
          currentRole="SUPER_ADMIN"
          somitiNameBn={branding.banglaName}
          somitiNameEn={branding.englishName}
          logoUrl={branding.logoUrl}
        />
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="w-80 max-w-[85vw] h-full flex flex-col bg-slate-900 shadow-2xl">
            <Sidebar
              currentSection={currentSection}
              onSelectSection={handleSelectSection}
              lang={lang}
              collapsed={false}
              onToggleCollapse={() => setMobileMenuOpen(false)}
              pendingApprovalsCount={pendingApprovalsCount}
              onLogout={onLogout}
              currentRole="SUPER_ADMIN"
              somitiNameBn={branding.banglaName}
              somitiNameEn={branding.englishName}
              logoUrl={branding.logoUrl}
            />
          </div>
          <div className="flex-1" onClick={() => setMobileMenuOpen(false)}></div>
        </div>
      )}

      {/* Main Viewport Container */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Header Bar */}
        <HeaderBar
          currentSection={currentSection}
          lang={lang}
          onToggleLang={onToggleLang}
          dateRange={dateRange}
          onChangeDateRange={setDateRange}
          dataMode={dataMode}
          onToggleDataMode={onToggleDataMode}
          pendingCount={pendingApprovalsCount}
          onOpenQuickActions={() => setShowQuickActions(true)}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenApprovals={() => setCurrentSection('approvals')}
          currentRole="SUPER_ADMIN"
        />

        {/* Workspace Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {currentSection === 'dashboard' && (
            <DashboardMainView
              financialState={financialState}
              onUpdateFinancialState={onUpdateFinancialState}
              transactions={transactions}
              approvals={approvals}
              lang={lang}
              dateRange={dateRange}
              dataMode={dataMode}
              onOpenQuickActions={() => setShowQuickActions(true)}
              onApproveRequest={onApproveRequest}
              onRejectRequest={onRejectRequest}
              onRevisionRequest={onRevisionRequest}
            />
          )}

          {currentSection === 'members' && (
            selectedMemberId ? (
              <MemberProfileDetail
                memberId={selectedMemberId}
                lang={lang}
                branding={branding}
                onBack={() => setSelectedMemberId(null)}
                onViewReceipt={(rNo) => {
                  const r = memberService.getReceiptByNumber(rNo);
                  if (r) setActiveReceipt(r);
                }}
              />
            ) : (
              <AdminMemberDashboard
                lang={lang}
                branding={branding}
                onSelectMember={(id) => setSelectedMemberId(id)}
                onNavigateToApprovals={() => setCurrentSection('approvals')}
              />
            )
          )}

          {currentSection === 'approvals' && (
            <AdminPaymentApprovalsView
              lang={lang}
              onViewReceipt={(rNo) => {
                const r = memberService.getReceiptByNumber(rNo);
                if (r) setActiveReceipt(r);
              }}
            />
          )}

          {currentSection === 'settings' && (
            <SettingsView
              branding={branding}
              formulaConfig={formulaConfig}
              onSaveBranding={onSaveBranding}
              onSaveFormulaConfig={onSaveFormulaConfig}
              lang={lang}
            />
          )}

          {currentSection !== 'dashboard' &&
            currentSection !== 'settings' &&
            currentSection !== 'members' &&
            currentSection !== 'approvals' && (
              <ModuleDetailView
                section={currentSection}
                financialState={financialState}
                transactions={transactions}
                approvals={approvals}
                lang={lang}
                onOpenQuickActions={() => setShowQuickActions(true)}
              />
            )}
        </main>

        {/* Receipt Modal */}
        {activeReceipt && (
          <ReceiptModal
            receipt={activeReceipt}
            lang={lang}
            onClose={() => setActiveReceipt(null)}
          />
        )}

        {/* Admin Footer */}
        <footer className="py-4 px-6 border-t border-slate-200 bg-white/70 text-center text-xs text-slate-500 font-bengali">
          <span>{branding.footerText}</span>
          <span className="mx-2">·</span>
          <span>{branding.copyrightText}</span>
        </footer>
      </div>

      {/* Quick Actions Modal */}
      {showQuickActions && (
        <QuickActionsModal
          lang={lang}
          onClose={() => setShowQuickActions(false)}
          onSubmitTransactionRequest={(data) => {
            onSubmitTransactionRequest(data);
            setShowQuickActions(false);
          }}
        />
      )}

      {/* Google Sheets Schema Modal */}
      {showSheetsSchema && (
        <GoogleSheetsSchemaModal
          lang={lang}
          onClose={() => setShowSheetsSchema(false)}
        />
      )}
    </div>
  );
};
