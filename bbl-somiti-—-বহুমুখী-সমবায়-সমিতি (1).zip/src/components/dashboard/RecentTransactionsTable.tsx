import React, { useState } from 'react';
import {
  Receipt,
  Search,
  Filter,
  CheckCircle2,
  FileText,
  Printer,
  X,
  CreditCard,
  Building,
} from 'lucide-react';
import { TransactionRecord, Language } from '../../types/dashboard';
import { formatCurrency } from '../../utils/formatters';

interface RecentTransactionsTableProps {
  transactions: TransactionRecord[];
  lang: Language;
  onViewReceipt?: (trx: TransactionRecord) => void;
}

export const RecentTransactionsTable: React.FC<RecentTransactionsTableProps> = ({
  transactions,
  lang,
}) => {
  const isBn = lang === 'bn';
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTrx, setSelectedTrx] = useState<TransactionRecord | null>(null);

  const filteredTransactions = transactions.filter((t) => {
    const q = searchTerm.toLowerCase();
    return (
      t.id.toLowerCase().includes(q) ||
      t.referenceName.toLowerCase().includes(q) ||
      t.transactionType.toLowerCase().includes(q) ||
      t.paymentMethod.toLowerCase().includes(q) ||
      t.receiptNumber.toLowerCase().includes(q)
    );
  });

  return (
    <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
      {/* Header and Search */}
      <div className="p-5 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-700" />
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
              {isBn ? 'সর্বশেষ আর্থিক লেনদেন (Recent Posted Transactions)' : 'Recent Posted Transactions'}
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-bengali mt-0.5">
            {isBn
              ? 'ডাবল এন্ট্রি সাধারণ খতিয়ানে পোস্টকৃত যাচাইকৃত আর্থিক রসিদ ও ভাউচার'
              : 'Verified double-entry journal items successfully posted to the general ledger'}
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isBn ? 'আইডি, নাম বা রসিদ নং...' : 'Search TRX, Member, Receipt...'}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-bengali"
          />
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        {filteredTransactions.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500 font-bengali">
            {isBn ? 'কোনো লেনদেন রেকর্ড পাওয়া যায়নি।' : 'No transaction records found.'}
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider font-bengali">
                <th className="py-3 px-4">{isBn ? 'লেনদেন আইডি' : 'TRX ID'}</th>
                <th className="py-3 px-4">{isBn ? 'তারিখ ও সময়' : 'Date & Time'}</th>
                <th className="py-3 px-4">{isBn ? 'সদস্য / পার্টনার' : 'Member / Reference'}</th>
                <th className="py-3 px-4">{isBn ? 'লেনদেনের ধরন' : 'Transaction Type'}</th>
                <th className="py-3 px-4 text-right">{isBn ? 'পরিমাণ' : 'Amount'}</th>
                <th className="py-3 px-4">{isBn ? 'পদ্ধতি' : 'Method'}</th>
                <th className="py-3 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                <th className="py-3 px-4 text-center">{isBn ? 'রসিদ' : 'Receipt'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-bengali">
              {filteredTransactions.map((trx) => (
                <tr key={trx.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-blue-700 whitespace-nowrap">
                    {trx.id}
                  </td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                    <div>{trx.date}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{trx.timestamp}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-900 font-semibold">
                    <div>{trx.referenceName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{trx.referenceId}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-700 font-medium">
                    {trx.transactionType}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm whitespace-nowrap">
                    {formatCurrency(trx.amount, lang)}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold">
                      {trx.paymentMethod}
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{isBn ? 'পোস্টেড' : 'POSTED'}</span>
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <button
                      onClick={() => setSelectedTrx(trx)}
                      className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-800 text-[11px] font-bold transition-colors cursor-pointer inline-flex items-center gap-1"
                      title="View Voucher"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>{isBn ? 'ভাউচার' : 'Voucher'}</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal: Official Voucher / Receipt Details */}
      {selectedTrx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
            {/* Header */}
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest block font-bold">
                  BBL SOMITI OFFICIAL VOUCHER
                </span>
                <h3 className="text-lg font-bold font-display mt-0.5">
                  {isBn ? 'আর্থিক লেনদেন রসিদ ও অডিট রেকর্ড' : 'Transaction Receipt & Audit Voucher'}
                </h3>
              </div>
              <button
                onClick={() => setSelectedTrx(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Voucher Body */}
            <div className="p-6 space-y-4 text-xs font-bengali">
              <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                <div>
                  <span className="text-slate-500 block">{isBn ? 'রসিদ নং:' : 'Receipt No:'}</span>
                  <span className="font-mono font-bold text-slate-900 text-sm">{selectedTrx.receiptNumber}</span>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block">{isBn ? 'লেনদেন আইডি:' : 'Transaction ID:'}</span>
                  <span className="font-mono font-bold text-blue-700 text-sm">{selectedTrx.id}</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-center">
                <span className="text-slate-500 block text-[11px]">{isBn ? 'মোট লেনদেনকৃত পরিমাণ' : 'Total Amount Paid'}</span>
                <span className="text-2xl font-extrabold text-emerald-900 font-mono block mt-1">
                  {formatCurrency(selectedTrx.amount, lang)}
                </span>
                <span className="text-[11px] font-bold text-emerald-800 mt-1 block">
                  {selectedTrx.transactionType}
                </span>
              </div>

              <div className="space-y-2 text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'গ্রহীতা / রেফারেন্স:' : 'Reference:'}</span>
                  <span className="font-bold text-slate-900">{selectedTrx.referenceName} ({selectedTrx.referenceId})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'পেমেন্ট মাধ্যম:' : 'Payment Method:'}</span>
                  <span className="font-bold text-slate-900">{selectedTrx.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'ডেবিট হিসাব (খতিয়ান):' : 'Debit Ledger A/C:'}</span>
                  <span className="font-mono font-bold text-blue-800">{selectedTrx.debitAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'ক্রেডিট হিসাব (খতিয়ান):' : 'Credit Ledger A/C:'}</span>
                  <span className="font-mono font-bold text-emerald-800">{selectedTrx.creditAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'অনুমোদনকারী:' : 'Approved By:'}</span>
                  <span className="font-semibold text-slate-800">{selectedTrx.approvedBy || 'সুপার এডমিন'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">{isBn ? 'পোস্টিং অফিসার:' : 'Posted By:'}</span>
                  <span className="font-semibold text-slate-800">{selectedTrx.postedBy || 'সিস্টেম ক্যাশিয়ার'}</span>
                </div>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isBn ? 'রসিদ প্রিন্ট করুন' : 'Print Voucher'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTrx(null)}
                  className="py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold transition-colors cursor-pointer"
                >
                  {isBn ? 'বন্ধ করুন' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
