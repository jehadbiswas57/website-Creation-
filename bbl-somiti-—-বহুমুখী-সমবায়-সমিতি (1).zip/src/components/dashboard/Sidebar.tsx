import React from 'react';
import {
  LayoutDashboard,
  Users,
  Briefcase,
  HandCoins,
  PiggyBank,
  CircleDollarSign,
  Shield,
  UserCheck,
  CheckCircle2,
  FileCheck,
  BookOpen,
  FolderTree,
  Scale,
  Receipt,
  TrendingUp,
  Building2,
  Coins,
  ArrowDownToLine,
  FileSpreadsheet,
  FileText,
  Bell,
  UserCog,
  ShieldAlert,
  Settings,
  HelpCircle,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Database
} from 'lucide-react';
import { SidebarSection, Language, Role } from '../../types/dashboard';

interface SidebarProps {
  currentSection: SidebarSection;
  onSelectSection: (section: SidebarSection) => void;
  lang: Language;
  collapsed: boolean;
  onToggleCollapse: () => void;
  pendingApprovalsCount: number;
  onLogout: () => void;
  currentRole: Role;
  somitiNameBn: string;
  somitiNameEn: string;
  logoUrl: string | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  onSelectSection,
  lang,
  collapsed,
  onToggleCollapse,
  pendingApprovalsCount,
  onLogout,
  currentRole,
  somitiNameBn,
  somitiNameEn,
  logoUrl,
}) => {
  const isBn = lang === 'bn';

  const menuGroups = [
    {
      groupTitleBn: 'মূল ড্যাশবোর্ড',
      groupTitleEn: 'Overview',
      items: [
        { id: 'dashboard' as SidebarSection, icon: LayoutDashboard, labelBn: 'হোম ড্যাশবোর্ড', labelEn: 'Main Dashboard' },
        { id: 'approvals' as SidebarSection, icon: FileCheck, labelBn: 'অনুমোদন কেন্দ্র', labelEn: 'Approval Center', badge: pendingApprovalsCount },
        { id: 'verification' as SidebarSection, icon: CheckCircle2, labelBn: 'পেমেন্ট যাচাই', labelEn: 'Payment Verification' },
      ],
    },
    {
      groupTitleBn: 'সমিতি ও সদস্য কার্যক্রম',
      groupTitleEn: 'Cooperative Operations',
      items: [
        { id: 'members' as SidebarSection, icon: Users, labelBn: 'সদস্য তালিকা ও তথ্য', labelEn: 'Member Management' },
        { id: 'member_deposit' as SidebarSection, icon: ArrowDownToLine, labelBn: 'সদস্যের জমা গ্রহণ', labelEn: 'Member Deposit' },
        { id: 'partners' as SidebarSection, icon: Briefcase, labelBn: 'অংশীদার / পার্টনার', labelEn: 'Partner Management' },
        { id: 'partner_capital' as SidebarSection, icon: Coins, labelBn: 'পার্টনারদের মূলধন', labelEn: 'Partner Capital' },
        { id: 'loans' as SidebarSection, icon: HandCoins, labelBn: 'ঋণ কার্যক্রম', labelEn: 'Loan Management' },
        { id: 'savings' as SidebarSection, icon: PiggyBank, labelBn: 'সঞ্চয় হিসাব', labelEn: 'Savings Management' },
        { id: 'dps' as SidebarSection, icon: CircleDollarSign, labelBn: 'ডিপিএস হিসাব', labelEn: 'DPS Management' },
        { id: 'insurance' as SidebarSection, icon: Shield, labelBn: 'কল্যাণ ও বীমা তহবিল', labelEn: 'Insurance Management' },
        { id: 'admission' as SidebarSection, icon: UserCheck, labelBn: 'ভর্তি ফি হিসাব', labelEn: 'Admission Fees' },
        { id: 'business' as SidebarSection, icon: Building2, labelBn: 'ব্যবসায়িক প্রকল্প', labelEn: 'Business Management' },
      ],
    },
    {
      groupTitleBn: 'হিসাব ও খতিয়ান',
      groupTitleEn: 'Accounting & Ledger',
      items: [
        { id: 'cashbook' as SidebarSection, icon: BookOpen, labelBn: 'ক্যাশ বই (দৈনিক হিসাব)', labelEn: 'Cashbook' },
        { id: 'chart_of_accounts' as SidebarSection, icon: FolderTree, labelBn: 'হিসাবের কোড তালিকা', labelEn: 'Chart of Accounts' },
        { id: 'general_ledger' as SidebarSection, icon: Scale, labelBn: 'খতিয়ান বিবরণী', labelEn: 'General Ledger' },
        { id: 'transactions' as SidebarSection, icon: Receipt, labelBn: 'দৈনিক লেনদেন', labelEn: 'Transactions' },
        { id: 'income_expense' as SidebarSection, icon: TrendingUp, labelBn: 'আয় ও ব্যয় হিসাব', labelEn: 'Income & Expense' },
        { id: 'reports' as SidebarSection, icon: FileSpreadsheet, labelBn: 'আর্থিক প্রতিবেদন', labelEn: 'Reports & Statements' },
      ],
    },
    {
      groupTitleBn: 'সিস্টেম ও প্রশাসন',
      groupTitleEn: 'System Administration',
      items: [
        { id: 'sheets_schema' as SidebarSection, icon: Database, labelBn: 'স্প্রেডশিট ডেটাবেজ', labelEn: 'Sheets / DB Schema' },
        { id: 'documents' as SidebarSection, icon: FileText, labelBn: 'নথিপত্র ও ফাইল', labelEn: 'Documents & Files' },
        { id: 'notices' as SidebarSection, icon: Bell, labelBn: 'নোটিশ বোর্ড', labelEn: 'Notices & Messages' },
        { id: 'users' as SidebarSection, icon: UserCog, labelBn: 'ব্যবহারকারী ও রোল', labelEn: 'Users & Roles' },
        { id: 'audit_log' as SidebarSection, icon: ShieldAlert, labelBn: 'নিরাপত্তা ও অডিট লগ', labelEn: 'Audit Log' },
        { id: 'settings' as SidebarSection, icon: Settings, labelBn: 'সিস্টেম সেটিংস', labelEn: 'System Settings' },
        { id: 'help' as SidebarSection, icon: HelpCircle, labelBn: 'সহায়তা ও নির্দেশিকা', labelEn: 'Help & Support' },
      ],
    },
  ];

  return (
    <aside
      className={`relative flex flex-col bg-slate-900 text-slate-100 transition-all duration-300 border-r border-slate-800 select-none z-30 ${
        collapsed ? 'w-20' : 'w-72 sm:w-80'
      }`}
    >
      {/* Brand Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-800/80 bg-slate-950/60">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-white p-1 shadow-sm flex items-center justify-center shrink-0 overflow-hidden">
            {logoUrl ? (
              <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" />
            ) : (
              <div className="w-full h-full rounded-lg bg-emerald-700 flex items-center justify-center text-white font-extrabold text-sm">
                BBL
              </div>
            )}
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <h2 className="text-sm font-extrabold text-white tracking-tight truncate font-display">
                {isBn ? somitiNameBn : somitiNameEn}
              </h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                  {currentRole.replace('_', ' ')}
                </span>
              </div>
            </div>
          )}
        </div>

        <button
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors hidden lg:flex items-center justify-center cursor-pointer"
          title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 custom-scrollbar text-xs">
        {menuGroups.map((group, gIdx) => (
          <div key={gIdx} className="space-y-1">
            {!collapsed && (
              <p className="px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider font-bengali">
                {isBn ? group.groupTitleBn : group.groupTitleEn}
              </p>
            )}
            <div className="space-y-0.5 pt-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectSection(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium transition-all cursor-pointer ${
                      isActive
                        ? 'bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                    } ${collapsed ? 'justify-center' : 'justify-between'}`}
                    title={isBn ? item.labelBn : item.labelEn}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      {!collapsed && (
                        <span className="truncate font-bengali text-xs">
                          {isBn ? item.labelBn : item.labelEn}
                        </span>
                      )}
                    </div>
                    {!collapsed && item.badge !== undefined && item.badge > 0 && (
                      <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-500 text-slate-950">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom User Profile & Logout */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/70">
        <button
          onClick={onLogout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-rose-300 hover:text-white hover:bg-rose-950/40 transition-colors cursor-pointer ${
            collapsed ? 'justify-center' : ''
          }`}
          title={isBn ? 'লগআউট / প্রস্থান' : 'Logout / Exit'}
        >
          <LogOut className="w-4 h-4 shrink-0 text-rose-400" />
          {!collapsed && (
            <span className="font-bold text-xs font-bengali">
              {isBn ? 'লগআউট / লগইন পেজে ফিরুন' : 'Logout & Return to Login'}
            </span>
          )}
        </button>
      </div>
    </aside>
  );
};
