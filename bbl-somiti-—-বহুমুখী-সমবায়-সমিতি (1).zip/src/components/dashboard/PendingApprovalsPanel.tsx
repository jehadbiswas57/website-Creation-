import React, { useState } from 'react';
import {
  FileCheck,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  User,
  ArrowRight,
  ShieldCheck,
  Search,
} from 'lucide-react';
import { ApprovalRequest, Language } from '../../types/dashboard';
import { formatCurrency } from '../../utils/formatters';

interface PendingApprovalsPanelProps {
  approvals: ApprovalRequest[];
  lang: Language;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  onRevision: (id: string) => void;
}

export const PendingApprovalsPanel: React.FC<PendingApprovalsPanelProps> = ({
  approvals,
  lang,
  onApprove,
  onReject,
  onRevision,
}) => {
  const isBn = lang === 'bn';
  const [selectedType, setSelectedType] = useState<string>('ALL');

  const pendingList = approvals.filter((a) => a.status === 'PENDING');
  const filteredList = selectedType === 'ALL'
    ? pendingList
    : pendingList.filter((a) => a.type === selectedType);

  return (
    <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
      {/* Header */}
      <div className="p-5 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <FileCheck className="w-5 h-5 text-amber-600" />
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
              {isBn ? 'সুপার এডমিন অনুমোদন কেন্দ্র (Pending Approvals)' : 'Super Admin Approval Center'}
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-bengali mt-0.5">
            {isBn
              ? 'ঋণ, সঞ্চয় উত্তোলন, খরচের ভাউচার ও সদস্য আবেদনসমূহ অনুমোদনের অপেক্ষমাণ তালিকা'
              : 'Multi-signature queue for loans, withdrawals, expenses, and onboarding tickets'}
          </p>
        </div>

        <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold font-bengali self-start sm:self-auto">
          {pendingList.length} {isBn ? 'টি অনুমোদন বাকি' : 'Pending Requests'}
        </span>
      </div>

      {/* Filter Chips */}
      <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 text-xs font-bengali">
        <button
          onClick={() => setSelectedType('ALL')}
          className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
            selectedType === 'ALL' ? 'bg-slate-900 text-white font-bold' : 'bg-white text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isBn ? 'সব আবেদন' : 'All'}
        </button>
        <button
          onClick={() => setSelectedType('LOAN_REQUEST')}
          className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
            selectedType === 'LOAN_REQUEST' ? 'bg-slate-900 text-white font-bold' : 'bg-white text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isBn ? 'ঋণ আবেদন' : 'Loans'}
        </button>
        <button
          onClick={() => setSelectedType('SAVINGS_WITHDRAWAL')}
          className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
            selectedType === 'SAVINGS_WITHDRAWAL' ? 'bg-slate-900 text-white font-bold' : 'bg-white text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isBn ? 'সঞ্চয় উত্তোলন' : 'Withdrawals'}
        </button>
        <button
          onClick={() => setSelectedType('EXPENSE_REQUEST')}
          className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
            selectedType === 'EXPENSE_REQUEST' ? 'bg-slate-900 text-white font-bold' : 'bg-white text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isBn ? 'খরচ অনুমোদন' : 'Expenses'}
        </button>
        <button
          onClick={() => setSelectedType('MEMBER_APPLICATION')}
          className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
            selectedType === 'MEMBER_APPLICATION' ? 'bg-slate-900 text-white font-bold' : 'bg-white text-slate-600 hover:bg-slate-200'
          }`}
        >
          {isBn ? 'নতুন সদস্য' : 'Members'}
        </button>
      </div>

      {/* List */}
      <div className="divide-y divide-slate-100">
        {filteredList.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500 font-bengali">
            {isBn ? 'বর্তমানে কোনো অনুরোধ অনুমোদনের অপেক্ষায় নেই।' : 'No pending tickets awaiting approval.'}
          </div>
        ) : (
          filteredList.map((req) => (
            <div key={req.id} className="p-5 hover:bg-slate-50/70 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                    {req.id}
                  </span>
                  <span className="text-xs font-bold text-slate-900 font-bengali">
                    {req.applicantName} ({req.applicantId})
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {req.requestDate}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-bengali leading-relaxed">
                  {req.details}
                </p>
                <div className="text-[11px] text-slate-500 font-bengali flex items-center gap-2">
                  <span>{isBn ? 'দাখিলকারী:' : 'Submitted By:'} {req.submittedBy}</span>
                </div>
              </div>

              {/* Amount & Actions */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 shrink-0">
                {req.amount !== undefined && (
                  <div className="text-right sm:pr-4 sm:border-r border-slate-200">
                    <span className="text-[10px] text-slate-400 block font-bengali uppercase">
                      {isBn ? 'অনুরোধকৃত অর্থ' : 'Requested'}
                    </span>
                    <span className="text-base font-extrabold text-slate-900 font-mono">
                      {formatCurrency(req.amount, lang)}
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  {/* Approve */}
                  <button
                    onClick={() => onApprove(req.id)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer font-bengali"
                    title={isBn ? 'অনুমোদন দিন ও লেজারে পোস্ট করুন' : 'Approve & Post'}
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>{isBn ? 'অনুমোদন' : 'Approve'}</span>
                  </button>

                  {/* Revision */}
                  <button
                    onClick={() => onRevision(req.id)}
                    className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer font-bengali"
                    title={isBn ? 'সংশোধনের জন্য ফেরত পাঠান' : 'Request Revision'}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>{isBn ? 'সংশোধন' : 'Revision'}</span>
                  </button>

                  {/* Reject */}
                  <button
                    onClick={() => onReject(req.id)}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer font-bengali"
                    title={isBn ? 'প্রত্যাখ্যান করুন' : 'Reject'}
                  >
                    <XCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span>{isBn ? 'বাতিল' : 'Reject'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
