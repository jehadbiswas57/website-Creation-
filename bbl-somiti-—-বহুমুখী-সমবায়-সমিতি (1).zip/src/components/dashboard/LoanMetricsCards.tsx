import React from 'react';
import {
  HandCoins,
  ArrowUpRight,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  Calendar,
  Layers,
  Scale,
  FileCheck,
  Percent,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface LoanMetricsCardsProps {
  state: FinancialState;
  lang: Language;
}

export const LoanMetricsCards: React.FC<LoanMetricsCardsProps> = ({ state, lang }) => {
  const isBn = lang === 'bn';

  const recoveryRate = state.totalLoanDisbursed > 0
    ? Math.round((state.totalLoanPrincipalRecovered / state.totalLoanDisbursed) * 100)
    : 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'ঋণ ব্যবস্থাপনা ও আদায় মেট্রিক (Loan Management)' : 'Loan Portfolio & Recovery Metrics'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? 'বিতরণ, মূলধন আদায়, অর্জিত মুনাফা ও বকেয়ার পূর্ণাঙ্গ আলাদা হিসাব (মূলধন আদায়কে আয় হিসেবে গণ্য নয়)'
              : 'Complete breakdown of disbursement, principal recovery, earned profit, and overdue installments'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold text-blue-900 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
            {isBn ? `আদায় অগ্রগতি: ${recoveryRate}%` : `Recovery: ${recoveryRate}%`}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {/* 1. Total Loan Disbursed */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১. মোট ঋণ বিতরণ' : '1. Total Loan Disbursed'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <HandCoins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.totalLoanDisbursed, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সদস্যদের মাঝে মোট বিতরণকৃত মূলধন' : 'Cumulative loan capital disbursed'}
          </p>
        </div>

        {/* 2. Total Loan Principal Recovered */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '২. মোট ঋণ মূলধন আদায়' : '2. Principal Recovered'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 font-mono tabular-nums">
            {formatCurrency(state.totalLoanPrincipalRecovered, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'ফেরত প্রাপ্ত মূলধন (আয় নয়, ঋণ হ্রাস)' : 'Returned principal (asset reduction, not income)'}
          </p>
        </div>

        {/* 3. Total Loan Profit Recovered */}
        <div className="rounded-2xl p-4 sm:p-5 bg-emerald-50/50 border border-emerald-200/80 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider font-bengali">
              {isBn ? '৩. মোট ঋণের মুনাফা আদায়' : '3. Profit / Interest Recovered'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-900 font-mono tabular-nums">
            {formatCurrency(state.totalLoanProfitRecovered, lang)}
          </div>
          <p className="text-[11px] text-emerald-800/80 font-bengali">
            {isBn ? 'সমিতির প্রকৃত আয় হিসেবে স্বীকৃত মুনাফা' : 'Realized profit recognized as cooperative income'}
          </p>
        </div>

        {/* 4. Total Outstanding Loan Principal */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৪. মোট বকেয়া ঋণের মূলধন' : '4. Outstanding Principal'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-indigo-950 font-mono tabular-nums">
            {formatCurrency(state.totalOutstandingLoanPrincipal, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'বর্তমান অপরিশোধিত মূল ঋণ স্থিতি' : 'Remaining principal yet to be collected'}
          </p>
        </div>

        {/* 5. Pending Loan Applications */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৫. অনুমোদনের অপেক্ষায় ঋণ আবেদন' : '5. Pending Loan Requests'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-900 font-mono tabular-nums">
            {formatNumber(state.pendingLoanApplicationsCount, lang)} {isBn ? 'টি' : 'Files'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সুপার এডমিনের অনুমোদনের অপেক্ষায়' : 'Awaiting Super Admin credit committee review'}
          </p>
        </div>

        {/* 6. Approved Undisbursed Loans */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৬. অনুমোদিত কিন্তু অবিতরণকৃত' : '6. Approved Undisbursed'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <FileCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-sky-950 font-mono tabular-nums">
            {formatNumber(state.approvedUndisbursedLoansCount, lang)} {isBn ? 'টি' : 'Loans'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'অনুমোদিত, চেক বা ক্যাশ উত্তোলনের অপেক্ষায়' : 'Sanctioned, awaiting disbursement transfer'}
          </p>
        </div>

        {/* 7. Active Loans Count */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৭. চলমান ঋণের সংখ্যা' : '7. Active Loan Accounts'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-700 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatNumber(state.activeLoansCount, lang)} {isBn ? 'টি' : 'Accounts'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'নিয়মিত কিস্তি চলমান মোট ঋণ' : 'Regular active installment accounts'}
          </p>
        </div>

        {/* 8. Fully Paid Loans */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৮. সম্পূর্ণ পরিশোধিত ঋণ' : '8. Fully Paid Loans'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatNumber(state.fullyPaidLoansCount, lang)} {isBn ? 'টি' : 'Closed'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'শতভাগ কিস্তি ও মুনাফা পরিশোধিত' : 'Zero balance and successfully closed'}
          </p>
        </div>

        {/* 9. Overdue Loans */}
        <div className="rounded-2xl p-4 sm:p-5 bg-rose-50/60 border border-rose-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-rose-800 uppercase tracking-wider font-bengali">
              {isBn ? '৯. বকেয়া কিস্তি ও খেলাপী' : '9. Overdue & Defaulted'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-600 text-white flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-rose-900 font-mono tabular-nums">
            {formatCurrency(state.overdueInstallmentsAmount, lang)}
          </div>
          <p className="text-[11px] text-rose-800 font-bengali">
            {formatNumber(state.overdueLoansCount, lang)} {isBn ? 'টি অ্যাকাউন্টে বকেয়া' : 'Accounts with past-due installments'}
          </p>
        </div>

        {/* 10. Today Loan Collection */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১০. আজকের ঋণ আদায়' : '10. Today Loan Collection'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.todayLoanCollection, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'আজকের দিনে সংগৃহীত কিস্তি' : 'Installments collected today'}
          </p>
        </div>

        {/* 11. This Month Loan Collection */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১১. এই মাসের ঋণ আদায়' : '11. This Month Collection'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatCurrency(state.thisMonthLoanCollection, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'চলতি মাসের পুঞ্জীভূত ঋণ আদায়' : 'Cumulative collection for current calendar month'}
          </p>
        </div>

        {/* 12. Comparison metric */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-slate-900 to-blue-950 text-white shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-blue-300 font-bold uppercase tracking-wider font-bengali">
              {isBn ? '১২. বিতরণ বনাম আদায় রেশিও' : '12. Disbursement vs Recovery'}
            </span>
            <Scale className="w-4 h-4 text-blue-300" />
          </div>
          <div className="w-full bg-white/20 h-2.5 rounded-full overflow-hidden mt-2">
            <div
              className="bg-emerald-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(recoveryRate, 100)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[11px] font-mono pt-1 text-slate-300">
            <span>{isBn ? 'আদায়:' : 'Recovered:'} {recoveryRate}%</span>
            <span>{isBn ? 'বকেয়া:' : 'Remaining:'} {100 - recoveryRate}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};
