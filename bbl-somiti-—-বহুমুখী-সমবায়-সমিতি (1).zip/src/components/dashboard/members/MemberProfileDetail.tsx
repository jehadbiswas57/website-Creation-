import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  User,
  KeyRound,
  CreditCard,
  PiggyBank,
  FileText,
  ShieldCheck,
  Users,
  Calendar,
  Phone,
  MapPin,
  CheckCircle2,
  AlertCircle,
  Clock,
  Plus,
  Printer,
  Download,
  FileCheck,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  Upload,
  Lock,
  X,
  Loader2,
  Trash2,
  Archive,
  UserCheck,
  UserX,
  ShieldAlert,
  Info,
  Check,
  ExternalLink,
  DollarSign,
  FileSpreadsheet,
  Edit,
  RefreshCw,
} from 'lucide-react';
import { Language } from '../../../types';
import { MemberRecord, MemberLoan, PaymentRequest, OfficialReceipt } from '../../../types/member';
import { BrandingSettings } from '../../../types/dashboard';
import { memberService } from '../../../services/memberService';
import { calculateLoan, toBnNumber, LoanCalculationMethod } from '../../../services/loanCalculator';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

interface MemberProfileDetailProps {
  memberId: string;
  lang: Language;
  branding?: BrandingSettings;
  onBack: () => void;
  onViewReceipt?: (receiptNumber: string) => void;
}

export const MemberProfileDetail: React.FC<MemberProfileDetailProps> = ({
  memberId,
  lang,
  branding,
  onBack,
  onViewReceipt,
}) => {
  const isBn = lang === 'bn';
  const [activeTab, setActiveTab] = useState<'PERSONAL' | 'ADMISSION' | 'LOANS' | 'SAVINGS' | 'NOMINEE' | 'DOCS'>('LOANS');

  // Load Member & Associated Data
  const [member, setMember] = useState<MemberRecord | undefined>(() => memberService.getMemberById(memberId));
  const [loans, setLoans] = useState<MemberLoan[]>(() => memberService.getLoansByMemberId(memberId));
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>(() => memberService.getPaymentRequestsByMember(memberId));
  const [receipts, setReceipts] = useState<OfficialReceipt[]>(() => memberService.getReceiptsByMember(memberId));
  const [audits, setAudits] = useState(() => memberService.getAuditLogs().filter((a) => a.targetId === memberId));

  // Modals
  const [showApplyLoanModal, setShowApplyLoanModal] = useState(false);
  const [showAdminPaymentModal, setShowAdminPaymentModal] = useState(false);
  const [showUploadDocModal, setShowUploadDocModal] = useState(false);
  const [showEditMemberModal, setShowEditMemberModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteBlockReason, setDeleteBlockReason] = useState<string | null>(null);

  // Fee Waiver Modal State
  const [showWaiveModal, setShowWaiveModal] = useState<{ feeType: 'ADMISSION' | 'INSURANCE' | 'INITIAL_SAVINGS'; title: string } | null>(null);
  const [waiveReason, setWaiveReason] = useState('');

  // Apply Loan Calculator State
  const [loanAmount, setLoanAmount] = useState<number>(() => member?.requestedInitialLoanAmount || 50000);
  const [loanInstallmentCount, setLoanInstallmentCount] = useState<number>(12);
  const [loanProfitRate, setLoanProfitRate] = useState<number>(() => branding?.loanProfitRatePercent || 10);
  const [loanCalcMethod, setLoanCalcMethod] = useState<LoanCalculationMethod>(() => branding?.defaultLoanCalculationMethod || 'FLAT');
  const [loanFirstDate, setLoanFirstDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split('T')[0];
  });
  const [loanPurpose, setLoanPurpose] = useState<string>('ক্ষুদ্র ব্যবসা সম্প্রসারণ');
  const [loanMessage, setLoanMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  // Edit Loan Proposal State
  const [editLoanTarget, setEditLoanTarget] = useState<MemberLoan | null>(null);
  const [editLoanAmount, setEditLoanAmount] = useState<number>(50000);
  const [editLoanInstallmentCount, setEditLoanInstallmentCount] = useState<number>(12);
  const [editLoanProfitRate, setEditLoanProfitRate] = useState<number>(10);
  const [editLoanCalcMethod, setEditLoanCalcMethod] = useState<LoanCalculationMethod>('FLAT');
  const [editLoanFirstDate, setEditLoanFirstDate] = useState<string>('');
  const [editLoanPurpose, setEditLoanPurpose] = useState<string>('');
  const [editLoanReason, setEditLoanReason] = useState<string>('');

  // Member Consent Modal State
  const [consentTargetLoan, setConsentTargetLoan] = useState<MemberLoan | null>(null);
  const [consentNote, setConsentNote] = useState<string>('সদস্য কর্তৃক সকল আর্থিক শর্ত ও কিস্তির হিসাব পড়ে সম্মতি প্রদান করা হয়েছে।');
  const [consentAcknowledged, setConsentAcknowledged] = useState<boolean>(true);

  // Disburse Modal State
  const [disburseTargetLoan, setDisburseTargetLoan] = useState<MemberLoan | null>(null);
  const [disburseMethod, setDisburseMethod] = useState<'CASH' | 'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK'>('CASH');
  const [disburseRef, setDisburseRef] = useState<string>('');
  const [disburseNote, setDisburseNote] = useState<string>('');

  // Schedule Modal State
  const [scheduleTargetLoan, setScheduleTargetLoan] = useState<MemberLoan | null>(null);

  // Document Lightbox Preview State
  const [previewDoc, setPreviewDoc] = useState<{ url: string; title: string; category?: string } | null>(null);

  // Admin Payment Entry State
  const [payType, setPayType] = useState<'LOAN_INSTALLMENT' | 'SAVINGS_DEPOSIT' | 'ADMISSION_FEE' | 'INSURANCE_FEE'>('LOAN_INSTALLMENT');
  const [payAmount, setPayAmount] = useState<number>(1000);
  const [payMethod, setPayMethod] = useState<'CASH' | 'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK'>('CASH');
  const [payRef, setPayRef] = useState<string>('');
  const [isSubmittingPay, setIsSubmittingPay] = useState<boolean>(false);
  const [payFeedback, setPayFeedback] = useState<string | null>(null);

  // Doc Upload State
  const [uploadCategory, setUploadCategory] = useState<'MEMBER' | 'NOMINEE' | 'GUARANTOR'>('MEMBER');
  const [docType, setDocType] = useState<any>('MEMBER_AGREEMENT');
  const [docTitle, setDocTitle] = useState<string>('');
  const [docDataUrl, setDocDataUrl] = useState<string>('');

  // Edit Member State
  const [editForm, setEditForm] = useState({
    fullNameBn: member?.fullNameBn || '',
    fullNameEn: member?.fullNameEn || '',
    mobileNumber: member?.mobileNumber || '',
    nidNumber: member?.nidNumber || '',
    fatherOrHusbandName: member?.fatherOrHusbandName || '',
    motherName: member?.motherName || '',
    occupation: member?.occupation || '',
    address: member?.address || '',
  });

  // Fee Edit State
  const [showFeeEditModal, setShowFeeEditModal] = useState<boolean>(false);
  const [feeEditForm, setFeeEditForm] = useState({
    admissionFeeRequired: member?.admissionFeeRequired ?? 100,
    admissionFeePaid: member?.admissionFeePaid ?? 100,
    insuranceFeeRequired: member?.insuranceFeeRequired ?? 250,
    insuranceFeePaid: member?.insuranceFeePaid ?? 250,
    initialSavingsRequired: member?.initialSavingsRequired ?? 2500,
    initialSavingsPaid: member?.initialSavingsPaid ?? 2500,
  });

  const openFeeEditModal = () => {
    if (member) {
      setFeeEditForm({
        admissionFeeRequired: member.admissionFeeRequired,
        admissionFeePaid: member.admissionFeePaid,
        insuranceFeeRequired: member.insuranceFeeRequired,
        insuranceFeePaid: member.insuranceFeePaid,
        initialSavingsRequired: member.initialSavingsRequired,
        initialSavingsPaid: member.initialSavingsPaid,
      });
      setShowFeeEditModal(true);
    }
  };

  const refreshAll = () => {
    setMember(memberService.getMemberById(memberId));
    setLoans(memberService.getLoansByMemberId(memberId));
    setPaymentRequests(memberService.getPaymentRequestsByMember(memberId));
    setReceipts(memberService.getReceiptsByMember(memberId));
    setAudits(memberService.getAuditLogs().filter((a) => a.targetId === memberId));
  };

  const eligibility = useMemo(() => {
    return memberService.checkLoanEligibility(memberId);
  }, [member, memberId]);

  const allowedInstallments = useMemo(() => {
    return branding?.allowedLoanInstallments || [11, 11.5, 12, 12.5, 13, 15, 18, 24];
  }, [branding]);

  // Live calculation for Apply Loan Modal
  const newLoanCalc = useMemo(() => {
    return calculateLoan({
      principal: loanAmount,
      profitRatePercent: loanProfitRate,
      installmentCount: loanInstallmentCount,
      calculationMethod: loanCalcMethod,
      firstInstallmentDate: loanFirstDate,
    });
  }, [loanAmount, loanProfitRate, loanInstallmentCount, loanCalcMethod, loanFirstDate]);

  // Live calculation for Edit Loan Modal
  const editLoanCalc = useMemo(() => {
    return calculateLoan({
      principal: editLoanAmount,
      profitRatePercent: editLoanProfitRate,
      installmentCount: editLoanInstallmentCount,
      calculationMethod: editLoanCalcMethod,
      firstInstallmentDate: editLoanFirstDate || new Date().toISOString().split('T')[0],
    });
  }, [editLoanAmount, editLoanProfitRate, editLoanInstallmentCount, editLoanCalcMethod, editLoanFirstDate]);

  if (!member) {
    return (
      <div className="p-8 text-center space-y-4 rounded-3xl bg-white border border-slate-200 font-bengali">
        <p className="text-sm text-rose-600 font-bold">
          {isBn ? 'সদস্যের তথ্য খুঁজে পাওয়া যায়নি।' : 'Member record not found.'}
        </p>
        <button
          onClick={onBack}
          className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold cursor-pointer"
        >
          {isBn ? 'ফিরে যান' : 'Back'}
        </button>
      </div>
    );
  }

  // Handle Apply Loan Submission
  const handleApplyLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoanMessage(null);

    const applyRes = memberService.applyLoan(member.id, {
      requestedAmount: loanAmount,
      installmentCount: loanInstallmentCount,
      profitRatePercent: loanProfitRate,
      calculationMethod: loanCalcMethod,
      firstInstallmentDate: loanFirstDate,
      purpose: loanPurpose,
    });

    if (applyRes.success && applyRes.loan) {
      setLoanMessage({
        type: 'success',
        text: 'ঋণ আবেদন সফলভাবে দাখিল হয়েছে। অনুমোদনের পূর্বে সদস্যের সম্মতি নিশ্চিত করুন।',
      });
      refreshAll();
      setTimeout(() => {
        setShowApplyLoanModal(false);
        setLoanMessage(null);
      }, 1200);
    } else {
      setLoanMessage({ type: 'error', text: applyRes.message });
    }
  };

  // Open Edit Loan Modal
  const handleOpenEditLoan = (loan: MemberLoan) => {
    setEditLoanTarget(loan);
    setEditLoanAmount(loan.approvedAmount || loan.requestedAmount);
    setEditLoanInstallmentCount(loan.installmentCount || loan.totalInstallments || 12);
    setEditLoanProfitRate(loan.profitRatePercent || 10);
    setEditLoanCalcMethod(loan.calculationMethod || 'FLAT');
    setEditLoanFirstDate(loan.firstInstallmentDate || loan.nextInstallmentDueDate || new Date().toISOString().split('T')[0]);
    setEditLoanPurpose(loan.purpose || '');
    setEditLoanReason('');
  };

  // Submit Edit Loan Proposal
  const handleEditLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editLoanTarget) return;

    const res = memberService.updateLoanProposal(editLoanTarget.id, {
      requestedAmount: editLoanAmount,
      installmentCount: editLoanInstallmentCount,
      profitRatePercent: editLoanProfitRate,
      calculationMethod: editLoanCalcMethod,
      firstInstallmentDate: editLoanFirstDate,
      purpose: editLoanPurpose,
      actor: 'সুপার এডমিন (SA-01)',
      editReason: editLoanReason,
    });

    if (res.success) {
      alert('ঋণ প্রস্তাবনা ও কিস্তির হিসাব সফলভাবে হালনাগাদ করা হয়েছে। শর্ত পরিবর্তনের কারণে সদস্যের পুনরায় সম্মতি প্রয়োজন হবে।');
      refreshAll();
      setEditLoanTarget(null);
    } else {
      alert(res.message);
    }
  };

  // Record Member Consent
  const handleRecordConsent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consentTargetLoan) return;

    const res = memberService.recordMemberConsent(
      consentTargetLoan.id,
      'সুপার এডমিন (সদস্যের উপস্থিতিতে)',
      consentNote
    );

    if (res.success) {
      alert('সদস্যের আনুষ্ঠানিক ঋণ সম্মতিপত্র সফলভাবে রেকর্ড করা হয়েছে।');
      refreshAll();
      setConsentTargetLoan(null);
    } else {
      alert(res.message);
    }
  };

  // Open Disburse Modal
  const handleOpenDisburseModal = (loan: MemberLoan) => {
    if (!eligibility.isEligible) {
      alert(`ঋণ বিতরণ স্থগিত: লোন একাউন্ট অসম্পূর্ণ! ${eligibility.missingReasons.join(' · ')}। অনুগ্রহ করে পূর্বে ফি বা আমানত গ্রহণ অথবা মওকুফ করুন।`);
      return;
    }
    if (loan.memberConsentStatus !== 'CONSENTED') {
      alert('ঋণ বিতরণ স্থগিত: সদস্যের আনুষ্ঠানিক সম্মতি (Consent) এখনও রেকর্ড করা হয়নি। বিতরণের পূর্বে সদস্যের সম্মতি গ্রহণ করুন।');
      setConsentTargetLoan(loan);
      return;
    }
    setDisburseTargetLoan(loan);
    setDisburseMethod('CASH');
    setDisburseRef(`DISB-${Date.now().toString().slice(-6)}`);
    setDisburseNote('সুপার এডমিন চূড়ান্ত অনুমোদন ও বিতরণ');
  };

  // Submit Final Disbursement
  const handleFinalDisburseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disburseTargetLoan) return;

    const res = memberService.approveAndDisburseLoan(disburseTargetLoan.id, 'সুপার এডমিন (SA-01)', {
      disbursementMethod: disburseMethod,
      disbursementRef: disburseRef,
      notes: disburseNote,
    });

    if (res.success) {
      alert('ঋণ সফলভাবে অনুমোদিত হয়েছে এবং মূলধন বিতরণ সম্পন্ন হয়েছে। লেজারে লেনদেন ও ভাউচার পোস্টিং হয়েছে।');
      refreshAll();
      setDisburseTargetLoan(null);
    } else {
      alert(res.message);
    }
  };

  // Handle Fee Waiver Submit
  const handleWaiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showWaiveModal || !waiveReason.trim()) return;

    memberService.waiveFeeRequirement(member.id, showWaiveModal.feeType, 'সুপার এডমিন (SA-01)', waiveReason);
    refreshAll();
    setShowWaiveModal(null);
    setWaiveReason('');
  };

  // Handle Member Deletion
  const handleDeleteMember = () => {
    const res = memberService.deleteMember(member.id, 'সুপার এডমিন (SA-01)');
    if (res.canDelete) {
      alert(res.message);
      onBack();
    } else {
      setDeleteBlockReason(res.blockedReason || res.message);
    }
  };

  // Handle Deactivate / Archive / Activate
  const handleStatusChange = (newStatus: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED') => {
    if (newStatus === 'INACTIVE') {
      memberService.deactivateMember(member.id, 'সুপার এডমিন (SA-01)');
    } else if (newStatus === 'ARCHIVED') {
      memberService.archiveMember(member.id, 'সুপার এডমিন (SA-01)');
    } else {
      memberService.reactivateMember(member.id, 'সুপার এডমিন (SA-01)');
    }
    refreshAll();
  };

  // Handle Edit Member
  const handleEditMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    memberService.updateMember(member.id, editForm, 'সুপার এডমিন (SA-01)');
    refreshAll();
    setShowEditMemberModal(false);
  };

  // Handle Doc Upload Submit
  const handleDocUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !docDataUrl) return;

    memberService.addMemberDocument(
      member.id,
      {
        type: docType,
        category: uploadCategory,
        title: docTitle,
        fileUrl: docDataUrl,
        uploadedBy: 'সুপার এডমিন (SA-01)',
      },
      'সুপার এডমিন (SA-01)'
    );

    refreshAll();
    setShowUploadDocModal(false);
    setDocTitle('');
    setDocDataUrl('');
  };

  // Document Categorization
  const memberDocs = member.documents.filter((d) => d.category === 'MEMBER' || d.type.startsWith('MEMBER'));
  const nomineeDocs = member.documents.filter((d) => d.category === 'NOMINEE' || d.type.startsWith('NOMINEE'));
  const guarantorDocs = member.documents.filter((d) => d.category === 'GUARANTOR' || d.type.startsWith('GUARANTOR'));

  return (
    <div className="space-y-6 font-bengali">
      {/* Top Header & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold cursor-pointer transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{isBn ? 'সদস্য তালিকায় ফিরে যান' : 'Back to Member List'}</span>
        </button>

        {/* Admin Controls on Member Record */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowEditMemberModal(true)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5" />
            <span>{isBn ? 'তথ্য সম্পাদনা' : 'Edit Member'}</span>
          </button>

          {member.status === 'ACTIVE' ? (
            <button
              onClick={() => handleStatusChange('INACTIVE')}
              className="px-3 py-1.5 rounded-xl border border-amber-300 hover:bg-amber-50 text-amber-800 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <UserX className="w-3.5 h-3.5 text-amber-600" />
              <span>{isBn ? 'নিষ্ক্রিয় করুন' : 'Deactivate'}</span>
            </button>
          ) : (
            <button
              onClick={() => handleStatusChange('ACTIVE')}
              className="px-3 py-1.5 rounded-xl border border-emerald-300 hover:bg-emerald-50 text-emerald-800 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isBn ? 'পুনরায় সক্রিয়' : 'Reactivate'}</span>
            </button>
          )}

          {member.status !== 'ARCHIVED' && (
            <button
              onClick={() => handleStatusChange('ARCHIVED')}
              className="px-3 py-1.5 rounded-xl border border-purple-300 hover:bg-purple-50 text-purple-800 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Archive className="w-3.5 h-3.5 text-purple-600" />
              <span>{isBn ? 'আর্কাইভ করুন' : 'Archive'}</span>
            </button>
          )}

          <button
            onClick={() => {
              setShowDeleteModal(true);
              setDeleteBlockReason(null);
            }}
            className="px-3 py-1.5 rounded-xl border border-rose-300 hover:bg-rose-50 text-rose-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-600" />
            <span>{isBn ? 'সদস্য ডিলিট' : 'Delete Member'}</span>
          </button>

          <button
            onClick={() => setShowAdminPaymentModal(true)}
            className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? 'পেমেন্ট এন্ট্রি' : 'Log Payment'}</span>
          </button>
        </div>
      </div>

      {/* Premium Banking Header Profile Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          {/* Member Identity Details */}
          <div className="flex items-start gap-4 sm:gap-5">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-slate-100 overflow-hidden shrink-0 flex items-center justify-center font-extrabold text-slate-600 text-2xl border-2 border-slate-200 shadow-inner">
              {member.photoUrl ? (
                <img src={member.photoUrl} alt={member.fullNameBn} className="w-full h-full object-cover" />
              ) : (
                <span>{member.fullNameBn.slice(0, 1)}</span>
              )}
            </div>
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display">
                  {member.fullNameBn}
                </h2>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold font-mono ${
                    member.status === 'ACTIVE'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : member.status === 'ARCHIVED'
                      ? 'bg-purple-100 text-purple-800 border border-purple-300'
                      : 'bg-slate-100 text-slate-700 border border-slate-300'
                  }`}
                >
                  {member.status}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono">
                {member.fullNameEn} · <span className="font-bold text-blue-700">{member.id}</span>
              </p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 pt-1">
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <strong className="font-mono">{member.mobileNumber}</strong>
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{isBn ? 'ভর্তির তারিখ:' : 'Joined:'} {member.admissionDate}</span>
                </span>
                <span className="flex items-center gap-1">
                  <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                  <span>
                    {isBn ? 'ইউজার আইডি:' : 'User ID:'}{' '}
                    <strong className="font-mono text-emerald-800">
                      {member.userId || (isBn ? 'তৈরি করা হয়নি' : 'None')}
                    </strong>
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Key Financial Snapshot Pill */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-center">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">
                {isBn ? 'মোট ঋণ' : 'Total Loan'}
              </span>
              <span className="text-sm sm:text-base font-extrabold font-mono text-blue-900 mt-0.5 block tabular-nums">
                {formatCurrency(member.totalLoanDisbursedAmount, lang)}
              </span>
            </div>
            <div className="border-x border-slate-200 px-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">
                {isBn ? 'মোট পরিশোধ' : 'Total Repaid'}
              </span>
              <span className="text-sm sm:text-base font-extrabold font-mono text-emerald-800 mt-0.5 block tabular-nums">
                {formatCurrency(member.totalLoanPrincipalPaid + member.totalLoanProfitPaid, lang)}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">
                {isBn ? 'বর্তমান বকেয়া' : 'Outstanding'}
              </span>
              <span className="text-sm sm:text-base font-extrabold font-mono text-amber-900 mt-0.5 block tabular-nums">
                {formatCurrency(member.currentLoanOutstanding, lang)}
              </span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 overflow-x-auto border-t border-slate-200 pt-4 scrollbar-none">
          {[
            { id: 'LOANS', labelBn: 'লোন ব্যবস্থাপনা ও অনুমোদন', labelEn: 'Loan Approval' },
            { id: 'ADMISSION', labelBn: 'ভর্তি ফি ও প্রাথমিক আমানত', labelEn: 'Admission & Fees' },
            { id: 'DOCS', labelBn: 'নথিপত্র ও ডকুমেন্টস', labelEn: 'Documents' },
            { id: 'PERSONAL', labelBn: 'ব্যক্তিগত তথ্য', labelEn: 'Personal Info' },
            { id: 'SAVINGS', labelBn: 'সঞ্চয় ও লেজার খতিয়ান', labelEn: 'Savings & Ledger' },
            { id: 'NOMINEE', labelBn: 'নমিনী ও জামিনদার', labelEn: 'Nominee & Guarantor' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {isBn ? tab.labelBn : tab.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: LOAN MANAGEMENT & DIRECT APPROVAL FROM PROFILE */}
      {activeTab === 'LOANS' && (
        <div className="space-y-6">
          {/* Loan Eligibility & Readiness Banner */}
          <div
            className={`p-5 rounded-3xl border ${
              eligibility.isEligible
                ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                : 'bg-amber-50/80 border-amber-300 text-amber-950'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                {eligibility.isEligible ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm sm:text-base">
                      {eligibility.isEligible
                        ? 'লোন অ্যাকাউন্ট সম্পূর্ণ ও বিতরণের জন্য প্রস্তুত'
                        : 'লোন অ্যাকাউন্ট অসম্পূর্ণ (Incomplete) — চূড়ান্ত অনুমোদন ও বিতরণ স্থগিত'}
                    </h4>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        eligibility.isEligible
                          ? 'bg-emerald-200 text-emerald-900'
                          : 'bg-amber-200 text-amber-900'
                      }`}
                    >
                      {eligibility.isEligible ? 'READY TO DISBURSE' : 'INCOMPLETE'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed">
                    {eligibility.isEligible
                      ? 'ভর্তি ফি, ইনস্যুরেন্স ফান্ড এবং প্রাথমিক বাধ্যতামূলক সঞ্চয় সম্পন্ন হয়েছে। সুপার এডমিন সরাসরি লোন অনুমোদন ও বিতরণ করতে পারবেন।'
                      : 'সমিতির আর্থিক নীতিমালা অনুযায়ী ভর্তি ফি, ইনস্যুরেন্স ফান্ড এবং বাধ্যতামূলক প্রাথমিক সঞ্চয় সম্পন্ন না হওয়া পর্যন্ত লোন বিতরণ করা নিষিদ্ধ।'}
                  </p>

                  {!eligibility.isEligible && (
                    <div className="pt-1 text-xs text-amber-900 font-semibold space-y-0.5">
                      <span className="block text-[11px] text-amber-800">বকেয়া খাতের তালিকা:</span>
                      {eligibility.missingReasons.map((reason, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                          <span>{reason}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setShowApplyLoanModal(true)}
                  className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-sm cursor-pointer"
                >
                  + নতুন লোন আবেদন / অনুমোদন
                </button>
              </div>
            </div>
          </div>

          {/* Active Loans & Pending Applications */}
          {loans.length === 0 ? (
            <div className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-2xs text-center space-y-3">
              <CreditCard className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="font-bold text-slate-800 text-sm">এই সদস্যের কোনো লোন ফাইল নেই</h4>
              <p className="text-xs text-slate-500">
                উপরের বাটনে ক্লিক করে নতুন লোন আবেদন দাখিল বা অনুমোদন করতে পারেন।
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {loans.map((loan) => {
                const isFractional = loan.installmentCount ? loan.installmentCount % 1 !== 0 : false;
                const isConsented = loan.memberConsentStatus === 'CONSENTED';
                const canDisburse = (loan.loanStatus === 'SUBMITTED' || loan.loanStatus === 'PENDING_APPROVAL');

                return (
                  <div key={loan.id} className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-5">
                    {/* Loan Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                          {loan.id}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">{loan.purpose}</h4>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Consent Badge */}
                        {isConsented ? (
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-800 border border-teal-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                            <span>সম্মতি প্রাপ্ত</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>সম্মতি অপেক্ষমান</span>
                          </span>
                        )}

                        {/* Loan Status Badge */}
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold font-mono ${
                            loan.loanStatus === 'ACTIVE'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : loan.loanStatus === 'COMPLETED'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800 border border-amber-300'
                          }`}
                        >
                          {loan.loanStatus}
                        </span>
                      </div>
                    </div>

                    {/* Loan Key Metrics Grid (6 Cards) */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-0.5">
                        <span className="text-slate-500 block">অনুমোদিত মূলধন:</span>
                        <span className="font-mono font-bold text-blue-900 text-sm">
                          {formatCurrency(loan.approvedAmount, lang)}
                        </span>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-0.5">
                        <span className="text-slate-500 block">মোট মুনাফা:</span>
                        <span className="font-mono font-bold text-emerald-700 text-sm">
                          + {formatCurrency(loan.totalProfitAmount || Math.max(0, loan.totalPayableAmount - loan.approvedAmount), lang)}
                        </span>
                      </div>

                      <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-200 space-y-0.5">
                        <span className="text-blue-900 block font-bold">মোট পরিশোধযোগ্য:</span>
                        <span className="font-mono font-extrabold text-blue-950 text-sm">
                          {formatCurrency(loan.totalPayableAmount, lang)}
                        </span>
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-0.5">
                        <span className="text-slate-500 block">কিস্তির সংখ্যা:</span>
                        <span className="font-bold text-slate-800 text-sm block">
                          {toBnNumber(loan.installmentCount || loan.totalInstallments)} কিস্তি
                        </span>
                        {isFractional && (
                          <span className="text-[10px] text-amber-700 block font-semibold">
                            (পূর্ণ ও শেষ অর্ধেক কিস্তি)
                          </span>
                        )}
                      </div>

                      <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-0.5">
                        <span className="text-slate-500 block">মাসিক কিস্তি:</span>
                        <span className="font-mono font-bold text-emerald-800 text-sm">
                          {formatCurrency(loan.regularInstallmentAmount || loan.monthlyInstallmentAmount, lang)}
                        </span>
                      </div>
                    </div>

                    {/* Progress / Status Bar */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50/80 p-3 rounded-2xl border border-slate-200 font-mono">
                      <div>
                        <span className="text-slate-500 text-[11px] block">মূলধন আদায়:</span>
                        <span className="font-bold text-emerald-800">{formatCurrency(loan.totalPrincipalRepaid, lang)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[11px] block">বকেয়া মূলধন:</span>
                        <span className="font-bold text-amber-900">{formatCurrency(loan.outstandingPrincipal, lang)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[11px] block">পরিশোধিত কিস্তি:</span>
                        <span className="font-bold text-slate-800">{loan.installmentsPaidCount} / {loan.totalInstallments}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[11px] block">পরবর্তী কিস্তির তারিখ:</span>
                        <span className="font-bold text-blue-700">{loan.nextInstallmentDueDate || '—'}</span>
                      </div>
                    </div>

                    {/* Action Buttons Footer */}
                    <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setScheduleTargetLoan(loan)}
                        className="px-3.5 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-blue-600" />
                        <span>পরিশোধের সময়সূচি দেখুন</span>
                      </button>

                      {canDisburse && (
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenEditLoan(loan)}
                            className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                          >
                            <Edit className="w-3.5 h-3.5 text-slate-600" />
                            <span>হিসাব ও শর্ত সম্পাদনা</span>
                          </button>

                          {!isConsented && (
                            <button
                              type="button"
                              onClick={() => setConsentTargetLoan(loan)}
                              className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>সদস্যের সম্মতি গ্রহণ</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => handleOpenDisburseModal(loan)}
                            disabled={!eligibility.isEligible || !isConsented}
                            title={
                              !eligibility.isEligible
                                ? 'লোন অ্যাকাউন্ট অসম্পূর্ণ'
                                : !isConsented
                                ? 'সদস্যের সম্মতি এখনও গ্রহণ করা হয়নি'
                                : 'চূড়ান্ত অনুমোদন ও বিতরণ করুন'
                            }
                            className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                            <span>চূড়ান্ত অনুমোদন ও বিতরণ</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ADMISSION FEES & INITIAL DEPOSITS (AUTO CALCULATED & EDITABLE) */}
      {activeTab === 'ADMISSION' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                ভর্তি ফি, ইনস্যুরেন্স ফান্ড ও প্রাথমিক আমানত স্থিতি
              </h3>
              <p className="text-xs text-slate-500">
                আবেদনকৃত লোনের পরিমাণের ভিত্তিতে স্বয়ংক্রিয় হিসাব এবং পরিশোধিত ব্যালেন্স
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-3 py-1.5 rounded-xl border border-blue-200">
                আবেদনকৃত লোন: ৳{member.requestedInitialLoanAmount || 50000}
              </div>
              <button
                type="button"
                onClick={() => {
                  const rate = branding?.insuranceRatePercent ?? 0.5;
                  const res = memberService.recalculateMemberInsuranceFee(member.id, rate);
                  if (res.success) {
                    refreshAll();
                  }
                }}
                className="px-3 py-1.5 rounded-xl border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                title="বর্তমান সেটিং অনুযায়ী ইনস্যুরেন্স ফি হিসাব হালনাগাদ করুন"
              >
                <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                <span>সেটিংস পুনঃহিসাব ({branding?.insuranceRatePercent ?? 0.5}%)</span>
              </button>
              <button
                type="button"
                onClick={openFeeEditModal}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>অনুমোদিত খাত সম্পাদনা</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
            {/* 1. Admission Fee */}
            <div className="p-5 rounded-3xl border border-slate-200 space-y-3 bg-slate-50/70">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">ভর্তি ফি (Admission Fee)</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                    member.admissionFeeStatus === 'PAID' || member.admissionFeeWaived
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {member.admissionFeeWaived ? 'WAIVED' : member.admissionFeeStatus}
                </span>
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">নির্ধারিত টাকা:</span>
                  <span className="font-mono font-bold">৳{member.admissionFeeRequired}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">পরিশোধিত টাকা:</span>
                  <span className="font-mono font-bold text-emerald-800">৳{member.admissionFeePaid}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">বাকি টাকা:</span>
                  <span className="font-mono font-bold text-rose-600">
                    ৳{Math.max(0, member.admissionFeeRequired - member.admissionFeePaid)}
                  </span>
                </div>
              </div>
              {!member.admissionFeeWaived && member.admissionFeeStatus !== 'PAID' && (
                <button
                  onClick={() => setShowWaiveModal({ feeType: 'ADMISSION', title: 'ভর্তি ফি মওকুফ' })}
                  className="w-full mt-2 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-[11px] font-bold cursor-pointer"
                >
                  ফি মওকুফ অনুমোদন (Waive)
                </button>
              )}
            </div>

            {/* 2. Insurance Fund */}
            <div className="p-5 rounded-3xl border border-slate-200 space-y-3 bg-slate-50/70">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">ইনস্যুরেন্স ফান্ড (Insurance)</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                    member.insuranceStatus === 'PAID' || member.insuranceFeeWaived
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {member.insuranceFeeWaived ? 'WAIVED' : member.insuranceStatus}
                </span>
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">নির্ধারিত টাকা:</span>
                  <span className="font-mono font-bold">৳{member.insuranceFeeRequired}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">পরিশোধিত টাকা:</span>
                  <span className="font-mono font-bold text-emerald-800">৳{member.insuranceFeePaid}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">বাকি টাকা:</span>
                  <span className="font-mono font-bold text-rose-600">
                    ৳{Math.max(0, member.insuranceFeeRequired - member.insuranceFeePaid)}
                  </span>
                </div>
              </div>
              {!member.insuranceFeeWaived && member.insuranceStatus !== 'PAID' && (
                <button
                  onClick={() => setShowWaiveModal({ feeType: 'INSURANCE', title: 'ইনস্যুরেন্স ফান্ড মওকুফ' })}
                  className="w-full mt-2 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-[11px] font-bold cursor-pointer"
                >
                  ফান্ড মওকুফ অনুমোদন (Waive)
                </button>
              )}
            </div>

            {/* 3. Initial Savings */}
            <div className="p-5 rounded-3xl border border-slate-200 space-y-3 bg-slate-50/70">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800">বাধ্যতামূলক সঞ্চয় (Savings)</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                    member.initialSavingsStatus === 'PAID' || member.initialSavingsWaived
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {member.initialSavingsWaived ? 'WAIVED' : member.initialSavingsStatus}
                </span>
              </div>
              <div className="space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">নির্ধারিত টাকা:</span>
                  <span className="font-mono font-bold">৳{member.initialSavingsRequired}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">পরিশোধিত টাকা:</span>
                  <span className="font-mono font-bold text-emerald-800">৳{member.initialSavingsPaid}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">বাকি টাকা:</span>
                  <span className="font-mono font-bold text-rose-600">
                    ৳{Math.max(0, member.initialSavingsRequired - member.initialSavingsPaid)}
                  </span>
                </div>
              </div>
              {!member.initialSavingsWaived && member.initialSavingsStatus !== 'PAID' && (
                <button
                  onClick={() => setShowWaiveModal({ feeType: 'INITIAL_SAVINGS', title: 'প্রাথমিক সঞ্চয় মওকুফ' })}
                  className="w-full mt-2 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 text-[11px] font-bold cursor-pointer"
                >
                  সঞ্চয় শর্ত মওকুফ (Waive)
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DOCUMENTS (MEMBER, NOMINEE, GUARANTOR FULL CATEGORIZED STORAGE) */}
      {activeTab === 'DOCS' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                সদস্য, নমিনী ও জামিনদারের সংরক্ষিত নথিপত্র (Documents)
              </h3>
              <p className="text-xs text-slate-500">
                প্রতিটি নথি নির্দিষ্ট সদস্য আইডির সঙ্গে স্থায়ীভাবে সংরক্ষিত ও সুরক্ষিত
              </p>
            </div>
            <button
              onClick={() => setShowUploadDocModal(true)}
              className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Upload className="w-4 h-4" />
              <span>+ নতুন ডকুমেন্ট যুক্ত করুন</span>
            </button>
          </div>

          {/* Section A: Member's Own Documents */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider border-b border-slate-200 pb-2">
              ১. সদস্যের নিজস্ব ডকুমেন্টস
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              {/* Profile Photo */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">সদস্যের ছবি (প্রোফাইল)</span>
                {member.photoUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.photoUrl}
                      alt="Member"
                      onClick={() => setPreviewDoc({ url: member.photoUrl!, title: `${member.fullNameBn} - প্রোফাইল ছবি` })}
                      className="w-20 h-20 rounded-xl object-cover border border-slate-300 cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.photoUrl!, title: `${member.fullNameBn} - প্রোফাইল ছবি` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              {/* Agreement Paper */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">চুক্তিপত্র / এগ্রিমেন্ট পেপার</span>
                {member.agreementDocUrl ? (
                  <div className="space-y-2">
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> সংরক্ষিত আছে
                    </span>
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.agreementDocUrl!, title: `${member.fullNameBn} - চুক্তিপত্র / এগ্রিমেন্ট পেপার` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      চুক্তিপত্র ফাইল দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              {/* NID Front */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">ভোটার আইডি (সামনের অংশ)</span>
                {member.nidFrontUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.nidFrontUrl}
                      alt="NID Front"
                      onClick={() => setPreviewDoc({ url: member.nidFrontUrl!, title: `${member.fullNameBn} - ভোটার আইডি (সামনের অংশ)` })}
                      className="w-full h-20 rounded-xl object-cover border border-slate-300 cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.nidFrontUrl!, title: `${member.fullNameBn} - ভোটার আইডি (সামনের অংশ)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              {/* NID Back */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">ভোটার আইডি (পেছনের অংশ)</span>
                {member.nidBackUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.nidBackUrl}
                      alt="NID Back"
                      onClick={() => setPreviewDoc({ url: member.nidBackUrl!, title: `${member.fullNameBn} - ভোটার আইডি (পেছনের অংশ)` })}
                      className="w-full h-20 rounded-xl object-cover border border-slate-300 cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.nidBackUrl!, title: `${member.fullNameBn} - ভোটার আইডি (পেছনের অংশ)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>
            </div>
          </div>

          {/* Section B: Nominee Documents */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-purple-900 uppercase tracking-wider border-b border-slate-200 pb-2">
              ২. নমিনীর ডকুমেন্টস ({member.nominee?.name || 'তথ্য নেই'})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">নমিনীর ছবি</span>
                {member.nominee?.photoUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.nominee.photoUrl}
                      alt="Nominee"
                      onClick={() => setPreviewDoc({ url: member.nominee!.photoUrl!, title: `নমিনী (${member.nominee?.name}) - ছবি` })}
                      className="w-20 h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.nominee!.photoUrl!, title: `নমিনী (${member.nominee?.name}) - ছবি` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">নমিনীর ভোটার আইডি (সামনে)</span>
                {member.nominee?.nidFrontUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.nominee.nidFrontUrl}
                      alt="Nominee NID Front"
                      onClick={() => setPreviewDoc({ url: member.nominee!.nidFrontUrl!, title: `নমিনী (${member.nominee?.name}) - NID (সামনে)` })}
                      className="w-full h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.nominee!.nidFrontUrl!, title: `নমিনী (${member.nominee?.name}) - NID (সামনে)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">নমিনীর ভোটার আইডি (পেছনে)</span>
                {member.nominee?.nidBackUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.nominee.nidBackUrl}
                      alt="Nominee NID Back"
                      onClick={() => setPreviewDoc({ url: member.nominee!.nidBackUrl!, title: `নমিনী (${member.nominee?.name}) - NID (পেছনে)` })}
                      className="w-full h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.nominee!.nidBackUrl!, title: `নমিনী (${member.nominee?.name}) - NID (পেছনে)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>
            </div>
          </div>

          {/* Section C: Guarantor Documents */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h4 className="text-xs font-bold text-teal-900 uppercase tracking-wider">
                ৩. জামিনদার (Guarantor)-এর ডকুমেন্টস ({member.guarantor?.name || 'তথ্য নেই'})
              </h4>
              {member.guarantor?.memberId && (
                <span className="text-xs font-mono font-bold text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded border border-teal-200">
                  মেম্বার আইডি: {member.guarantor.memberId}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">জামিনদারের ছবি</span>
                {member.guarantor?.photoUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.guarantor.photoUrl}
                      alt="Guarantor"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.photoUrl!, title: `জামিনদার (${member.guarantor?.name}) - ছবি` })}
                      className="w-20 h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.photoUrl!, title: `জামিনদার (${member.guarantor?.name}) - ছবি` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">জামিনদারের NID (সামনের অংশ)</span>
                {member.guarantor?.nidFrontUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.guarantor.nidFrontUrl}
                      alt="Guarantor NID Front"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.nidFrontUrl!, title: `জামিনদার (${member.guarantor?.name}) - NID (সামনের অংশ)` })}
                      className="w-full h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.nidFrontUrl!, title: `জামিনদার (${member.guarantor?.name}) - NID (সামনের অংশ)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block">জামিনদারের NID (পেছনের অংশ)</span>
                {member.guarantor?.nidBackUrl ? (
                  <div className="space-y-2">
                    <img
                      src={member.guarantor.nidBackUrl}
                      alt="Guarantor NID Back"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.nidBackUrl!, title: `জামিনদার (${member.guarantor?.name}) - NID (পেছনের অংশ)` })}
                      className="w-full h-20 rounded-xl object-cover border cursor-pointer hover:opacity-90"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewDoc({ url: member.guarantor!.nidBackUrl!, title: `জামিনদার (${member.guarantor?.name}) - NID (পেছনের অংশ)` })}
                      className="text-blue-700 underline text-[11px] block text-left cursor-pointer"
                    >
                      পূর্ণ আকারে দেখুন
                    </button>
                  </div>
                ) : (
                  <span className="text-slate-400 text-[11px] block">ডকুমেন্ট আপলোড করা হয়নি</span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PERSONAL INFORMATION */}
      {activeTab === 'PERSONAL' && (
        <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-6">
          <div className="border-b border-slate-200 pb-3 flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-900">
              সদস্যের ব্যক্তিগত পরিচিতি ও ঠিকানা
            </h3>
            <span className="text-xs font-mono font-bold text-blue-700">{member.id}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">পূর্ণ নাম (বাংলা):</span>
              <span className="text-slate-900 font-extrabold text-sm block">{member.fullNameBn}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">Full Name (English):</span>
              <span className="text-slate-900 font-bold font-mono text-sm block">{member.fullNameEn}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">মোবাইল নম্বর:</span>
              <span className="text-slate-900 font-bold font-mono text-sm block">{member.mobileNumber}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">জাতীয় পরিচয়পত্র (NID):</span>
              <span className="text-slate-900 font-bold font-mono text-sm block">{member.nidNumber}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">পিতা / স্বামীর নাম:</span>
              <span className="text-slate-900 font-semibold block">{member.fatherOrHusbandName || 'তথ্য নেই'}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">মাতার নাম:</span>
              <span className="text-slate-900 font-semibold block">{member.motherName || 'তথ্য নেই'}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">জন্ম তারিখ:</span>
              <span className="text-slate-900 font-mono font-semibold block">{member.dateOfBirth || 'তথ্য নেই'}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">পেশা:</span>
              <span className="text-slate-900 font-semibold block">{member.occupation || 'তথ্য নেই'}</span>
            </div>
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500 font-bold block">সমিতিতে যোগদানের তারিখ:</span>
              <span className="text-slate-900 font-mono font-semibold block">{member.admissionDate}</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
            <span className="text-slate-500 font-bold block">বর্তমান ও স্থায়ী ঠিকানা:</span>
            <p className="text-slate-800 leading-relaxed font-semibold">{member.address || 'তথ্য প্রদান করা হয়নি।'}</p>
          </div>
        </div>
      )}

      {/* TAB 5: SAVINGS & GENERAL LEDGER */}
      {activeTab === 'SAVINGS' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-1">
              <span className="text-xs text-slate-500">মোট সঞ্চয় জমা</span>
              <span className="text-xl font-bold font-mono text-emerald-800 block">
                {formatCurrency(member.totalSavingsDeposits, lang)}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-1">
              <span className="text-xs text-slate-500">মোট সঞ্চয় উত্তোলন</span>
              <span className="text-xl font-bold font-mono text-rose-600 block">
                {formatCurrency(member.totalSavingsWithdrawals, lang)}
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-700 to-teal-800 text-white space-y-1">
              <span className="text-xs text-emerald-100">চলমান সঞ্চয় স্থিতি</span>
              <span className="text-xl font-bold font-mono text-white block">
                {formatCurrency(member.currentSavingsBalance, lang)}
              </span>
            </div>
          </div>

          {/* Receipts Table */}
          <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                অনুমোদিত ও পোস্টকৃত রশিদের তালিকা
              </h3>
              <span className="text-xs font-mono text-slate-500">Total: {receipts.length}</span>
            </div>

            {receipts.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                কোনো অনুমোদিত লেনদেন রশিদ পাওয়া যায়নি।
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono">
                      <th className="py-3 px-4">Receipt No</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Method</th>
                      <th className="py-3 px-4 text-right">Amount</th>
                      <th className="py-3 px-4 text-center">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {receipts.map((r) => (
                      <tr key={r.receiptNumber} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-blue-700">{r.receiptNumber}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{r.paymentDate}</td>
                        <td className="py-3 px-4 font-semibold text-slate-800">{r.type}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{r.paymentMethod}</td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(r.amount, lang)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {onViewReceipt && (
                            <button
                              onClick={() => onViewReceipt(r.receiptNumber)}
                              className="text-xs text-emerald-700 hover:text-emerald-800 font-bold underline cursor-pointer"
                            >
                              রশিদ দেখুন
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 6: NOMINEE & GUARANTOR DETAILS */}
      {activeTab === 'NOMINEE' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Users className="w-5 h-5 text-purple-700" />
              <h3 className="text-sm font-bold text-slate-900">নমিনীর বিবরণ (Nominee)</h3>
            </div>
            {member.nominee ? (
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">নাম:</span>
                  <span className="font-bold text-slate-900">{member.nominee.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">সম্পর্ক:</span>
                  <span className="font-semibold text-slate-800">{member.nominee.relation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মোবাইল নম্বর:</span>
                  <span className="font-mono text-slate-800">{member.nominee.mobile}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">NID নম্বর:</span>
                  <span className="font-mono text-slate-800">{member.nominee.nid}</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400">কোনো নমিনী রেকর্ড সংযুক্ত নেই।</p>
            )}
          </div>

          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <ShieldCheck className="w-5 h-5 text-teal-700" />
              <h3 className="text-sm font-bold text-slate-900">জামিনদারের বিবরণ (Guarantor)</h3>
            </div>
            {member.guarantor ? (
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">নাম:</span>
                  <span className="font-bold text-slate-900">{member.guarantor.name}</span>
                </div>
                {member.guarantor.memberId && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">সমিতির মেম্বার আইডি:</span>
                    <span className="font-mono font-bold text-teal-800">{member.guarantor.memberId}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">সম্পর্ক:</span>
                  <span className="font-semibold text-slate-800">{member.guarantor.relation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মোবাইল নম্বর:</span>
                  <span className="font-mono text-slate-800">{member.guarantor.mobile}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">NID নম্বর:</span>
                  <span className="font-mono text-slate-800">{member.guarantor.nid}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">পেশা ও ঠিকানা:</span>
                  <span className="text-slate-800">{member.guarantor.occupation} · {member.guarantor.address}</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400">কোনো জামিনদার রেকর্ড সংযুক্ত নেই।</p>
            )}
          </div>
        </div>
      )}

      {/* MODAL 1: APPLY NEW LOAN WITH INTERACTIVE CALCULATOR */}
      {showApplyLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-xs">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900">
                    নতুন লোন আবেদন ও ক্যালকুলেটর
                  </h3>
                  <p className="text-xs text-slate-500">
                    সদস্য: {member.fullNameBn} ({member.id})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowApplyLoanModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleApplyLoanSubmit} className="p-5 sm:p-6 space-y-5 overflow-y-auto text-xs">
              {loanMessage && (
                <div
                  className={`p-3 rounded-xl ${
                    loanMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                  }`}
                >
                  {loanMessage.text}
                </div>
              )}

              {/* Principal Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">ঋণের আসল পরিমাণ (টাকা) *</label>
                  <span className="font-mono font-bold text-blue-700 text-sm">
                    {formatCurrency(loanAmount)}
                  </span>
                </div>
                <input
                  type="number"
                  min={1000}
                  step={1000}
                  required
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Math.max(0, Number(e.target.value)))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm bg-slate-50 focus:bg-white outline-none"
                />
                <div className="flex flex-wrap gap-1 pt-1">
                  {[20000, 30000, 50000, 100000, 200000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setLoanAmount(amt)}
                      className={`px-2.5 py-1 text-xs rounded-lg border font-mono font-semibold ${
                        loanAmount === amt
                          ? 'bg-blue-700 text-white border-blue-700'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ৳ {amt.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rate & Method */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">মুনাফার হার (% বার্ষিক)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step={0.5}
                      min={0}
                      max={30}
                      value={loanProfitRate}
                      onChange={(e) => setLoanProfitRate(Math.max(0, Number(e.target.value)))}
                      className="w-full p-2 rounded-xl border border-slate-300 font-mono font-bold text-xs"
                    />
                    <span className="font-bold text-slate-600">%</span>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">গণনার পদ্ধতি</label>
                  <select
                    value={loanCalcMethod}
                    onChange={(e) => setLoanCalcMethod(e.target.value as LoanCalculationMethod)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white"
                  >
                    <option value="FLAT">সরল মুনাফা (Flat Rate)</option>
                    <option value="REDUCING">হ্রাসমান ব্যালেন্স (Reducing Balance EMI)</option>
                  </select>
                </div>
              </div>

              {/* Installment Count Selection (with fractional pills) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">মাসিক কিস্তির সংখ্যা নির্বাচন করুন *</label>
                  <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200">
                    {toBnNumber(loanInstallmentCount)} কিস্তি {newLoanCalc.isFractional ? '(ভগ্নাংশ কিস্তি)' : ''}
                  </span>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                  {allowedInstallments.map((inst) => {
                    const isSelected = loanInstallmentCount === inst;
                    const isHalf = inst % 1 !== 0;
                    return (
                      <button
                        key={inst}
                        type="button"
                        onClick={() => setLoanInstallmentCount(inst)}
                        className={`p-2 rounded-xl border text-center transition-all ${
                          isSelected
                            ? 'bg-blue-700 text-white border-blue-700 shadow-sm'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div className="font-mono font-bold text-xs">{inst}</div>
                        <div className={`text-[9px] ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                          {isHalf ? 'অর্ধেকসহ' : 'কিস্তি'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* First Installment Date & Purpose */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">প্রথম কিস্তির সম্ভাব্য তারিখ *</label>
                  <input
                    type="date"
                    required
                    value={loanFirstDate}
                    onChange={(e) => setLoanFirstDate(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">ঋণের উদ্দেশ্য *</label>
                  <input
                    type="text"
                    required
                    value={loanPurpose}
                    onChange={(e) => setLoanPurpose(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              {/* Live Calculator Calculation Result Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white space-y-3">
                <span className="text-[11px] text-blue-200 font-bold block uppercase tracking-wider">
                  ক্যালকুলেশন ফলাফল ও কিস্তির হিসাব
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div className="p-2 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-[10px] text-slate-300 block">মোট আসল</span>
                    <span className="font-mono font-bold text-white text-xs mt-0.5 block">
                      {formatCurrency(newLoanCalc.principal)}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-white/5 border border-white/10">
                    <span className="text-[10px] text-emerald-300 block">মোট মুনাফা</span>
                    <span className="font-mono font-bold text-emerald-400 text-xs mt-0.5 block">
                      + {formatCurrency(newLoanCalc.totalProfitAmount)}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-blue-500/20 border border-blue-400/30">
                    <span className="text-[10px] text-blue-200 block">মোট পরিশোধযোগ্য</span>
                    <span className="font-mono font-extrabold text-blue-300 text-xs mt-0.5 block">
                      {formatCurrency(newLoanCalc.totalPayableAmount)}
                    </span>
                  </div>

                  <div className="p-2 rounded-xl bg-indigo-500/20 border border-indigo-400/30">
                    <span className="text-[10px] text-indigo-200 block">মোট কিস্তি</span>
                    <span className="font-mono font-bold text-indigo-300 text-xs mt-0.5 block">
                      {toBnNumber(newLoanCalc.totalPaymentCount)} বার
                    </span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-white/10 border border-white/15 text-center text-xs">
                  <span className="text-slate-300 text-[11px] block">মাসিক কিস্তি:</span>
                  <span className="font-mono font-bold text-emerald-300 text-base">
                    {formatCurrency(newLoanCalc.regularInstallmentAmount)}
                  </span>
                </div>
              </div>

              {!eligibility.isEligible && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
                  সতর্কতা: সদস্যের ভর্তি ফি, ইনস্যুরেন্স বা সঞ্চয় বকেয়া রয়েছে। আবেদন দাখিল করা গেলেও বকেয়া পূরণ বা মওকুফ না হওয়া পর্যন্ত বিতরণ স্থগিত থাকবে।
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowApplyLoanModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-xs cursor-pointer"
                >
                  ঋণ আবেদন দাখিল করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: EDIT LOAN PROPOSAL (ADMIN ADJUSTMENT BEFORE APPROVAL) */}
      {editLoanTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50 shrink-0">
              <div className="flex items-center gap-2">
                <Edit className="w-5 h-5 text-blue-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  ঋণ প্রস্তাবনা ও কিস্তির হিসাব সম্পাদনা ({editLoanTarget.id})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditLoanTarget(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditLoanSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto text-xs">
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
                নোটিশ: ঋণের পরিমাণ বা কিস্তির সংখ্যা পরিবর্তন করলে সদস্যের পূর্বের সম্মতি স্বয়ংক্রিয়ভাবে বাতিল হয়ে অপেক্ষমান (PENDING) হবে এবং নতুন করে সম্মতি নিশ্চিত করতে হবে।
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">সংশোধিত ঋণের পরিমাণ (টাকা) *</label>
                <input
                  type="number"
                  min={1000}
                  step={1000}
                  required
                  value={editLoanAmount}
                  onChange={(e) => setEditLoanAmount(Math.max(0, Number(e.target.value)))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">মুনাফার হার (% বার্ষিক)</label>
                  <input
                    type="number"
                    step={0.5}
                    value={editLoanProfitRate}
                    onChange={(e) => setEditLoanProfitRate(Number(e.target.value))}
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">গণনার পদ্ধতি</label>
                  <select
                    value={editLoanCalcMethod}
                    onChange={(e) => setEditLoanCalcMethod(e.target.value as LoanCalculationMethod)}
                    className="w-full p-2 rounded-xl border border-slate-300 font-semibold"
                  >
                    <option value="FLAT">সরল মুনাফা (Flat)</option>
                    <option value="REDUCING">হ্রাসমান ব্যালেন্স (Reducing)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">কিস্তির সংখ্যা নির্বাচন করুন</label>
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                  {allowedInstallments.map((inst) => (
                    <button
                      key={inst}
                      type="button"
                      onClick={() => setEditLoanInstallmentCount(inst)}
                      className={`p-2 rounded-xl border text-center transition-all ${
                        editLoanInstallmentCount === inst
                          ? 'bg-blue-700 text-white border-blue-700 font-bold'
                          : 'bg-white text-slate-700 border-slate-200'
                      }`}
                    >
                      <span className="font-mono text-xs">{inst}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-800 block mb-1">প্রথম কিস্তির তারিখ</label>
                  <input
                    type="date"
                    required
                    value={editLoanFirstDate}
                    onChange={(e) => setEditLoanFirstDate(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-800 block mb-1">উদ্দেশ্য</label>
                  <input
                    type="text"
                    value={editLoanPurpose}
                    onChange={(e) => setEditLoanPurpose(e.target.value)}
                    className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">সম্পাদনার কারণ / অডিট নোট *</label>
                <input
                  type="text"
                  required
                  placeholder="উদাঃ সদস্যের অনুরোধে কিস্তির সংখ্যা বৃদ্ধি"
                  value={editLoanReason}
                  onChange={(e) => setEditLoanReason(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              {/* Live Preview Card */}
              <div className="p-3.5 rounded-2xl bg-slate-900 text-white space-y-2">
                <span className="text-[10px] text-blue-200 font-bold uppercase">নতুন হিসাবের রূপরেখা:</span>
                <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-slate-400 block">মোট পরিশোধযোগ্য:</span>
                    <span className="font-bold text-blue-300">{formatCurrency(editLoanCalc.totalPayableAmount)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">মাসিক কিস্তি:</span>
                    <span className="font-bold text-emerald-300">{formatCurrency(editLoanCalc.regularInstallmentAmount)}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setEditLoanTarget(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold shadow-xs cursor-pointer"
                >
                  হালনাগাদ ও সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: RECORD MEMBER CONSENT */}
      {consentTargetLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-amber-50/80 shrink-0">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-amber-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  সদস্যের ঋণ সম্মতিপত্র গ্রহণ (Member Consent)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setConsentTargetLoan(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRecordConsent} className="p-5 sm:p-6 space-y-4 overflow-y-auto text-xs">
              <p className="text-slate-600 leading-relaxed">
                ঋণ অনুমোদনের পূর্বে সদস্যকে ঋণের পরিমাণ, মোট মুনাফা, মোট পরিশোধযোগ্য টাকা, কিস্তির সংখ্যা, নিয়মিত মাসিক কিস্তি এবং শেষ কিস্তির টাকা স্পষ্টভাবে অবহিত করে তার আনুষ্ঠানিক সম্মতি লিপিবদ্ধ করুন।
              </p>

              {/* Full Financial Disclosure Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500 font-bold">সদস্যের নাম:</span>
                  <span className="font-bold text-slate-900">{member.fullNameBn} ({member.id})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">ঋণের আসল পরিমাণ:</span>
                  <span className="font-mono font-bold text-blue-900">{formatCurrency(consentTargetLoan.approvedAmount || consentTargetLoan.requestedAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মোট মুনাফা:</span>
                  <span className="font-mono font-bold text-emerald-700">+ {formatCurrency(consentTargetLoan.totalProfitAmount || (consentTargetLoan.totalPayableAmount - consentTargetLoan.approvedAmount))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-bold">সর্বমোট পরিশোধযোগ্য:</span>
                  <span className="font-mono font-extrabold text-blue-950 text-sm">{formatCurrency(consentTargetLoan.totalPayableAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">কিস্তির সংখ্যা:</span>
                  <span className="font-bold text-slate-800">{toBnNumber(consentTargetLoan.installmentCount || consentTargetLoan.totalInstallments)} কিস্তি</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মাসিক কিস্তি:</span>
                  <span className="font-mono font-bold text-emerald-800">{formatCurrency(consentTargetLoan.regularInstallmentAmount || consentTargetLoan.monthlyInstallmentAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">প্রথম কিস্তির তারিখ:</span>
                  <span className="font-mono font-bold text-slate-700">{consentTargetLoan.firstInstallmentDate || consentTargetLoan.nextInstallmentDueDate || '—'}</span>
                </div>
              </div>

              {/* Consent Acknowledgment Checkbox */}
              <label className="flex items-start gap-2.5 p-3 rounded-2xl bg-amber-50 border border-amber-200 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={consentAcknowledged}
                  onChange={(e) => setConsentAcknowledged(e.target.checked)}
                  className="mt-0.5 w-4 h-4 rounded text-blue-600 accent-blue-600"
                />
                <span className="text-[11px] text-amber-950 font-bold leading-relaxed">
                  আমি (সদস্য) উপরোক্ত ঋণের পরিমাণ, সার্ভিস চার্জ, কিস্তির সংখ্যা ও পরিশোধের সময়সূচির প্রতিটি শর্ত বিস্তারিতভাবে জেনে, বুঝে সম্পূর্ণ সন্তুষ্টির সাথে সম্মতি জ্ঞাপন করছি।
                </span>
              </label>

              <div>
                <label className="font-bold text-slate-800 block mb-1">সম্মতি গ্রহণ সংক্রান্ত নোট / মন্তব্য</label>
                <textarea
                  rows={2}
                  value={consentNote}
                  onChange={(e) => setConsentNote(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setConsentTargetLoan(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={!consentAcknowledged}
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold shadow-xs cursor-pointer"
                >
                  সম্মতি নিশ্চিত ও রেকর্ড করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: FINAL APPROVAL & DISBURSEMENT */}
      {disburseTargetLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-emerald-50 shrink-0">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  ঋণ চূড়ান্ত অনুমোদন ও বিতরণ ডেস্ক ({disburseTargetLoan.id})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setDisburseTargetLoan(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFinalDisburseSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto text-xs">
              {/* Integrity Checklist */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <span className="font-bold text-slate-800 block text-xs">বিতরণ পূর্ববর্তী চেকলিস্ট:</span>

                <div className="flex items-center justify-between">
                  <span>১. লোন একাউন্ট সম্পূর্ণতা (ফি ও আমানত):</span>
                  {eligibility.isEligible ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> শর্ত পূরণ হয়েছে
                    </span>
                  ) : (
                    <span className="text-rose-600 font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> বকেয়া রয়েছে
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span>২. সদস্যের সম্মতিপত্র (Member Consent):</span>
                  {disburseTargetLoan.memberConsentStatus === 'CONSENTED' ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> সম্মতি নথিভুক্ত
                    </span>
                  ) : (
                    <span className="text-rose-600 font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" /> সম্মতি অনুপস্থিত
                    </span>
                  )}
                </div>
              </div>

              {/* Amount to Disburse */}
              <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 flex justify-between items-center">
                <span className="font-bold text-blue-900">বিতরণযোগ্য মূলধন:</span>
                <span className="font-mono font-extrabold text-blue-950 text-base">
                  {formatCurrency(disburseTargetLoan.approvedAmount || disburseTargetLoan.requestedAmount)}
                </span>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">বিতরণ মাধ্যম (Disbursement Method) *</label>
                <select
                  value={disburseMethod}
                  onChange={(e) => setDisburseMethod(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-bold bg-white"
                >
                  <option value="CASH">নগদ ক্যাশ (Cash in Hand)</option>
                  <option value="BANK">ব্যাংক ট্রান্সফার (Bank Transfer)</option>
                  <option value="BKASH">বিকাশ (bKash)</option>
                  <option value="NAGAD">নগদ (Nagad)</option>
                  <option value="ROCKET">রকেট (Rocket)</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">ভাউচার / লেনদেন রেফারেন্স নম্বর</label>
                <input
                  type="text"
                  value={disburseRef}
                  onChange={(e) => setDisburseRef(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono text-xs font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-800 block mb-1">অনুমোদন নোট / রেজোলিউশন</label>
                <input
                  type="text"
                  value={disburseNote}
                  onChange={(e) => setDisburseNote(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setDisburseTargetLoan(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={!eligibility.isEligible || disburseTargetLoan.memberConsentStatus !== 'CONSENTED'}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-40 text-white font-bold shadow-xs cursor-pointer"
                >
                  অনুমোদন ও বিতরণ সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: INSTALLMENT SCHEDULE TABLE MODAL */}
      {scheduleTargetLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50 shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-700" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    পরিশোধের সম্পূর্ণ কিস্তি সময়সূচি ({scheduleTargetLoan.id})
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    মোট পরিশোধযোগ্য: ৳ {scheduleTargetLoan.totalPayableAmount?.toLocaleString()} · মোট কিস্তি: {toBnNumber(scheduleTargetLoan.installmentCount || scheduleTargetLoan.totalInstallments)}টি
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setScheduleTargetLoan(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto">
              <div className="border border-slate-200 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[11px]">
                      <th className="py-2.5 px-3">কিস্তি নং</th>
                      <th className="py-2.5 px-3">পরিশোধের তারিখ</th>
                      <th className="py-2.5 px-3 text-right">আসল অংশ</th>
                      <th className="py-2.5 px-3 text-right">মুনাফা অংশ</th>
                      <th className="py-2.5 px-3 text-right">কিস্তির টাকা</th>
                      <th className="py-2.5 px-3 text-center">স্ট্যাটাস</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {(scheduleTargetLoan.schedule || []).map((item) => (
                      <tr key={item.installmentNumber} className={item.isFractional ? 'bg-amber-50/50' : 'hover:bg-slate-50'}>
                        <td className="py-2.5 px-3 font-bengali font-bold text-slate-800">
                          {item.label || `কিস্তি নং ${toBnNumber(item.installmentNumber)}`}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">{item.dueDate}</td>
                        <td className="py-2.5 px-3 text-right text-slate-700">৳ {item.principalAmount.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-emerald-700">৳ {item.profitAmount.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right font-bold text-blue-900">৳ {item.totalAmount.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-center font-bengali">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.status === 'PAID' ? 'পরিশোধিত' : 'অপেক্ষমান'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => setScheduleTargetLoan(null)}
                className="px-5 py-2 rounded-xl bg-blue-700 text-white text-xs font-bold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: DOCUMENT LIGHTBOX PREVIEW */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50 shrink-0">
              <h3 className="text-sm font-bold text-slate-900">{previewDoc.title}</h3>
              <button
                type="button"
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex items-center justify-center bg-slate-900">
              <img
                src={previewDoc.url}
                alt={previewDoc.title}
                className="max-h-[70vh] object-contain rounded-xl border border-slate-700"
              />
            </div>
            <div className="p-3 border-t border-slate-200 bg-slate-50 flex justify-between items-center shrink-0 text-xs">
              <a
                href={previewDoc.url}
                target="_blank"
                rel="noreferrer"
                download
                className="text-blue-700 font-bold hover:underline"
              >
                ডাউনলোড করুন / নতুন ট্যাবে খুলুন
              </a>
              <button
                type="button"
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-1.5 rounded-xl bg-slate-200 text-slate-800 font-bold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: FEE WAIVER */}
      {showWaiveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">{showWaiveModal.title}</h3>
              <button onClick={() => setShowWaiveModal(null)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleWaiveSubmit} className="p-6 space-y-4 text-xs">
              <p className="text-slate-600 leading-relaxed">
                অনুমোদিত প্রশাসনিক নীতিমালার আলোকে শর্ত মওকুফ করার কারণ লিপিবদ্ধ করুন। এটি অডিট লগে স্থায়ীভাবে সংরক্ষিত থাকবে।
              </p>
              <div>
                <label className="block font-bold text-slate-700 mb-1">মওকুফের কারণ *</label>
                <textarea
                  required
                  rows={2}
                  value={waiveReason}
                  onChange={(e) => setWaiveReason(e.target.value)}
                  placeholder="উদাঃ ব্যবস্থাপনা কমিটির বিশেষ রেজোলিউশন নং ৪"
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowWaiveModal(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button type="submit" className="px-5 py-2 rounded-xl bg-emerald-700 text-white font-bold">
                  মওকুফ নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT MEMBER INFORMATION */}
      {showEditMemberModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">সদস্যের তথ্য সম্পাদনা (Edit Member)</h3>
              <button onClick={() => setShowEditMemberModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditMemberSubmit} className="p-6 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">নাম (বাংলা)</label>
                  <input
                    type="text"
                    required
                    value={editForm.fullNameBn}
                    onChange={(e) => setEditForm({ ...editForm, fullNameBn: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">নাম (English)</label>
                  <input
                    type="text"
                    value={editForm.fullNameEn}
                    onChange={(e) => setEditForm({ ...editForm, fullNameEn: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                  <input
                    type="tel"
                    required
                    value={editForm.mobileNumber}
                    onChange={(e) => setEditForm({ ...editForm, mobileNumber: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">NID নম্বর</label>
                  <input
                    type="text"
                    required
                    value={editForm.nidNumber}
                    onChange={(e) => setEditForm({ ...editForm, nidNumber: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">পিতা / স্বামীর নাম</label>
                  <input
                    type="text"
                    value={editForm.fatherOrHusbandName}
                    onChange={(e) => setEditForm({ ...editForm, fatherOrHusbandName: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">পেশা</label>
                  <input
                    type="text"
                    value={editForm.occupation}
                    onChange={(e) => setEditForm({ ...editForm, occupation: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">ঠিকানা</label>
                <input
                  type="text"
                  value={editForm.address}
                  onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEditMemberModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button type="submit" className="px-5 py-2 rounded-xl bg-blue-700 text-white font-bold">
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DELETE CONFIRMATION & SAFETY CHECK */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-rose-50/80">
              <div className="flex items-center gap-2 text-rose-800">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold font-display">সদস্য মুছে ফেলার যাচাইকরণ</h3>
              </div>
              <button onClick={() => setShowDeleteModal(false)} className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">সদস্যের নাম:</span>
                  <span className="font-bold text-slate-900">{member.fullNameBn}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মেম্বার আইডি:</span>
                  <span className="font-mono font-bold text-blue-700">{member.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">বকেয়া ঋণ:</span>
                  <span className="font-mono font-bold text-amber-800">৳{member.currentLoanOutstanding}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">সঞ্চয় স্থিতি:</span>
                  <span className="font-mono font-bold text-emerald-800">৳{member.currentSavingsBalance}</span>
                </div>
              </div>

              {deleteBlockReason ? (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 space-y-2">
                  <div className="font-bold flex items-center gap-1.5 text-rose-700">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <span>আর্থিক নিরাপত্তার বিধিনিষেধ: ডিলিট স্থগিত</span>
                  </div>
                  <p className="leading-relaxed">{deleteBlockReason}</p>
                </div>
              ) : (
                <>
                  <p className="text-slate-600 leading-relaxed">
                    আপনি কি নিশ্চিত যে আপনি <strong>{member.fullNameBn} ({member.id})</strong>-এর রেকর্ড স্থায়ীভাবে মুছে ফেলতে চান?
                  </p>
                  <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowDeleteModal(false)}
                      className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                    >
                      বাতিল
                    </button>
                    <button
                      type="button"
                      onClick={handleDeleteMember}
                      className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                    >
                      যাচাই করে মুছে ফেলুন
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ADMIN PAYMENT ENTRY */}
      {showAdminPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">সদস্যের পেমেন্ট এন্ট্রি ও পোস্টিং</h3>
              <button onClick={() => setShowAdminPaymentModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsSubmittingPay(true);
              const idempotencyKey = `ADMIN-PAY-${Date.now()}-${Math.random()}`;
              const submitRes = memberService.submitPaymentRequest({
                idempotencyKey,
                memberId: member.id,
                memberName: member.fullNameBn,
                memberUserId: member.userId,
                loanId: member.activeLoanId,
                type: payType,
                dueAmount: payAmount,
                requestedAmount: payAmount,
                paymentMethod: payMethod,
                transactionReference: payRef,
              });
              if (submitRes.success && submitRes.request) {
                const postRes = memberService.approvePaymentRequest(submitRes.request.id, 'সুপার এডমিন (SA-01)', 'এডমিন সরাসরি পেমেন্ট এন্ট্রি');
                if (postRes.success) {
                  alert('পেমেন্ট সফলভাবে লেজারে পোস্ট হয়েছে ও রশিদ তৈরি হয়েছে।');
                  refreshAll();
                  setShowAdminPaymentModal(false);
                }
              }
              setIsSubmittingPay(false);
            }} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">লেনদেনের ধরন *</label>
                <select
                  value={payType}
                  onChange={(e) => setPayType(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="LOAN_INSTALLMENT">ঋণ কিস্তি আদায়</option>
                  <option value="SAVINGS_DEPOSIT">সঞ্চয় আমানত জমা</option>
                  <option value="ADMISSION_FEE">ভর্তি ফি গ্রহণ</option>
                  <option value="INSURANCE_FEE">ইনস্যুরেন্স ফান্ড জমা</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">টাকার পরিমাণ *</label>
                <input
                  type="number"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">পেমেন্ট মেথড *</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="CASH">ক্যাশ (Cash)</option>
                  <option value="BKASH">বিকাশ (bKash)</option>
                  <option value="NAGAD">নগদ (Nagad)</option>
                  <option value="ROCKET">রকেট (Rocket)</option>
                  <option value="BANK">ব্যাংক ট্রান্সফার (Bank)</option>
                </select>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAdminPaymentModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPay}
                  className="px-5 py-2 rounded-xl bg-emerald-700 text-white font-bold flex items-center gap-1.5"
                >
                  {isSubmittingPay && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>অনুমোদন ও লেজারে পোস্ট করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: UPLOAD ADDITIONAL DOCUMENT */}
      {showUploadDocModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">ডকুমেন্ট আপলোড</h3>
              <button onClick={() => setShowUploadDocModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleDocUploadSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">ক্যাটাগরি *</label>
                <select
                  value={uploadCategory}
                  onChange={(e) => setUploadCategory(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="MEMBER">সদস্যের নিজস্ব ডকুমেন্ট</option>
                  <option value="NOMINEE">নমিনীর ডকুমেন্ট</option>
                  <option value="GUARANTOR">জামিনদারের ডকুমেন্ট</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">ডকুমেন্ট শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={docTitle}
                  onChange={(e) => setDocTitle(e.target.value)}
                  placeholder="উদাঃ জাতীয় পরিচয়পত্র কপি, চুক্তিপত্র"
                  className="w-full p-2.5 rounded-xl border border-slate-300"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">ফাইল সিলেক্ট করুন *</label>
                <input
                  type="file"
                  accept="image/*,.pdf"
                  required
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => setDocDataUrl(reader.result as string);
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="w-full text-xs text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:bg-blue-100 file:text-blue-800"
                />
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadDocModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button type="submit" className="px-5 py-2 rounded-xl bg-blue-700 text-white font-bold">
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT APPROVED FEE & DEPOSIT REQUIREMENTS */}
      {showFeeEditModal && member && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-sm font-bold text-slate-900">অনুমোদিত খাতের টাকা সম্পাদনা</h3>
                <p className="text-xs text-slate-500">
                  ভর্তি ফি, ইনস্যুরেন্স ও প্রাথমিক আমানত সমন্বয় (বর্তমান ইনস্যুরেন্স হার: {branding?.insuranceRatePercent ?? 0.5}%)
                </p>
              </div>
              <button
                onClick={() => setShowFeeEditModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const res = memberService.updateMemberFeeAccounts(
                  member.id,
                  feeEditForm,
                  'সুপার এডমিন (SA-01)'
                );
                if (res.success) {
                  refreshAll();
                  setShowFeeEditModal(false);
                }
              }}
              className="p-6 space-y-5 text-xs max-h-[80vh] overflow-y-auto"
            >
              {/* Quick Auto-Fill Banner */}
              <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <span className="font-bold text-blue-900 block text-xs">
                    সেটিংস অনুযায়ী স্বয়ংক্রিয় হিসাব (০.৫% ইনস্যুরেন্স):
                  </span>
                  <span className="text-[11px] text-blue-700">
                    আবেদনকৃত লোন ৳{member.requestedInitialLoanAmount || 50000} হলে ০.৫% হারে ইনস্যুরেন্স ৳
                    {Math.round((member.requestedInitialLoanAmount || 50000) * ((branding?.insuranceRatePercent ?? 0.5) / 100))}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const loan = member.requestedInitialLoanAmount || 50000;
                    const insRate = branding?.insuranceRatePercent ?? 0.5;
                    const calculatedInsurance = Math.round(loan * (insRate / 100));
                    setFeeEditForm((prev) => ({
                      ...prev,
                      admissionFeeRequired: branding?.admissionFeeDefault ?? 100,
                      insuranceFeeRequired: calculatedInsurance,
                      initialSavingsRequired: Math.round(loan * ((branding?.initialSavingsRatePercent ?? 5.0) / 100)),
                    }));
                  }}
                  className="px-3 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shrink-0 cursor-pointer shadow-xs"
                >
                  সেটিংস হার প্রয়োগ করুন
                </button>
              </div>

              {/* 1. Admission Fee */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-900 text-xs flex items-center justify-between">
                  <span>১. ভর্তি ফি (Admission Fee)</span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    বকেয়া: ৳{Math.max(0, feeEditForm.admissionFeeRequired - feeEditForm.admissionFeePaid)}
                  </span>
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 mb-1">নির্ধারিত টাকা *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.admissionFeeRequired}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, admissionFeeRequired: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">পরিশোধিত টাকা *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.admissionFeePaid}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, admissionFeePaid: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-emerald-800"
                    />
                  </div>
                </div>
              </div>

              {/* 2. Insurance Fund */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-900 text-xs flex items-center justify-between">
                  <span>২. ইনস্যুরেন্স ফান্ড (Insurance Fund)</span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    বকেয়া: ৳{Math.max(0, feeEditForm.insuranceFeeRequired - feeEditForm.insuranceFeePaid)}
                  </span>
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 mb-1">নির্ধারিত টাকা (০.৫% হারে ২৫০) *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.insuranceFeeRequired}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, insuranceFeeRequired: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">পরিশোধিত টাকা *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.insuranceFeePaid}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, insuranceFeePaid: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-emerald-800"
                    />
                  </div>
                </div>
              </div>

              {/* 3. Initial Savings */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-900 text-xs flex items-center justify-between">
                  <span>৩. প্রাথমিক বাধ্যতামূলক সঞ্চয় (Initial Savings)</span>
                  <span className="text-[11px] text-slate-500 font-normal">
                    বকেয়া: ৳{Math.max(0, feeEditForm.initialSavingsRequired - feeEditForm.initialSavingsPaid)}
                  </span>
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 mb-1">নির্ধারিত টাকা *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.initialSavingsRequired}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, initialSavingsRequired: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">পরিশোধিত টাকা (সদস্য বেশি দিতে পারেন) *</label>
                    <input
                      type="number"
                      required
                      min={0}
                      value={feeEditForm.initialSavingsPaid}
                      onChange={(e) =>
                        setFeeEditForm({ ...feeEditForm, initialSavingsPaid: Number(e.target.value) })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-emerald-800"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  সংরক্ষণ করলে তাৎক্ষণিকভাবে অডিট লগে রেকর্ড হবে ও বকেয়া হালনাগাদ হবে।
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowFeeEditModal(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 cursor-pointer"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer shadow-xs"
                  >
                    হালনাগাদ সংরক্ষণ করুন
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
