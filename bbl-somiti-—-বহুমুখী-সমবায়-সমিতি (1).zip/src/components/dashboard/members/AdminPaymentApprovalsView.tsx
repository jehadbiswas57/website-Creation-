import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  Eye,
  FileCheck,
  CreditCard,
  User,
  ArrowRight,
  Filter,
  Check,
  X,
  FileText,
  Loader2,
  Calendar,
  Wallet,
} from 'lucide-react';
import { Language } from '../../../types';
import { PaymentRequest, OfficialReceipt } from '../../../types/member';
import { memberService } from '../../../services/memberService';
import { formatCurrency } from '../../../utils/formatters';

interface AdminPaymentApprovalsViewProps {
  lang: Language;
  onViewReceipt?: (receiptNumber: string) => void;
}

export const AdminPaymentApprovalsView: React.FC<AdminPaymentApprovalsViewProps> = ({
  lang,
  onViewReceipt,
}) => {
  const isBn = lang === 'bn';
  const [requests, setRequests] = useState<PaymentRequest[]>(() => memberService.getAllPaymentRequests());
  const [filterStatus, setFilterStatus] = useState<'PENDING' | 'APPROVED' | 'REJECTED' | 'ALL'>('PENDING');

  // Modal / Action State
  const [selectedReq, setSelectedReq] = useState<PaymentRequest | null>(null);
  const [actionType, setActionType] = useState<'APPROVE' | 'REJECT' | null>(null);
  const [reviewNote, setReviewNote] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string; receiptNo?: string } | null>(null);

  const refreshRequests = () => {
    setRequests(memberService.getAllPaymentRequests());
  };

  const filtered = requests.filter((r) => {
    if (filterStatus === 'ALL') return true;
    return r.status === filterStatus;
  });

  const pendingCount = requests.filter((r) => r.status === 'PENDING').length;

  const handleExecuteAction = () => {
    if (!selectedReq || !actionType) return;
    setIsProcessing(true);
    setFeedback(null);

    if (actionType === 'APPROVE') {
      const res = memberService.approvePaymentRequest(
        selectedReq.id,
        'সুপার এডমিন (SA-01)',
        reviewNote || 'অনুমোদিত ও আর্থিক পোস্টিং সম্পন্ন'
      );
      if (res.success && res.receipt) {
        setFeedback({
          type: 'success',
          text: res.message,
          receiptNo: res.receipt.receiptNumber,
        });
        refreshRequests();
        setTimeout(() => {
          setSelectedReq(null);
          setActionType(null);
          setReviewNote('');
          setIsProcessing(false);
          setFeedback(null);
        }, 1500);
      } else {
        setFeedback({ type: 'error', text: res.message });
        setIsProcessing(false);
      }
    } else {
      const res = memberService.rejectPaymentRequest(
        selectedReq.id,
        'সুপার এডমিন (SA-01)',
        reviewNote || 'তথ্য অসামঞ্জস্যপূর্ণ'
      );
      if (res.success) {
        setFeedback({ type: 'success', text: res.message });
        refreshRequests();
        setTimeout(() => {
          setSelectedReq(null);
          setActionType(null);
          setReviewNote('');
          setIsProcessing(false);
          setFeedback(null);
        }, 1200);
      } else {
        setFeedback({ type: 'error', text: res.message });
        setIsProcessing(false);
      }
    }
  };

  return (
    <div className="space-y-6 font-bengali">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-emerald-800 font-bold uppercase tracking-widest block">
            SUPER ADMIN FINANCIAL AUTHORIZATION DESK
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display mt-0.5">
            {isBn ? 'সদস্য পেমেন্ট ও কিস্তি অনুমোদন কেন্দ্র' : 'Payment Approvals & Posting'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            {isBn
              ? 'সদস্যদের প্রেরিত কিস্তি যাচাই, অনুমোদন ও লেজারে আর্থিক পোস্টিং সম্পন্ন করুন'
              : 'Verify member payment requests, authorize, and post directly into the financial ledger'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-600" />
            <span className="text-xs font-bold font-mono">
              {isBn ? `অপেক্ষমান আবেদন: ${pendingCount}` : `Pending: ${pendingCount}`}
            </span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        {[
          { key: 'PENDING', label: isBn ? `অপেক্ষমান (${pendingCount})` : `Pending (${pendingCount})` },
          { key: 'APPROVED', label: isBn ? 'অনুমোদিত' : 'Approved' },
          { key: 'REJECTED', label: isBn ? 'বাতিলকৃত' : 'Rejected' },
          { key: 'ALL', label: isBn ? 'সকল অনুরোধ' : 'All' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilterStatus(tab.key as any)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterStatus === tab.key
                ? 'bg-blue-700 text-white shadow-xs'
                : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Table / List */}
      {filtered.length === 0 ? (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-10 text-center space-y-3">
          <FileCheck className="w-12 h-12 text-slate-300 mx-auto" />
          <h4 className="text-sm font-bold text-slate-900">
            {filterStatus === 'PENDING'
              ? (isBn ? 'বর্তমানে কোনো অপেক্ষমান পেমেন্ট অনুরোধ নেই' : 'No pending payment requests')
              : (isBn ? 'কোনো রেকর্ড পাওয়া যায়নি' : 'No records found')}
          </h4>
          <p className="text-xs text-slate-500">
            {isBn
              ? 'সদস্যরা তাদের ড্যাশবোর্ড থেকে কিস্তি বা জমার অনুরোধ পাঠালে এখানে প্রদর্শিত হবে।'
              : 'Requests submitted by members will appear here for verification.'}
          </p>
        </div>
      ) : (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono tracking-wider">
                  <th className="py-3 px-4">{isBn ? 'অনুরোধ আইডি' : 'Request ID'}</th>
                  <th className="py-3 px-4">{isBn ? 'সদস্যের নাম ও আইডি' : 'Member'}</th>
                  <th className="py-3 px-4">{isBn ? 'খাত ও কিস্তি' : 'Type / Loan'}</th>
                  <th className="py-3 px-4">{isBn ? 'পদ্ধতি' : 'Method'}</th>
                  <th className="py-3 px-4">{isBn ? 'রেফারেন্স / স্লিপ' : 'Reference'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'টাকা' : 'Amount'}</th>
                  <th className="py-3 px-4">{isBn ? 'দাখিলের সময়' : 'Submitted'}</th>
                  <th className="py-3 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'সিদ্ধান্ত' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-blue-700">
                      {req.id}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{req.memberName}</div>
                      <div className="font-mono text-[11px] text-slate-400">{req.memberId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">
                        {req.type === 'LOAN_INSTALLMENT'
                          ? 'ঋণ কিস্তি'
                          : req.type === 'SAVINGS_DEPOSIT'
                          ? 'সঞ্চয় জমা'
                          : req.type === 'ADMISSION_FEE'
                          ? 'ভর্তি ফি'
                          : 'ইনস্যুরেন্স ফান্ড'}
                      </div>
                      {req.loanId && (
                        <div className="font-mono text-[10px] text-blue-700">{req.loanId}</div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono text-[11px] font-bold">
                        {req.paymentMethod}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {req.transactionReference || (req.paymentMethod === 'CASH' ? 'নগদ জমা' : '—')}
                      {req.paymentEvidenceUrl && (
                        <a
                          href={req.paymentEvidenceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="ml-1 text-blue-600 underline text-[10px]"
                        >
                          [স্লিপ]
                        </a>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                      {formatCurrency(req.requestedAmount, lang)}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                      <div>{req.submittedDate}</div>
                      <div className="text-[10px] text-slate-400">{req.submittedTime}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          req.status === 'PENDING'
                            ? 'bg-amber-100 text-amber-800'
                            : req.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {req.status === 'PENDING' ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedReq(req);
                              setActionType('APPROVE');
                              setReviewNote('');
                              setFeedback(null);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>অনুমোদন</span>
                          </button>
                          <button
                            onClick={() => {
                              setSelectedReq(req);
                              setActionType('REJECT');
                              setReviewNote('');
                              setFeedback(null);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs flex items-center gap-1 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>বাতিল</span>
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] text-slate-400">
                          {req.generatedReceiptNumber && onViewReceipt && (
                            <button
                              onClick={() => onViewReceipt(req.generatedReceiptNumber!)}
                              className="text-blue-700 hover:underline font-bold font-mono"
                            >
                              {req.generatedReceiptNumber}
                            </button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* APPROVE / REJECT CONFIRMATION MODAL */}
      {selectedReq && actionType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                {actionType === 'APPROVE' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-600" />
                )}
                <h3 className="text-sm font-bold text-slate-900">
                  {actionType === 'APPROVE' ? 'পেমেন্ট অনুমোদন ও আর্থিক পোস্টিং' : 'পেমেন্ট অনুরোধ বাতিল'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setSelectedReq(null);
                  setActionType(null);
                }}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {feedback && (
                <div
                  className={`p-3 rounded-xl ${
                    feedback.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                  }`}
                >
                  <p>{feedback.text}</p>
                  {feedback.receiptNo && (
                    <p className="mt-1 font-mono font-bold">রশিদ নম্বর: {feedback.receiptNo}</p>
                  )}
                </div>
              )}

              {/* Request Details Review */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">সদস্যের নাম:</span>
                  <span className="font-bold text-slate-900">{selectedReq.memberName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">মেম্বার আইডি:</span>
                  <span className="font-mono font-bold text-blue-700">{selectedReq.memberId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">টাকার পরিমাণ:</span>
                  <span className="font-mono font-bold text-emerald-800 text-sm">
                    {formatCurrency(selectedReq.requestedAmount, lang)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">পেমেন্ট মেথড:</span>
                  <span className="font-mono font-bold text-slate-800">{selectedReq.paymentMethod}</span>
                </div>
                {selectedReq.transactionReference && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">ট্রানজেকশন আইডি:</span>
                    <span className="font-mono text-slate-800">{selectedReq.transactionReference}</span>
                  </div>
                )}
              </div>

              {/* Review Note */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {actionType === 'APPROVE' ? 'অডিট ও ভাউচার নোট (ঐচ্ছিক)' : 'বাতিলের কারণ লিখুন *'}
                </label>
                <textarea
                  rows={2}
                  value={reviewNote}
                  onChange={(e) => setReviewNote(e.target.value)}
                  placeholder={
                    actionType === 'APPROVE'
                      ? 'অনুমোদনের কারণ বা ভাউচার বিস্তারিত'
                      : 'কী কারণে বাতিল করা হলো তা সদস্যকে জানানো হবে'
                  }
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedReq(null);
                    setActionType(null);
                  }}
                  className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleExecuteAction}
                  disabled={isProcessing}
                  className={`px-5 py-2 rounded-xl text-white font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-75 ${
                    actionType === 'APPROVE' ? 'bg-emerald-700 hover:bg-emerald-800' : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {isProcessing && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{actionType === 'APPROVE' ? 'অনুমোদন ও লেজারে পোস্টিং' : 'অনুরোধ বাতিল করুন'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
