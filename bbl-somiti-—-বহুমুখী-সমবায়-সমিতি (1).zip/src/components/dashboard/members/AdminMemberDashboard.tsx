import React, { useState, useMemo } from 'react';
import {
  Users,
  UserCheck,
  UserX,
  CreditCard,
  TrendingDown,
  TrendingUp,
  AlertCircle,
  PiggyBank,
  ShieldCheck,
  Wallet,
  Search,
  Filter,
  Plus,
  Eye,
  KeyRound,
  Edit,
  ArrowUpDown,
  FileSpreadsheet,
  CheckCircle2,
  Lock,
  ChevronLeft,
  ChevronRight,
  Phone,
  Calendar,
  X,
  ShieldAlert,
  Loader2,
  Check,
  Upload,
  Image,
  FileText,
  Trash2,
  Archive,
  RefreshCw,
  AlertTriangle,
  Info,
  Paperclip,
} from 'lucide-react';
import { Language } from '../../../types';
import { MemberRecord, MemberStatus, MemberDocument } from '../../../types/member';
import { BrandingSettings } from '../../../types/dashboard';
import { memberService } from '../../../services/memberService';
import { formatCurrency, formatNumber } from '../../../utils/formatters';

interface AdminMemberDashboardProps {
  lang: Language;
  branding?: BrandingSettings;
  onSelectMember: (memberId: string) => void;
  onNavigateToApprovals?: () => void;
}

export const AdminMemberDashboard: React.FC<AdminMemberDashboardProps> = ({
  lang,
  branding,
  onSelectMember,
  onNavigateToApprovals,
}) => {
  const isBn = lang === 'bn';
  const [members, setMembers] = useState<MemberRecord[]>(() => memberService.getAllMembers());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'TABLE' | 'CARDS'>('TABLE');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState<MemberRecord | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<MemberRecord | null>(null);
  const [deleteBlockMessage, setDeleteBlockMessage] = useState<string | null>(null);

  // Settings Rates for Dynamic Calculations
  const admissionFeeSetting = branding?.admissionFeeDefault ?? 100;
  const insuranceRateSetting = branding?.insuranceRatePercent ?? 0.5;
  const initialSavingsRateSetting = branding?.initialSavingsRatePercent ?? 5.0;

  // New Member Form State
  const initialFormState = {
    fullNameBn: '',
    fullNameEn: '',
    fatherOrHusbandName: '',
    motherName: '',
    dateOfBirth: '',
    mobileNumber: '',
    nidNumber: '',
    address: '',
    occupation: '',

    // Member Documents
    photoUrl: '',
    agreementDocUrl: '',
    nidFrontUrl: '',
    nidBackUrl: '',

    // Dynamic Loan & Fees
    requestedInitialLoanAmount: 50000,
    admissionFeeRequired: admissionFeeSetting,
    admissionFeePaid: admissionFeeSetting,
    insuranceFeeRequired: Math.round(50000 * (insuranceRateSetting / 100)),
    insuranceFeePaid: Math.round(50000 * (insuranceRateSetting / 100)),
    initialSavingsRequired: Math.round(50000 * (initialSavingsRateSetting / 100)),
    initialSavingsPaid: Math.round(50000 * (initialSavingsRateSetting / 100)),

    // Nominee Info & Documents
    nomineeName: '',
    nomineeRelation: '',
    nomineeMobile: '',
    nomineeNid: '',
    nomineePhotoUrl: '',
    nomineeNidFrontUrl: '',
    nomineeNidBackUrl: '',

    // Guarantor Info & Documents
    guarantorName: '',
    guarantorMemberId: '',
    guarantorRelation: '',
    guarantorMobile: '',
    guarantorNid: '',
    guarantorOccupation: '',
    guarantorAddress: '',
    guarantorPhotoUrl: '',
    guarantorNidFrontUrl: '',
    guarantorNidBackUrl: '',
  };

  const [newMemberForm, setNewMemberForm] = useState(initialFormState);

  // Handle loan amount change to dynamically recalculate fee requirements
  const handleRequestedLoanChange = (amount: number) => {
    const calc = memberService.calculateInitialFees(amount, {
      admissionFeeDefault: admissionFeeSetting,
      insuranceRatePercent: insuranceRateSetting,
      initialSavingsRatePercent: initialSavingsRateSetting,
    });

    setNewMemberForm((prev) => ({
      ...prev,
      requestedInitialLoanAmount: amount,
      admissionFeeRequired: calc.admissionFee,
      admissionFeePaid: calc.admissionFee,
      insuranceFeeRequired: calc.insuranceFee,
      insuranceFeePaid: calc.insuranceFee,
      initialSavingsRequired: calc.initialSavings,
      initialSavingsPaid: calc.initialSavings,
    }));
  };

  // Helper for file upload preview to data URL
  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    field: keyof typeof newMemberForm
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setNewMemberForm((prev) => ({
        ...prev,
        [field]: result,
      }));
    };
    reader.readAsDataURL(file);
  };

  // Account Modal Form State
  const [accountUserId, setAccountUserId] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [accountMessage, setAccountMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmittingAccount, setIsSubmittingAccount] = useState(false);

  const refreshData = () => {
    setMembers(memberService.getAllMembers());
  };

  const metrics = useMemo(() => {
    return memberService.getDashboardMetrics();
  }, [members]);

  // Search & Filter
  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      const q = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !q ||
        m.id.toLowerCase().includes(q) ||
        m.fullNameBn.toLowerCase().includes(q) ||
        m.fullNameEn.toLowerCase().includes(q) ||
        m.mobileNumber.includes(q) ||
        (m.userId && m.userId.toLowerCase().includes(q)) ||
        m.nidNumber.includes(q);

      if (!matchesSearch) return false;

      if (statusFilter === 'ALL') return true;
      if (statusFilter === 'ACTIVE') return m.status === 'ACTIVE';
      if (statusFilter === 'INACTIVE') return m.status === 'INACTIVE' || m.status === 'SUSPENDED';
      if (statusFilter === 'ARCHIVED') return m.status === 'ARCHIVED';
      if (statusFilter === 'LOAN_ACTIVE') return m.currentLoanOutstanding > 0 || !!m.activeLoanId;
      if (statusFilter === 'ADMISSION_PENDING') return m.admissionFeeStatus !== 'PAID';
      if (statusFilter === 'NO_ACCOUNT') return !m.hasLoginAccount;
      return true;
    });
  }, [members, searchTerm, statusFilter]);

  const totalPages = Math.ceil(filteredMembers.length / pageSize) || 1;
  const paginatedMembers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredMembers.slice(start, start + pageSize);
  }, [filteredMembers, currentPage, pageSize]);

  // Handle Add Member Submit
  const handleAddMemberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberForm.fullNameBn.trim() || !newMemberForm.mobileNumber.trim()) {
      alert(isBn ? 'অনুগ্রহ করে সদস্যের নাম ও মোবাইল নম্বর পূরণ করুন।' : 'Please enter member name & mobile.');
      return;
    }

    // Prepare Documents Array
    const docs: MemberDocument[] = [];
    const nowStr = new Date().toISOString().split('T')[0];

    if (newMemberForm.photoUrl) {
      docs.push({
        id: `DOC-PHOTO-${Date.now()}`,
        type: 'MEMBER_PHOTO',
        category: 'MEMBER',
        title: 'সদস্যের প্রোফাইল ছবি',
        fileUrl: newMemberForm.photoUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.agreementDocUrl) {
      docs.push({
        id: `DOC-AGREE-${Date.now()}`,
        type: 'MEMBER_AGREEMENT',
        category: 'MEMBER',
        title: 'সদস্য চুক্তিপত্র / এগ্রিমেন্ট পেপার',
        fileUrl: newMemberForm.agreementDocUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.nidFrontUrl) {
      docs.push({
        id: `DOC-NIDF-${Date.now()}`,
        type: 'MEMBER_NID_FRONT',
        category: 'MEMBER',
        title: 'সদস্যের NID (সামনের অংশ)',
        fileUrl: newMemberForm.nidFrontUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.nidBackUrl) {
      docs.push({
        id: `DOC-NIDB-${Date.now()}`,
        type: 'MEMBER_NID_BACK',
        category: 'MEMBER',
        title: 'সদস্যের NID (পেছনের অংশ)',
        fileUrl: newMemberForm.nidBackUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.nomineePhotoUrl) {
      docs.push({
        id: `DOC-NOMP-${Date.now()}`,
        type: 'NOMINEE_PHOTO',
        category: 'NOMINEE',
        title: 'নমিনীর ছবি',
        fileUrl: newMemberForm.nomineePhotoUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.nomineeNidFrontUrl) {
      docs.push({
        id: `DOC-NOMF-${Date.now()}`,
        type: 'NOMINEE_NID_FRONT',
        category: 'NOMINEE',
        title: 'নমিনীর NID (সামনের অংশ)',
        fileUrl: newMemberForm.nomineeNidFrontUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.nomineeNidBackUrl) {
      docs.push({
        id: `DOC-NOMB-${Date.now()}`,
        type: 'NOMINEE_NID_BACK',
        category: 'NOMINEE',
        title: 'নমিনীর NID (পেছনের অংশ)',
        fileUrl: newMemberForm.nomineeNidBackUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.guarantorPhotoUrl) {
      docs.push({
        id: `DOC-GUAP-${Date.now()}`,
        type: 'GUARANTOR_PHOTO',
        category: 'GUARANTOR',
        title: 'জামিনদারের ছবি',
        fileUrl: newMemberForm.guarantorPhotoUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.guarantorNidFrontUrl) {
      docs.push({
        id: `DOC-GUAF-${Date.now()}`,
        type: 'GUARANTOR_NID_FRONT',
        category: 'GUARANTOR',
        title: 'জামিনদারের NID (সামনের অংশ)',
        fileUrl: newMemberForm.guarantorNidFrontUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    if (newMemberForm.guarantorNidBackUrl) {
      docs.push({
        id: `DOC-GUAB-${Date.now()}`,
        type: 'GUARANTOR_NID_BACK',
        category: 'GUARANTOR',
        title: 'জামিনদারের NID (পেছনের অংশ)',
        fileUrl: newMemberForm.guarantorNidBackUrl,
        uploadedAt: nowStr,
        uploadedBy: 'সুপার এডমিন (ভর্তি ফরম)',
      });
    }

    // Determine Fee Statuses
    const admStatus =
      newMemberForm.admissionFeePaid >= newMemberForm.admissionFeeRequired
        ? 'PAID'
        : newMemberForm.admissionFeePaid > 0
        ? 'PARTIAL'
        : 'PENDING';

    const insStatus =
      newMemberForm.insuranceFeePaid >= newMemberForm.insuranceFeeRequired
        ? 'PAID'
        : newMemberForm.insuranceFeePaid > 0
        ? 'PARTIAL'
        : 'PENDING';

    const savStatus =
      newMemberForm.initialSavingsPaid >= newMemberForm.initialSavingsRequired
        ? 'PAID'
        : newMemberForm.initialSavingsPaid > 0
        ? 'PARTIAL'
        : 'PENDING';

    memberService.createMember(
      {
        hasLoginAccount: false,
        fullNameBn: newMemberForm.fullNameBn,
        fullNameEn: newMemberForm.fullNameEn || newMemberForm.fullNameBn,
        fatherOrHusbandName: newMemberForm.fatherOrHusbandName,
        motherName: newMemberForm.motherName,
        dateOfBirth: newMemberForm.dateOfBirth,
        mobileNumber: newMemberForm.mobileNumber,
        nidNumber: newMemberForm.nidNumber,
        address: newMemberForm.address,
        occupation: newMemberForm.occupation,
        // Automatic profile photo linking
        photoUrl: newMemberForm.photoUrl || undefined,
        nidFrontUrl: newMemberForm.nidFrontUrl || undefined,
        nidBackUrl: newMemberForm.nidBackUrl || undefined,
        agreementDocUrl: newMemberForm.agreementDocUrl || undefined,
        admissionDate: nowStr,
        status: 'ACTIVE',

        requestedInitialLoanAmount: newMemberForm.requestedInitialLoanAmount,

        admissionFeeRequired: newMemberForm.admissionFeeRequired,
        admissionFeePaid: newMemberForm.admissionFeePaid,
        admissionFeeStatus: admStatus,

        insuranceFeeRequired: newMemberForm.insuranceFeeRequired,
        insuranceFeePaid: newMemberForm.insuranceFeePaid,
        insuranceStatus: insStatus,

        initialSavingsRequired: newMemberForm.initialSavingsRequired,
        initialSavingsPaid: newMemberForm.initialSavingsPaid,
        initialSavingsStatus: savStatus,

        nominee: newMemberForm.nomineeName
          ? {
              name: newMemberForm.nomineeName,
              relation: newMemberForm.nomineeRelation,
              mobile: newMemberForm.nomineeMobile,
              nid: newMemberForm.nomineeNid,
              sharePercent: 100,
              photoUrl: newMemberForm.nomineePhotoUrl || undefined,
              nidFrontUrl: newMemberForm.nomineeNidFrontUrl || undefined,
              nidBackUrl: newMemberForm.nomineeNidBackUrl || undefined,
            }
          : undefined,

        guarantor: newMemberForm.guarantorName
          ? {
              name: newMemberForm.guarantorName,
              memberId: newMemberForm.guarantorMemberId || undefined,
              relation: newMemberForm.guarantorRelation,
              mobile: newMemberForm.guarantorMobile,
              nid: newMemberForm.guarantorNid,
              occupation: newMemberForm.guarantorOccupation,
              address: newMemberForm.guarantorAddress,
              photoUrl: newMemberForm.guarantorPhotoUrl || undefined,
              nidFrontUrl: newMemberForm.guarantorNidFrontUrl || undefined,
              nidBackUrl: newMemberForm.guarantorNidBackUrl || undefined,
            }
          : undefined,

        documents: docs,
        totalLoansTakenCount: 0,
        totalLoanDisbursedAmount: 0,
        totalLoanPrincipalPaid: 0,
        totalLoanProfitPaid: 0,
        currentLoanOutstanding: 0,
        totalSavingsDeposits: newMemberForm.initialSavingsPaid,
        totalSavingsWithdrawals: 0,
        currentSavingsBalance: newMemberForm.initialSavingsPaid,
      },
      'সুপার এডমিন (SA-01)'
    );

    refreshData();
    setShowAddModal(false);
    setNewMemberForm(initialFormState);
  };

  // Handle Account Creation / Password Reset
  const handleAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showAccountModal) return;

    if (!accountUserId.trim() || !accountPassword.trim()) {
      setAccountMessage({ type: 'error', text: 'ইউজার আইডি ও পাসওয়ার্ড উভয়টি পূরণ করুন।' });
      return;
    }

    if (accountPassword.length < 6) {
      setAccountMessage({ type: 'error', text: 'পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।' });
      return;
    }

    setIsSubmittingAccount(true);
    setAccountMessage(null);

    try {
      let res;
      if (showAccountModal.hasLoginAccount) {
        res = await memberService.resetMemberPassword(
          showAccountModal.id,
          accountPassword,
          'সুপার এডমিন (SA-01)'
        );
      } else {
        res = await memberService.createMemberLoginAccount(
          showAccountModal.id,
          accountUserId,
          accountPassword,
          'সুপার এডমিন (SA-01)'
        );
      }

      if (res.success) {
        setAccountMessage({ type: 'success', text: res.message });
        refreshData();
        setTimeout(() => {
          setShowAccountModal(null);
          setAccountUserId('');
          setAccountPassword('');
          setAccountMessage(null);
        }, 1200);
      } else {
        setAccountMessage({ type: 'error', text: res.message });
      }
    } catch {
      setAccountMessage({ type: 'error', text: 'সার্ভার ত্রুটি, পুনরায় চেষ্টা করুন।' });
    } finally {
      setIsSubmittingAccount(false);
    }
  };

  // Handle Delete Confirmation
  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    const res = memberService.deleteMember(deleteTarget.id, 'সুপার এডমিন (SA-01)');
    if (res.canDelete) {
      refreshData();
      setDeleteTarget(null);
      setDeleteBlockMessage(null);
    } else {
      setDeleteBlockMessage(res.blockedReason || res.message);
    }
  };

  // Status updates: Deactivate, Archive, Reactivate
  const handleToggleMemberStatus = (m: MemberRecord, action: 'DEACTIVATE' | 'ARCHIVE' | 'ACTIVATE') => {
    if (action === 'DEACTIVATE') {
      memberService.deactivateMember(m.id, 'সুপার এডমিন (SA-01)');
    } else if (action === 'ARCHIVE') {
      memberService.archiveMember(m.id, 'সুপার এডমিন (SA-01)');
    } else {
      memberService.reactivateMember(m.id, 'সুপার এডমিন (SA-01)');
    }
    refreshData();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-emerald-800 font-bold uppercase tracking-widest block">
            BBL SOMITI MEMBER MANAGEMENT SYSTEM
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display mt-0.5">
            {isBn ? 'সদস্য ব্যবস্থাপনা ড্যাশবোর্ড' : 'Member Management Dashboard'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali mt-0.5">
            {isBn
              ? 'সদস্য ভর্তি, ডকুমেন্ট আপলোড, স্বয়ংক্রিয় ফি হিসাব ও প্রোফাইল থেকে লোন অনুমোদন'
              : 'Member admissions, comprehensive document storage, dynamic fee calculation, and direct loan approval'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer transition-all active:scale-95 font-bengali"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? 'নতুন সদস্য নিবন্ধন ফরম' : 'Register New Member'}</span>
          </button>
          {onNavigateToApprovals && (
            <button
              onClick={onNavigateToApprovals}
              className="px-4 py-2.5 rounded-xl border border-emerald-600 text-emerald-800 hover:bg-emerald-50 font-bold text-xs flex items-center gap-2 cursor-pointer transition-colors font-bengali"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>{isBn ? 'পেমেন্ট অনুমোদন কেন্দ্র' : 'Payment Approvals'}</span>
            </button>
          )}
        </div>
      </div>

      {/* 12 Modern Banking Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 sm:gap-4">
        {/* 1. Total Members */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-slate-600 font-bengali">
              {isBn ? 'মোট সদস্য' : 'Total Members'}
            </span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono">
            {formatNumber(metrics.totalMembers, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'নিবন্ধিত মাস্টার তালিকা' : 'Registered master'}
          </span>
        </div>

        {/* 2. Active Members */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-emerald-800 font-bengali">
              {isBn ? 'সক্রিয় সদস্য' : 'Active Members'}
            </span>
            <UserCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono">
            {formatNumber(metrics.activeMembers, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'নিয়মিত কার্যক্রম' : 'Operational accounts'}
          </span>
        </div>

        {/* 3. Inactive Members */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-slate-600 font-bengali">
              {isBn ? 'নিষ্ক্রিয় সদস্য' : 'Inactive'}
            </span>
            <UserX className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-700 font-mono">
            {formatNumber(metrics.inactiveMembers, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'স্থগিত বা নিষ্ক্রিয়' : 'Dormant or suspended'}
          </span>
        </div>

        {/* 4. Total Loan Disbursed */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-blue-900 font-bengali">
              {isBn ? 'মোট বিতরণকৃত ঋণ' : 'Disbursed Loans'}
            </span>
            <CreditCard className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-blue-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalLoanDisbursed, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'অনুমোদিত ও বিতরণ' : 'Approved principals'}
          </span>
        </div>

        {/* 5. Principal Recovered */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-emerald-800 font-bengali">
              {isBn ? 'ঋণ মূলধন আদায়' : 'Principal Recovered'}
            </span>
            <TrendingDown className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatCurrency(metrics.totalLoanPrincipalRecovered, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'ফেরতপ্রাপ্ত মূলধন' : 'Repaid principal'}
          </span>
        </div>

        {/* 6. Profit Recovered */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-indigo-900 font-bengali">
              {isBn ? 'ঋণ মুনাফা আদায়' : 'Profit Recovered'}
            </span>
            <TrendingUp className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-indigo-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalLoanProfitRecovered, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'সমিতির অর্জিত আয়' : 'Earned revenue'}
          </span>
        </div>

        {/* 7. Outstanding Principal */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-amber-900 font-bengali">
              {isBn ? 'বকেয়া ঋণ মূলধন' : 'Outstanding Principal'}
            </span>
            <AlertCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-amber-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalOutstandingLoanPrincipal, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'আদায়যোগ্য ব্যালেন্স' : 'Receivable'}
          </span>
        </div>

        {/* 8. Admission Fees */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-teal-900 font-bengali">
              {isBn ? 'মোট ভর্তি ফি' : 'Admission Fees'}
            </span>
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-teal-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalAdmissionFeesCollected, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'নিবন্ধন রাজস্ব আয়' : 'Admission collection'}
          </span>
        </div>

        {/* 9. Insurance Fund */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-cyan-900 font-bengali">
              {isBn ? 'ইনস্যুরেন্স ফান্ড' : 'Insurance Fund'}
            </span>
            <ShieldCheck className="w-4 h-4 text-cyan-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-cyan-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalInsuranceCollected, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'ঝুঁকি ও নিরাপত্তা তহবিল' : 'Welfare & reserve'}
          </span>
        </div>

        {/* 10. Savings Deposits */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-emerald-900 font-bengali">
              {isBn ? 'মোট সঞ্চয় জমা' : 'Savings Deposited'}
            </span>
            <PiggyBank className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-emerald-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalSavingsDeposits, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'অনুমোদিত সঞ্চয় আমানত' : 'Total member deposits'}
          </span>
        </div>

        {/* 11. Savings Withdrawals */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold text-rose-900 font-bengali">
              {isBn ? 'সঞ্চয় উত্তোলন' : 'Savings Withdrawn'}
            </span>
            <TrendingDown className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-rose-900 font-mono tabular-nums">
            {formatCurrency(metrics.totalSavingsWithdrawals, lang)}
          </div>
          <span className="text-[10px] text-slate-400 font-bengali block">
            {isBn ? 'ফেরতকৃত আমানত' : 'Disbursed savings'}
          </span>
        </div>

        {/* 12. Net Savings Balance */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-700 to-teal-800 text-white shadow-md space-y-1">
          <div className="flex items-center justify-between text-emerald-100">
            <span className="text-[11px] font-bold font-bengali">
              {isBn ? 'বর্তমান সঞ্চয় স্থিতি' : 'Net Savings Balance'}
            </span>
            <Wallet className="w-4 h-4 text-emerald-200" />
          </div>
          <div className="text-lg sm:text-xl font-extrabold font-mono tabular-nums text-white">
            {formatCurrency(metrics.currentSavingsBalance, lang)}
          </div>
          <span className="text-[10px] text-emerald-200 font-bengali block">
            {isBn ? 'জমা − উত্তোলন' : 'Net liability'}
          </span>
        </div>
      </div>

      {/* Member Master List Toolbar */}
      <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            placeholder={isBn ? 'সদস্য আইডি, নাম, মোবাইল বা ইউজার আইডি খুঁজুন...' : 'Search Member ID, name, mobile or User ID...'}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 font-bengali"
          />
        </div>

        {/* Filter and View Toggles */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-slate-600 font-bengali">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="py-1.5 px-3 rounded-xl border border-slate-300 text-xs text-slate-800 bg-white focus:outline-none font-bengali"
            >
              <option value="ALL">{isBn ? 'সকল সদস্য (All)' : 'All Members'}</option>
              <option value="ACTIVE">{isBn ? 'সক্রিয় সদস্য (Active)' : 'Active Members'}</option>
              <option value="INACTIVE">{isBn ? 'নিষ্ক্রিয় সদস্য (Inactive)' : 'Inactive Members'}</option>
              <option value="ARCHIVED">{isBn ? 'আর্কাইভকৃত (Archived)' : 'Archived Members'}</option>
              <option value="LOAN_ACTIVE">{isBn ? 'চলমান ঋণ আছে' : 'Active Loan'}</option>
              <option value="ADMISSION_PENDING">{isBn ? 'ভর্তি ফি বকেয়া' : 'Admission Pending'}</option>
              <option value="NO_ACCOUNT">{isBn ? 'লগইন একাউন্ট নেই' : 'No Login Account'}</option>
            </select>
          </div>

          <div className="flex items-center rounded-xl border border-slate-300 p-0.5 bg-slate-100">
            <button
              onClick={() => setViewMode('TABLE')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'TABLE' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {isBn ? 'টেবিল' : 'Table'}
            </button>
            <button
              onClick={() => setViewMode('CARDS')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'CARDS' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {isBn ? 'কার্ড' : 'Cards'}
            </button>
          </div>
        </div>
      </div>

      {/* Member List Content */}
      {filteredMembers.length === 0 ? (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-10 text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Users className="w-8 h-8" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-base font-bold text-slate-900 font-display">
              {isBn ? 'কোনো সদস্য রেকর্ড পাওয়া যায়নি' : 'No Member Records Found'}
            </h3>
            <p className="text-xs text-slate-500 font-bengali leading-relaxed">
              {searchTerm || statusFilter !== 'ALL'
                ? (isBn ? 'আপনার ফিল্টারের সাথে মিল রেখে কোনো সদস্য পাওয়া যায়নি।' : 'No members matched your search criteria.')
                : (isBn ? 'সিস্টেমে বর্তমানে কোনো সদস্যের তথ্য নেই। শুরু করতে নতুন সদস্য নিবন্ধন করুন।' : 'There are currently no registered members. Register a new member to begin.')}
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs font-bengali cursor-pointer inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? 'নতুন সদস্য নিবন্ধন করুন' : 'Register New Member'}</span>
          </button>
        </div>
      ) : viewMode === 'TABLE' ? (
        <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-bengali">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono tracking-wider">
                  <th className="py-3 px-4">{isBn ? 'সদস্য তথ্য' : 'Member'}</th>
                  <th className="py-3 px-4">{isBn ? 'মেম্বার আইডি' : 'Member ID'}</th>
                  <th className="py-3 px-4">{isBn ? 'মোবাইল' : 'Mobile'}</th>
                  <th className="py-3 px-4">{isBn ? 'লগইন একাউন্ট' : 'User ID'}</th>
                  <th className="py-3 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                  <th className="py-3 px-4">{isBn ? 'ঋণ বিবরণী' : 'Loan Status'}</th>
                  <th className="py-3 px-4">{isBn ? 'বকেয়া ঋণ' : 'Outstanding'}</th>
                  <th className="py-3 px-4">{isBn ? 'পরবর্তী কিস্তি' : 'Next Due'}</th>
                  <th className="py-3 px-4 text-right">{isBn ? 'অ্যাকশন ও নিয়ন্ত্রণ' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedMembers.map((m) => {
                  const hasLoan = m.currentLoanOutstanding > 0 || !!m.activeLoanId;
                  return (
                    <tr key={m.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-slate-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-slate-600 text-xs border border-slate-300">
                            {m.photoUrl ? (
                              <img src={m.photoUrl} alt={m.fullNameBn} className="w-full h-full object-cover" />
                            ) : (
                              m.fullNameBn.slice(0, 1) || 'B'
                            )}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 block leading-tight">
                              {m.fullNameBn}
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono block">
                              {m.fullNameEn}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-blue-700">
                        {m.id}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {m.mobileNumber}
                      </td>
                      <td className="py-3 px-4">
                        {m.hasLoginAccount ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-mono text-[11px] font-bold border border-emerald-200">
                            <Check className="w-3 h-3 text-emerald-600" />
                            {m.userId}
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              setShowAccountModal(m);
                              setAccountUserId(`mem_${m.id.replace('BBL-', '').toLowerCase()}`);
                              setAccountPassword('');
                              setAccountMessage(null);
                            }}
                            className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-800 hover:underline cursor-pointer"
                          >
                            <KeyRound className="w-3 h-3" />
                            <span>{isBn ? '+ একাউন্ট তৈরি' : '+ Create Account'}</span>
                          </button>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                            m.status === 'ACTIVE'
                              ? 'bg-emerald-100 text-emerald-800'
                              : m.status === 'ARCHIVED'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {m.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        {hasLoan ? (
                          <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-900 border border-amber-200 text-[10px] font-bold">
                            {isBn ? 'চলমান ঋণ' : 'Active Loan'}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">
                            {isBn ? 'কোনো ঋণ নেই' : 'No Loan'}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">
                        {formatCurrency(m.currentLoanOutstanding, lang)}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">
                        {m.nextInstallmentDate || '—'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onSelectMember(m.id)}
                            className="p-1.5 rounded-lg text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
                            title={isBn ? 'প্রোফাইল দেখুন' : 'View Profile'}
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              setShowAccountModal(m);
                              setAccountUserId(m.userId || `mem_${m.id.replace('BBL-', '').toLowerCase()}`);
                              setAccountPassword('');
                              setAccountMessage(null);
                            }}
                            className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                            title={isBn ? 'লগইন একাউন্ট পরিচালনা' : 'Manage Account'}
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>
                          {m.status === 'ACTIVE' ? (
                            <button
                              onClick={() => handleToggleMemberStatus(m, 'DEACTIVATE')}
                              className="p-1.5 rounded-lg text-amber-700 hover:bg-amber-50 transition-colors cursor-pointer"
                              title={isBn ? 'সদস্য নিষ্ক্রিয় করুন (Deactivate)' : 'Deactivate Member'}
                            >
                              <UserX className="w-4 h-4" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleToggleMemberStatus(m, 'ACTIVATE')}
                              className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                              title={isBn ? 'পুনরায় সক্রিয় করুন' : 'Reactivate'}
                            >
                              <UserCheck className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => {
                              setDeleteTarget(m);
                              setDeleteBlockMessage(null);
                            }}
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title={isBn ? 'সদস্য ডিলিট করুন' : 'Delete Member'}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Card Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {paginatedMembers.map((m) => {
            const hasLoan = m.currentLoanOutstanding > 0 || !!m.activeLoanId;
            return (
              <div
                key={m.id}
                className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4 hover:border-blue-400 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-slate-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-slate-700 text-sm border border-slate-300">
                      {m.photoUrl ? (
                        <img src={m.photoUrl} alt={m.fullNameBn} className="w-full h-full object-cover" />
                      ) : (
                        m.fullNameBn.slice(0, 1) || 'B'
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm leading-tight font-bengali">
                        {m.fullNameBn}
                      </h4>
                      <span className="text-xs font-mono font-bold text-blue-700 block">
                        {m.id}
                      </span>
                    </div>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      m.status === 'ACTIVE'
                        ? 'bg-emerald-100 text-emerald-800'
                        : m.status === 'ARCHIVED'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {m.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 font-bengali pt-2 border-t border-slate-100">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">{isBn ? 'মোবাইল:' : 'Mobile:'}</span>
                    <span className="font-mono font-semibold text-slate-800">{m.mobileNumber}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">{isBn ? 'ইউজার আইডি:' : 'User ID:'}</span>
                    <span className="font-mono text-emerald-800 font-semibold">{m.userId || '—'}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">{isBn ? 'বকেয়া ঋণ:' : 'Outstanding:'}</span>
                    <span className="font-mono font-bold text-slate-900">
                      {formatCurrency(m.currentLoanOutstanding, lang)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">{isBn ? 'সঞ্চয় ব্যালেন্স:' : 'Savings:'}</span>
                    <span className="font-mono font-bold text-emerald-800">
                      {formatCurrency(m.currentSavingsBalance, lang)}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1.5">
                  <button
                    onClick={() => onSelectMember(m.id)}
                    className="flex-1 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center gap-1.5 font-bengali cursor-pointer transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{isBn ? 'প্রোফাইল' : 'Profile'}</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowAccountModal(m);
                      setAccountUserId(m.userId || `mem_${m.id.replace('BBL-', '').toLowerCase()}`);
                      setAccountPassword('');
                      setAccountMessage(null);
                    }}
                    className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer transition-colors"
                    title={isBn ? 'লগইন একাউন্ট' : 'Account'}
                  >
                    <KeyRound className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setDeleteTarget(m);
                      setDeleteBlockMessage(null);
                    }}
                    className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs cursor-pointer transition-colors"
                    title={isBn ? 'সদস্য ডিলিট' : 'Delete'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-2xs flex items-center justify-between">
          <span className="text-xs text-slate-500 font-bengali">
            {isBn
              ? `মোট ${formatNumber(filteredMembers.length, lang)} জন সদস্যের মধ্যে ${formatNumber(
                  (currentPage - 1) * pageSize + 1,
                  lang
                )} - ${formatNumber(Math.min(currentPage * pageSize, filteredMembers.length), lang)} দেখানো হচ্ছে`
              : `Showing ${(currentPage - 1) * pageSize + 1} - ${Math.min(
                  currentPage * pageSize,
                  filteredMembers.length
                )} of ${filteredMembers.length} members`}
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono font-bold text-slate-700">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* MODAL 1: REGISTER NEW MEMBER (FULL DOCUMENT UPLOADS & DYNAMIC FEES) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-display">
                    {isBn ? 'সদস্য ভর্তি ও পূর্ণাঙ্গ নথি নিবন্ধন ফরম' : 'Member Admission & Documentation'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isBn
                      ? 'ব্যক্তিগত তথ্য, এগ্রিমেন্ট, ভোটার আইডি, নমিনী ও জামিনদারের সকল নথি আপলোড করুন'
                      : 'Provide personal details, agreement, NID, nominee, and guarantor documents'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMemberSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
              {/* SECTION 1: PERSONAL INFORMATION */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                    <span>১. সদস্যের ব্যক্তিগত তথ্য</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পূর্ণ নাম (বাংলায়) *</label>
                    <input
                      type="text"
                      required
                      value={newMemberForm.fullNameBn}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, fullNameBn: e.target.value })}
                      placeholder="উদাঃ মোঃ রফিকুল ইসলাম"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Full Name (English)</label>
                    <input
                      type="text"
                      value={newMemberForm.fullNameEn}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, fullNameEn: e.target.value })}
                      placeholder="e.g. Md. Rafiqul Islam"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর * (১১ ডিজিট)</label>
                    <input
                      type="tel"
                      required
                      value={newMemberForm.mobileNumber}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, mobileNumber: e.target.value })}
                      placeholder="017XXXXXXXX"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">জাতীয় পরিচয়পত্র (NID) নম্বর *</label>
                    <input
                      type="text"
                      required
                      value={newMemberForm.nidNumber}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, nidNumber: e.target.value })}
                      placeholder="১০ বা ১৭ ডিজিট"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পিতা / স্বামীর নাম</label>
                    <input
                      type="text"
                      value={newMemberForm.fatherOrHusbandName}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, fatherOrHusbandName: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মাতার নাম</label>
                    <input
                      type="text"
                      value={newMemberForm.motherName}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, motherName: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">জন্ম তারিখ</label>
                    <input
                      type="date"
                      value={newMemberForm.dateOfBirth}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, dateOfBirth: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পেশা</label>
                    <input
                      type="text"
                      value={newMemberForm.occupation}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, occupation: e.target.value })}
                      placeholder="উদাঃ ব্যবসায়ী, কৃষক, শিক্ষক"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2 lg:col-span-1">
                    <label className="block font-bold text-slate-700 mb-1">ঠিকানা</label>
                    <input
                      type="text"
                      value={newMemberForm.address}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, address: e.target.value })}
                      placeholder="গ্রাম/রোড, ডাকঘর, উপজেলা, জেলা"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: MEMBER'S OWN DOCUMENTS */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                    <span>২. সদস্যের নিজস্ব ডকুমেন্টস (ফাইল / ছবি আপলোড)</span>
                  </h4>
                  <span className="text-[11px] text-blue-700 font-bold">
                    সদস্যের ছবি স্বয়ংক্রিয়ভাবে তার প্রোফাইলে সেট হবে
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {/* Member Photo */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="font-bold text-slate-800 block">সদস্যের ছবি (প্রোফাইল ফটো) *</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'photoUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-blue-100 file:text-blue-800 cursor-pointer"
                    />
                    {newMemberForm.photoUrl && (
                      <div className="w-14 h-14 rounded-xl overflow-hidden border border-blue-400 mt-1">
                        <img src={newMemberForm.photoUrl} alt="Member Preview" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>

                  {/* Member Signed Agreement */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="font-bold text-slate-800 block">চুক্তিপত্র / এগ্রিমেন্ট পেপার</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => handleFileUpload(e, 'agreementDocUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-blue-100 file:text-blue-800 cursor-pointer"
                    />
                    {newMemberForm.agreementDocUrl && (
                      <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> ফাইল সংযুক্ত হয়েছে
                      </span>
                    )}
                  </div>

                  {/* Member NID Front */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="font-bold text-slate-800 block">ভোটার আইডি (সামনের অংশ) *</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'nidFrontUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-blue-100 file:text-blue-800 cursor-pointer"
                    />
                    {newMemberForm.nidFrontUrl && (
                      <div className="w-16 h-10 rounded-lg overflow-hidden border border-blue-400 mt-1">
                        <img src={newMemberForm.nidFrontUrl} alt="NID Front" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>

                  {/* Member NID Back */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="font-bold text-slate-800 block">ভোটার আইডি (পেছনের অংশ) *</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'nidBackUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2.5 file:rounded-lg file:border-0 file:text-[11px] file:font-bold file:bg-blue-100 file:text-blue-800 cursor-pointer"
                    />
                    {newMemberForm.nidBackUrl && (
                      <div className="w-16 h-10 rounded-lg overflow-hidden border border-blue-400 mt-1">
                        <img src={newMemberForm.nidBackUrl} alt="NID Back" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* SECTION 3: REQUESTED LOAN & DYNAMIC INITIAL FEES CALCULATION */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                    <span>৩. লোনের পরিমাণ অনুযায়ী ভর্তি ফি, ইনস্যুরেন্স ও প্রাথমিক আমানত</span>
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Settings: ভর্তি ফি ৳{admissionFeeSetting} · ইনস্যুরেন্স {insuranceRateSetting}% · সঞ্চয় {initialSavingsRateSetting}%
                  </span>
                </div>

                {/* Requested Loan Input */}
                <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <label className="block font-bold text-blue-950 text-xs">
                      আবেদনকৃত লোনের পরিমাণ (Requested Loan Amount) *
                    </label>
                    <p className="text-[11px] text-blue-800">
                      সদস্য কত টাকা লোন নিতে চায় তা লিখুন; সিস্টেম স্বয়ংক্রিয়ভাবে প্রযোজ্য ফি হিসাব করবে।
                    </p>
                  </div>
                  <div className="sm:w-56">
                    <input
                      type="number"
                      step={5000}
                      value={newMemberForm.requestedInitialLoanAmount}
                      onChange={(e) => handleRequestedLoanChange(Number(e.target.value))}
                      placeholder="৫০,০০০"
                      className="w-full p-2.5 rounded-xl border border-blue-300 font-mono font-extrabold text-sm text-blue-950 bg-white text-right focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>

                {/* Dynamic Calculation Cards with Edit Support */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Admission Fee */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-800">ভর্তি ফি (টাকা)</span>
                      <span className="text-[10px] text-slate-500 font-mono">নির্ধারিত: ৳{newMemberForm.admissionFeeRequired}</span>
                    </div>
                    <input
                      type="number"
                      value={newMemberForm.admissionFeePaid}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, admissionFeePaid: Number(e.target.value) })}
                      className="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 bg-white"
                    />
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-500">পরিশোধের অবস্থা:</span>
                      <span
                        className={`font-bold font-mono ${
                          newMemberForm.admissionFeePaid >= newMemberForm.admissionFeeRequired
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {newMemberForm.admissionFeePaid >= newMemberForm.admissionFeeRequired ? 'পরিশোধিত (PAID)' : 'বকেয়া (DUE)'}
                      </span>
                    </div>
                  </div>

                  {/* Insurance Fund */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-800">ইনস্যুরেন্স ফান্ড (টাকা)</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        হার: {insuranceRateSetting}% (৳{newMemberForm.insuranceFeeRequired})
                      </span>
                    </div>
                    <input
                      type="number"
                      value={newMemberForm.insuranceFeePaid}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, insuranceFeePaid: Number(e.target.value) })}
                      className="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 bg-white"
                    />
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-500">পরিশোধের অবস্থা:</span>
                      <span
                        className={`font-bold font-mono ${
                          newMemberForm.insuranceFeePaid >= newMemberForm.insuranceFeeRequired
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {newMemberForm.insuranceFeePaid >= newMemberForm.insuranceFeeRequired ? 'পরিশোধিত (PAID)' : 'বকেয়া (DUE)'}
                      </span>
                    </div>
                  </div>

                  {/* Initial Savings */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-800">প্রাথমিক সঞ্চয় আমানত (টাকা)</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        হার: {initialSavingsRateSetting}% (৳{newMemberForm.initialSavingsRequired})
                      </span>
                    </div>
                    <input
                      type="number"
                      value={newMemberForm.initialSavingsPaid}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, initialSavingsPaid: Number(e.target.value) })}
                      className="w-full p-2 rounded-lg border border-slate-300 font-mono font-bold text-slate-900 bg-white"
                    />
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-500">পরিশোধের অবস্থা:</span>
                      <span
                        className={`font-bold font-mono ${
                          newMemberForm.initialSavingsPaid >= newMemberForm.initialSavingsRequired
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {newMemberForm.initialSavingsPaid >= newMemberForm.initialSavingsRequired ? 'পরিশোধিত (PAID)' : 'বকেয়া (DUE)'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Total Initial Requirement Banner */}
                <div className="p-3.5 rounded-2xl bg-slate-100 flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-700">
                    মোট প্রয়োজনীয় প্রাথমিক জমা: <strong>৳{newMemberForm.admissionFeeRequired + newMemberForm.insuranceFeeRequired + newMemberForm.initialSavingsRequired}</strong>
                  </span>
                  <span className="font-mono text-emerald-800 font-extrabold text-sm">
                    দাখিলকৃত জমা: ৳{newMemberForm.admissionFeePaid + newMemberForm.insuranceFeePaid + newMemberForm.initialSavingsPaid}
                  </span>
                </div>
              </div>

              {/* SECTION 4: NOMINEE INFORMATION & DOCUMENTS */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-purple-900 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                    <span>৪. নমিনীর তথ্য ও ডকুমেন্টস</span>
                  </h4>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">নমিনীর পূর্ণ নাম</label>
                    <input
                      type="text"
                      value={newMemberForm.nomineeName}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, nomineeName: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">সম্পর্ক</label>
                    <input
                      type="text"
                      value={newMemberForm.nomineeRelation}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, nomineeRelation: e.target.value })}
                      placeholder="উদাঃ স্ত্রী, পুত্র, কন্যা, মাতা"
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                    <input
                      type="tel"
                      value={newMemberForm.nomineeMobile}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, nomineeMobile: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ভোটার আইডি (NID) নম্বর</label>
                    <input
                      type="text"
                      value={newMemberForm.nomineeNid}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, nomineeNid: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-purple-50/50 border border-purple-200">
                    <span className="font-bold text-slate-800 block mb-1">নমিনীর ছবি</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'nomineePhotoUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-purple-100 file:text-purple-800 cursor-pointer"
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-purple-50/50 border border-purple-200">
                    <span className="font-bold text-slate-800 block mb-1">নমিনীর NID (সামনের অংশ)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'nomineeNidFrontUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-purple-100 file:text-purple-800 cursor-pointer"
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-purple-50/50 border border-purple-200">
                    <span className="font-bold text-slate-800 block mb-1">নমিনীর NID (পেছনের অংশ)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'nomineeNidBackUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-purple-100 file:text-purple-800 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 5: GUARANTOR (জামিনদার) INFORMATION & DOCUMENTS */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <h4 className="text-xs font-bold text-teal-900 uppercase tracking-wider flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-teal-600"></span>
                    <span>৫. জামিনদার (Guarantor)-এর তথ্য ও ডকুমেন্টস</span>
                  </h4>
                  <span className="text-[11px] text-teal-800 font-bold">
                    নমিনি এবং জামিনদার দুটি সম্পূর্ণ পৃথক ব্যক্তি
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">জামিনদারের পূর্ণ নাম *</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorName}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorName: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">সমিতির মেম্বার আইডি (যদি সদস্য হন)</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorMemberId}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorMemberId: e.target.value })}
                      placeholder="উদাঃ BBL-005"
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">সম্পর্ক</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorRelation}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorRelation: e.target.value })}
                      placeholder="উদাঃ ভাই, সহকর্মী, প্রতিবেশী"
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর *</label>
                    <input
                      type="tel"
                      value={newMemberForm.guarantorMobile}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorMobile: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ভোটার আইডি (NID) নম্বর</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorNid}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorNid: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">পেশা</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorOccupation}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorOccupation: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-bold text-slate-700 mb-1">জামিনদারের ঠিকানা</label>
                    <input
                      type="text"
                      value={newMemberForm.guarantorAddress}
                      onChange={(e) => setNewMemberForm({ ...newMemberForm, guarantorAddress: e.target.value })}
                      placeholder="গ্রাম/রোড, উপজেলা, জেলা"
                      className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-teal-50/50 border border-teal-200">
                    <span className="font-bold text-slate-800 block mb-1">জামিনদারের ছবি</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'guarantorPhotoUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-teal-100 file:text-teal-800 cursor-pointer"
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-teal-50/50 border border-teal-200">
                    <span className="font-bold text-slate-800 block mb-1">জামিনদারের NID (সামনের অংশ)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'guarantorNidFrontUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-teal-100 file:text-teal-800 cursor-pointer"
                    />
                  </div>
                  <div className="p-3 rounded-xl bg-teal-50/50 border border-teal-200">
                    <span className="font-bold text-slate-800 block mb-1">জামিনদারের NID (পেছনের অংশ)</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 'guarantorNidBackUrl')}
                      className="w-full text-[11px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-[10px] file:font-bold file:bg-teal-100 file:text-teal-800 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3 sticky bottom-0 bg-white py-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 text-white font-bold text-xs shadow-md cursor-pointer"
                >
                  সদস্য ও সমস্ত নথি সফলভাবে সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CREATE MEMBER LOGIN ACCOUNT & PASSWORD MANAGEMENT */}
      {showAccountModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-display">
                    {showAccountModal.hasLoginAccount ? 'পাসওয়ার্ড পরিবর্তন / রিসেট' : 'সদস্য লগইন একাউন্ট তৈরি'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {showAccountModal.fullNameBn} ({showAccountModal.id})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAccountModal(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAccountSubmit} className="p-6 space-y-4 text-xs font-bengali">
              {accountMessage && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    accountMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{accountMessage.text}</span>
                </div>
              )}

              {/* User ID Field */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-700">ইউজার আইডি (User ID)</label>
                <input
                  type="text"
                  required
                  disabled={showAccountModal.hasLoginAccount}
                  value={accountUserId}
                  onChange={(e) => setAccountUserId(e.target.value)}
                  placeholder="উদাঃ mem_001"
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono disabled:bg-slate-100 disabled:text-slate-500 focus:border-blue-600 focus:outline-none"
                />
              </div>

              {/* Password Field */}
              <div className="space-y-1">
                <label className="block font-bold text-slate-700">
                  {showAccountModal.hasLoginAccount ? 'নতুন পাসওয়ার্ড' : 'প্রাথমিক পাসওয়ার্ড'} (SHA-256 সুরক্ষিত)
                </label>
                <input
                  type="password"
                  required
                  value={accountPassword}
                  onChange={(e) => setAccountPassword(e.target.value)}
                  placeholder="কমপক্ষে ৬ অক্ষর বা সংখ্যা"
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono focus:border-blue-600 focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAccountModal(null)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-50 cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAccount}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold shadow-md cursor-pointer flex items-center gap-2 disabled:opacity-75"
                >
                  {isSubmittingAccount ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>প্রক্রিয়াকরণ...</span>
                    </>
                  ) : (
                    <span>{showAccountModal.hasLoginAccount ? 'পাসওয়ার্ড পরিবর্তন করুন' : 'একাউন্ট সক্রিয় করুন'}</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: DELETE MEMBER CONFIRMATION & FINANCIAL SAFETY CHECK */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-rose-50/80">
              <div className="flex items-center gap-2.5 text-rose-800">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold font-display">সদস্য মুছে ফেলার যাচাইকরণ</h3>
              </div>
              <button
                onClick={() => {
                  setDeleteTarget(null);
                  setDeleteBlockMessage(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">সদস্যের নাম:</span>
                  <span className="font-bold text-slate-900">{deleteTarget.fullNameBn}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">মেম্বার আইডি:</span>
                  <span className="font-mono font-bold text-blue-700">{deleteTarget.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">বর্তমান বকেয়া ঋণ:</span>
                  <span className="font-mono font-bold text-amber-800">৳{deleteTarget.currentLoanOutstanding}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">সঞ্চয় আমানত স্থিতি:</span>
                  <span className="font-mono font-bold text-emerald-800">৳{deleteTarget.currentSavingsBalance}</span>
                </div>
              </div>

              {deleteBlockMessage ? (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 space-y-2">
                  <div className="font-bold flex items-center gap-1.5 text-rose-700">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <span>আর্থিক নিরাপত্তার বিধিনিষেধ: ডিলিট স্থগিত</span>
                  </div>
                  <p className="leading-relaxed">{deleteBlockMessage}</p>
                  <div className="pt-2 border-t border-rose-200 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        handleToggleMemberStatus(deleteTarget, 'DEACTIVATE');
                        setDeleteTarget(null);
                        setDeleteBlockMessage(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-600 text-white font-bold"
                    >
                      নিষ্ক্রিয় (Deactivate) করুন
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleToggleMemberStatus(deleteTarget, 'ARCHIVE');
                        setDeleteTarget(null);
                        setDeleteBlockMessage(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 text-white font-bold"
                    >
                      আর্কাইভ (Archive) করুন
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-slate-600 leading-relaxed">
                    আপনি কি নিশ্চিত যে আপনি <strong>{deleteTarget.fullNameBn} ({deleteTarget.id})</strong>-এর রেকর্ড স্থায়ীভাবে মুছে ফেলতে চান?
                  </p>
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px]">
                    নোট: সদস্যের কোনো আর্থিক খতিয়ান, ঋণ বা সঞ্চয় থাকলে অডিট নিরাপত্তার কারণে ডিলিট প্রতিরোধ করা হবে।
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(null)}
                      className="px-4 py-2 rounded-xl border border-slate-300 font-bold"
                    >
                      বাতিল
                    </button>
                    <button
                      type="button"
                      onClick={handleDeleteConfirm}
                      className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold cursor-pointer"
                    >
                      যাচাই করে মুছে ফেলুন
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
