import React, { useState } from 'react';
import {
  X,
  PlusCircle,
  Briefcase,
  Users,
  PiggyBank,
  ArrowDownLeft,
  HandCoins,
  ShieldAlert,
  CreditCard,
  Building2,
  Receipt,
  CheckCircle2,
  AlertCircle,
  Upload,
} from 'lucide-react';
import { Language } from '../../types/dashboard';

interface QuickActionsModalProps {
  lang: Language;
  onClose: () => void;
  onSubmitTransactionRequest: (data: {
    type: string;
    targetId: string;
    amount: number;
    paymentMethod: string;
    reference: string;
    notes: string;
  }) => void;
}

export const QuickActionsModal: React.FC<QuickActionsModalProps> = ({
  lang,
  onClose,
  onSubmitTransactionRequest,
}) => {
  const isBn = lang === 'bn';

  const actionTypes = [
    { id: 'PARTNER_DEPOSIT', icon: Briefcase, labelBn: 'পার্টনারের মূলধন জমা', labelEn: 'Partner Capital Deposit' },
    { id: 'MEMBER_SAVINGS_DEPOSIT', icon: PiggyBank, labelBn: 'সদস্যের সাধারণ সঞ্চয় জমা', labelEn: 'Member Savings Deposit' },
    { id: 'MEMBER_SAVINGS_WITHDRAWAL', icon: ArrowDownLeft, labelBn: 'সদস্যের সঞ্চয় উত্তোলন আবেদন', labelEn: 'Savings Withdrawal Request' },
    { id: 'LOAN_COLLECTION', icon: HandCoins, labelBn: 'ঋণ কিস্তি আদায়', labelEn: 'Loan Installment Collection' },
    { id: 'LOAN_DISBURSEMENT_REQ', icon: HandCoins, labelBn: 'নতুন ঋণ বিতরণ আবেদন', labelEn: 'Loan Disbursement Request' },
    { id: 'INSURANCE_COLLECTION', icon: ShieldAlert, labelBn: 'ইনস্যুরেন্স প্রিমিয়াম জমা', labelEn: 'Insurance Premium Collection' },
    { id: 'ADMISSION_FEE_COLLECTION', icon: CreditCard, labelBn: 'ভর্তি ফি আদায় (১০০ টাকা)', labelEn: 'Admission Fee Collection' },
    { id: 'BUSINESS_INVESTMENT', icon: Building2, labelBn: 'ব্যবসায়িক প্রকল্পে বিনিয়োগ', labelEn: 'Business Enterprise Investment' },
    { id: 'APPROVED_EXPENSE', icon: Receipt, labelBn: 'অনুমোদিত অফিস খরচ এন্ট্রি', labelEn: 'Approved Operating Expense' },
  ];

  const [selectedType, setSelectedType] = useState<string>('MEMBER_SAVINGS_DEPOSIT');
  const [targetId, setTargetId] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('CASH');
  const [reference, setReference] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetId.trim()) {
      setError(isBn ? 'অনুগ্রহ করে সদস্য / পার্টনার / ভাউচার আইডি দিন।' : 'Please enter target ID / Member ID.');
      return;
    }
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError(isBn ? 'সঠিক টাকার পরিমাণ উল্লেখ করুন (ধনাত্মক সংখ্যা)।' : 'Please specify a valid positive amount.');
      return;
    }

    setError('');
    onSubmitTransactionRequest({
      type: selectedType,
      targetId: targetId.trim(),
      amount: numAmount,
      paymentMethod,
      reference: reference.trim(),
      notes: notes.trim(),
    });
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 bg-emerald-50/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'দ্রুত লেনদেন ও ভাউচার এন্ট্রি' : 'Quick Financial Transaction Entry'}
              </h3>
              <p className="text-xs text-emerald-900 font-bengali">
                {isBn ? 'প্রথমে এন্ট্রি → যাচাইকরণ → অনুমোদন → লেজার পোস্টিং' : 'Request Entry → Verification → Approval → Ledger Posting'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {submitted ? (
            <div className="py-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-lg font-bold text-slate-900 font-bengali">
                {isBn ? 'লেনদেন সফলভাবে অনুমোদন সারিতে জমা হয়েছে!' : 'Transaction Request Submitted for Approval!'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 font-bengali max-w-md mx-auto leading-relaxed">
                {isBn
                  ? 'আপনার নির্দেশনা অনুসারে কোনো শর্টকাট সরাসরি ব্যালেন্স পরিবর্তন করতে পারে না। সুপার এডমিন অনুমোদন প্রদান করলেই কেবল লেজার ও ক্যাশবুকে ডেবিট-ক্রেডিট পোস্ট হবে।'
                  : 'Per your accounting architecture, shortcut entries submit to the approval queue. Only once approved by the Super Admin will journal debits and credits post to verified ledger balances.'}
              </p>
              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs font-bengali transition-colors"
              >
                {isBn ? 'সম্পন্ন' : 'Done'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="p-3 rounded-xl bg-rose-50 text-rose-800 text-xs font-medium border border-rose-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span className="font-bengali">{error}</span>
                </div>
              )}

              {/* Action Type Grid */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider font-bengali">
                  {isBn ? 'লেনদেনের ধরন নির্বাচন করুন' : 'Select Transaction Type'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {actionTypes.map((item) => {
                    const Icon = item.icon;
                    const isSelected = selectedType === item.id;
                    return (
                      <button
                        type="button"
                        key={item.id}
                        onClick={() => setSelectedType(item.id)}
                        className={`p-2.5 text-left rounded-xl border text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="font-bengali truncate">{isBn ? item.labelBn : item.labelEn}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* ID & Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'সদস্য / পার্টনার / ভাউচার আইডি' : 'Member / Partner / Voucher ID'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={targetId}
                    onChange={(e) => setTargetId(e.target.value)}
                    placeholder={isBn ? 'উদা: BBL-001 বা BBL1001' : 'e.g. BBL-001 or BBL1001'}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'টাকার পরিমাণ (BDT)' : 'Amount (BDT)'} *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="৳ 0.00"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-mono font-bold"
                  />
                </div>
              </div>

              {/* Payment Method & Reference */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'পেমেন্ট মাধ্যম (Payment Method)' : 'Payment Method'}
                  </label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-bengali"
                  >
                    <option value="CASH">{isBn ? 'ক্যাশ ইন হ্যান্ড (Cash in Vault)' : 'Cash in Hand'}</option>
                    <option value="BANK">{isBn ? 'ব্যাংক একাউন্ট ট্রান্সফার' : 'Commercial Bank Transfer'}</option>
                    <option value="BKASH">bKash Merchant</option>
                    <option value="NAGAD">Nagad Islamic</option>
                    <option value="ROCKET">Rocket MFS</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                    {isBn ? 'ব্যাংক স্লিপ / ট্রানজেকশন রেফারেন্স নং' : 'Reference / TrxID'}
                  </label>
                  <input
                    type="text"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    placeholder={isBn ? 'উদা: স্লিপ নং বা TrxID' : 'e.g. Deposit Slip # or TrxID'}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-mono"
                  />
                </div>
              </div>

              {/* Description / Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'বিবরণ ও ভাউচার নোট' : 'Voucher Notes & Description'}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isBn ? 'লেনদেনের সংক্ষিপ্ত কারণ বা বিবরণ' : 'Brief purpose or audit note'}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-bengali"
                />
              </div>

              {/* Security info */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 font-bengali flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  {isBn
                    ? 'লেনদেনটি জমা দিলে সিস্টেম একটি অনন্য ট্র্যাকিং রেফারেন্স তৈরি করবে এবং তা সুপার এডমিনের অনুমোদন কেন্দ্রে স্থানান্তরিত হবে।'
                    : 'Submission assigns a sequential reference and routes the entry to the approval center.'}
                </span>
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition-colors font-bengali"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-md shadow-emerald-700/20 transition-all font-bengali cursor-pointer"
                >
                  {isBn ? 'অনুমোদনের জন্য পাঠান' : 'Submit for Approval'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
