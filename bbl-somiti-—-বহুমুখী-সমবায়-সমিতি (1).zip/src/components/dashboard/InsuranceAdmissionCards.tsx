import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  UserX,
  CreditCard,
  AlertCircle,
  Coins,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface InsuranceAdmissionCardsProps {
  state: FinancialState;
  lang: Language;
}

export const InsuranceAdmissionCards: React.FC<InsuranceAdmissionCardsProps> = ({ state, lang }) => {
  const isBn = lang === 'bn';

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'ইনস্যুরেন্স ও ভর্তি ফি ফান্ড (Insurance & Admission Management)' : 'Insurance & Admission Fee Portfolio'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? 'ডিফল্ট ভর্তি ফি ১০০ টাকা ও সংরক্ষিত ঝুঁকি ইনস্যুরেন্স ফান্ডের স্বচ্ছ হিসাব'
              : 'Default 100 BDT admission fee accounting alongside member life & credit safety reserve'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Total Insurance Collected */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১. মোট ইনস্যুরেন্স আদায়' : '1. Insurance Inflows'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.totalInsuranceCollected, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সংগৃহীত মোট প্রিমিয়াম' : 'Gross risk premium receipts'}
          </p>
        </div>

        {/* 2. Insurance Fund Balance */}
        <div className="rounded-2xl p-4 sm:p-5 bg-emerald-50/60 border border-emerald-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-900 uppercase tracking-wider font-bengali">
              {isBn ? '২. Insurance Fund ব্যালেন্স' : '2. Insurance Reserve'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-950 font-mono tabular-nums">
            {formatCurrency(state.insuranceFundBalance, lang)}
          </div>
          <p className="text-[11px] text-emerald-800 font-bengali">
            {isBn ? 'দাবিপূরণের জন্য সংরক্ষিত তহবিল' : 'Reserved for claims settlement'}
          </p>
        </div>

        {/* 3. Active Insurance Members */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৩. Active Insurance সদস্য' : '3. Covered Members'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatNumber(state.activeInsuranceMembersCount, lang)} {isBn ? 'জন' : 'Members'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'বর্তমানে সুরক্ষাপ্রাপ্ত সক্রিয় সদস্য' : 'Members under active safety policy'}
          </p>
        </div>

        {/* 4. Inactive/Expired Insurance */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৪. মেয়াদোত্তীর্ণ ইনস্যুরেন্স' : '4. Expired Policies'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center">
              <UserX className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-700 font-mono tabular-nums">
            {formatNumber(state.inactiveInsuranceMembersCount, lang)} {isBn ? 'জন' : 'Policies'}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'নবায়নযোগ্য বা তামাদি কভারেজ' : 'Lapsed or unrenewed policy holders'}
          </p>
        </div>

        {/* 5. Total Admission Fees Collected */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৫. মোট ভর্তি ফি আদায়' : '5. Admission Fees In'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatCurrency(state.totalAdmissionFeesCollected, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? '১০০ টাকা/সদস্য হিসাবে আদায়' : '100 BDT default fee collection'}
          </p>
        </div>

        {/* 6. Admission Fees Pending */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৬. ভর্তি ফি বকেয়া' : '6. Admission Arrears'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-900 font-mono tabular-nums">
            {formatCurrency(state.admissionFeesPending, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'নতুন আবেদনকারীদের বকেয়া ফি' : 'Pending fee on probationary files'}
          </p>
        </div>

        {/* 7. Other Member Fees */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5 sm:col-span-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৭. অন্যান্য সদস্য ফি ও আদায়' : '7. Auxiliary Member Fees'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.otherMemberFees, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'পাসবই ইস্যু, হিসাব বিবরণী ও ফরম ফিস' : 'Passbook, certificate & registration service fees'}
          </p>
        </div>
      </div>
    </div>
  );
};
