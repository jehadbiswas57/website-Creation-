import React, { useState } from 'react';
import {
  Calculator,
  Save,
  RotateCcw,
  Check,
  Coins,
  HandCoins,
  ArrowUpRight,
  PiggyBank,
  ArrowDownLeft,
  ShieldAlert,
  CreditCard,
  Receipt,
  Landmark,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency } from '../../utils/formatters';

interface FormulaCalculatorPanelProps {
  financialState: FinancialState;
  onUpdateFinancialState: (updated: FinancialState) => void;
  lang: Language;
}

export const FormulaCalculatorPanel: React.FC<FormulaCalculatorPanelProps> = ({
  financialState,
  onUpdateFinancialState,
  lang,
}) => {
  const isBn = lang === 'bn';

  // Local draft inputs for live typing
  const [inputs, setInputs] = useState({
    investmentCapital: financialState.totalInvestmentCapital,
    loanDisbursed: financialState.totalLoanDisbursed,
    loanRecovered: financialState.totalLoanPrincipalRecovered + financialState.totalLoanProfitRecovered,
    savingsIn: financialState.totalSavingsDeposits,
    savingsOut: financialState.totalSavingsWithdrawals,
    insuranceIn: financialState.totalInsuranceCollected,
    admissionIn: financialState.totalAdmissionFeesCollected,
    expenses: financialState.totalApprovedExpenses,
    bankBalance: financialState.bankBalance,
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Exact User Formula A:
  // বর্তমান ক্যাশ = মোট বিনিয়োগ মূলধন − মোট ঋণ বিতরণ + মোট ঋণ আদায় + মোট সঞ্চয় আদায় − মোট সঞ্চয় উত্তোলন + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায়
  const currentCash =
    Number(inputs.investmentCapital || 0) -
    Number(inputs.loanDisbursed || 0) +
    Number(inputs.loanRecovered || 0) +
    Number(inputs.savingsIn || 0) -
    Number(inputs.savingsOut || 0) +
    Number(inputs.insuranceIn || 0) +
    Number(inputs.admissionIn || 0);

  // Exact User Formula B:
  // টোটাল ক্যাশ = মোট বিনিয়োগ মূলধন + মোট সঞ্চয় আদায় + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায় − মোট সঞ্চয় উত্তোলন − মোট খরচ
  const totalCash =
    Number(inputs.investmentCapital || 0) +
    Number(inputs.savingsIn || 0) +
    Number(inputs.insuranceIn || 0) +
    Number(inputs.admissionIn || 0) -
    Number(inputs.savingsOut || 0) -
    Number(inputs.expenses || 0);

  // Available Cash & Bank
  const availableCashAndBank = currentCash + Number(inputs.bankBalance || 0);

  const handleInputChange = (field: keyof typeof inputs, value: string) => {
    const num = value === '' ? 0 : parseFloat(value);
    setInputs((prev) => ({ ...prev, [field]: isNaN(num) ? 0 : num }));
  };

  const handleSaveCalculation = () => {
    const updatedState: FinancialState = {
      ...financialState,
      totalInvestmentCapital: Number(inputs.investmentCapital || 0),
      totalLoanDisbursed: Number(inputs.loanDisbursed || 0),
      totalLoanPrincipalRecovered: Number(inputs.loanRecovered || 0),
      totalSavingsDeposits: Number(inputs.savingsIn || 0),
      totalSavingsWithdrawals: Number(inputs.savingsOut || 0),
      totalInsuranceCollected: Number(inputs.insuranceIn || 0),
      totalAdmissionFeesCollected: Number(inputs.admissionIn || 0),
      totalApprovedExpenses: Number(inputs.expenses || 0),
      bankBalance: Number(inputs.bankBalance || 0),
      presentCash: currentCash,
      availableCashAndBank: availableCashAndBank,
      totalFund: totalCash,
      memberSavingsLiability: Math.max(0, Number(inputs.savingsIn || 0) - Number(inputs.savingsOut || 0)),
      totalOutstandingLoanPrincipal: Math.max(0, Number(inputs.loanDisbursed || 0) - Number(inputs.loanRecovered || 0)),
    };

    onUpdateFinancialState(updatedState);
    try {
      localStorage.setItem('bbl_user_financial_state', JSON.stringify(updatedState));
    } catch {}

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleResetToZero = () => {
    const zeroInputs = {
      investmentCapital: 0,
      loanDisbursed: 0,
      loanRecovered: 0,
      savingsIn: 0,
      savingsOut: 0,
      insuranceIn: 0,
      admissionIn: 0,
      expenses: 0,
      bankBalance: 0,
    };
    setInputs(zeroInputs);

    const zeroState: FinancialState = {
      ...financialState,
      totalInvestmentCapital: 0,
      totalLoanDisbursed: 0,
      totalLoanPrincipalRecovered: 0,
      totalLoanProfitRecovered: 0,
      totalSavingsDeposits: 0,
      totalSavingsWithdrawals: 0,
      totalInsuranceCollected: 0,
      totalAdmissionFeesCollected: 0,
      totalApprovedExpenses: 0,
      bankBalance: 0,
      presentCash: 0,
      availableCashAndBank: 0,
      totalFund: 0,
      memberSavingsLiability: 0,
      totalOutstandingLoanPrincipal: 0,
    };

    onUpdateFinancialState(zeroState);
    try {
      localStorage.setItem('bbl_user_financial_state', JSON.stringify(zeroState));
    } catch {}
  };

  return (
    <div className="space-y-6">
      {/* 1. TOP RESULT CARDS — EXACT 2 FORMULAS (FORMULA A & FORMULA B) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {/* Card 1: Formula A - Present Cash */}
        <div className="rounded-2xl p-5 sm:p-6 bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900 text-white shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-200 font-bengali">
              {isBn ? 'সূত্র ১: বর্তমান ক্যাশ' : 'Formula 1: Present Cash'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-mono tracking-tight tabular-nums">
            {formatCurrency(currentCash, lang)}
          </div>
          <p className="text-[11px] sm:text-xs text-blue-200/90 font-bengali leading-relaxed pt-1.5 border-t border-white/10">
            {isBn
              ? 'বিনিয়োগ মূলধন − ঋণ বিতরণ + ঋণ আদায় + সঞ্চয় জমা − সঞ্চয় উত্তোলন + বীমা জমা + ভর্তি ফি'
              : 'Capital − Disbursed + Recovered + Savings In − Savings Out + Insurance + Admission'}
          </p>
        </div>

        {/* Card 2: Formula B - Total Cash */}
        <div className="rounded-2xl p-5 sm:p-6 bg-gradient-to-br from-emerald-700 via-teal-800 to-emerald-900 text-white shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-200 font-bengali">
              {isBn ? 'সূত্র ২: মোট ক্যাশ' : 'Formula 2: Total Cash'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-mono tracking-tight tabular-nums">
            {formatCurrency(totalCash, lang)}
          </div>
          <p className="text-[11px] sm:text-xs text-emerald-200/90 font-bengali leading-relaxed pt-1.5 border-t border-white/10">
            {isBn
              ? 'বিনিয়োগ মূলধন + সঞ্চয় জমা + বীমা জমা + ভর্তি ফি − সঞ্চয় উত্তোলন − মোট খরচ'
              : 'Capital + Savings In + Insurance + Admission − Savings Out − Total Expenses'}
          </p>
        </div>
      </div>

      {/* 2. LIVE CALCULATION & DATA INPUT PANEL */}
      <div className="rounded-3xl bg-white border border-slate-200 shadow-sm p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 font-display">
                {isBn ? 'দৈনিক ক্যাশ হিসাব' : 'Daily Cash Calculation'}
              </h3>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn
                  ? 'আপনার সমিতির বিভিন্ন খাতের মোট টাকার পরিমাণ এখানে লিখুন। ফলাফল সাথে সাথে গণনা হবে।'
                  : 'Enter the amounts for each fund below. The formula figures will calculate immediately.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSaveCalculation}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm transition-all cursor-pointer font-bengali"
            >
              {savedSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{savedSuccess ? (isBn ? 'সংরক্ষিত হয়েছে' : 'Saved!') : (isBn ? 'হিসাব সংরক্ষণ করুন' : 'Save Calculation')}</span>
            </button>

            <button
              type="button"
              onClick={handleResetToZero}
              className="inline-flex items-center gap-1 px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors cursor-pointer font-bengali"
              title="সব হিসাব ০ করুন"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isBn ? 'সব ০ করুন' : 'Reset 0'}</span>
            </button>
          </div>
        </div>

        {/* 9 INPUT FIELDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-bengali">
          {/* 1. মোট বিনিয়োগ মূলধন */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '১. মোট বিনিয়োগ মূলধন' : '1. Total Investment Capital'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.investmentCapital || ''}
              onChange={(e) => handleInputChange('investmentCapital', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'উদ্যোক্তা ও পার্টনারদের মূলধন' : 'Equity capital'}</span>
          </div>

          {/* 2. মোট ঋণ বিতরণ */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '২. মোট ঋণ বিতরণ' : '2. Total Loan Disbursed'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.loanDisbursed || ''}
              onChange={(e) => handleInputChange('loanDisbursed', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'সদস্যদের মাঝে বিতরণকৃত ঋণ' : 'Disbursed to members'}</span>
          </div>

          {/* 3. মোট ঋণ আদায় */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৩. মোট ঋণ আদায়' : '3. Total Loan Recovered'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.loanRecovered || ''}
              onChange={(e) => handleInputChange('loanRecovered', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'সদস্যদের থেকে ফেরত পাওয়া আসল ও লাভ' : 'Principal + profit received'}</span>
          </div>

          {/* 4. মোট সঞ্চয় জমা */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৪. মোট সঞ্চয় জমা' : '4. Total Savings Collected'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.savingsIn || ''}
              onChange={(e) => handleInputChange('savingsIn', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'সদস্যদের জমাকৃত মোট সঞ্চয়' : 'Member savings inflows'}</span>
          </div>

          {/* 5. মোট সঞ্চয় উত্তোলন */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৫. মোট সঞ্চয় উত্তোলন' : '5. Total Savings Withdrawn'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.savingsOut || ''}
              onChange={(e) => handleInputChange('savingsOut', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'সদস্যদের ফেরত দেওয়া মোট সঞ্চয়' : 'Savings paid out'}</span>
          </div>

          {/* 6. মোট বীমা / ইনস্যুরেন্স জমা */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৬. মোট বীমা / ইনস্যুরেন্স জমা' : '6. Total Insurance Collected'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.insuranceIn || ''}
              onChange={(e) => handleInputChange('insuranceIn', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'ঝুঁকি ও কল্যাণ তহবিল বাবদ আদায়' : 'Safety premium reserve'}</span>
          </div>

          {/* 7. মোট ভর্তি ফি */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৭. মোট ভর্তি ফি' : '7. Admission Fees Collected'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.admissionIn || ''}
              onChange={(e) => handleInputChange('admissionIn', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'নতুন সদস্যদের ভর্তি ফি বাবদ আদায়' : 'Registration onboarding fees'}</span>
          </div>

          {/* 8. মোট খরচ */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৮. মোট খরচ' : '8. Total Expenses'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.expenses || ''}
              onChange={(e) => handleInputChange('expenses', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'অনুমোদিত অফিস ও পরিচালন ব্যয়' : 'Operating costs'}</span>
          </div>

          {/* 9. বর্তমান ব্যাংক ব্যালেন্স */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <label className="block font-bold text-slate-800">
              {isBn ? '৯. বর্তমান ব্যাংক ব্যালেন্স' : '9. Bank Balance'} (৳)
            </label>
            <input
              type="number"
              min="0"
              step="any"
              value={inputs.bankBalance || ''}
              onChange={(e) => handleInputChange('bankBalance', e.target.value)}
              placeholder="0"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono font-bold text-sm text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
            />
            <span className="text-[10px] text-slate-500 block">{isBn ? 'ব্যাংক হিসাবে রক্ষিত মোট টাকা' : 'Bank account deposits'}</span>
          </div>
        </div>
      </div>

      {/* 3. 9 CORE FORMULA CARDS DISPLAY */}
      <div>
        <div className="pb-3 border-b border-slate-200 mb-4">
          <h4 className="text-sm font-bold text-slate-900 font-display">
            {isBn ? 'হিসাবের সারসংক্ষেপ (৯টি মূল খাত)' : 'Summary of Accounts (9 Core Funds)'}
          </h4>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn ? 'আপনার প্রদত্ত ইনপুট অনুযায়ী প্রতিটি খাতের বর্তমান হিসাব' : 'Current ledger amounts based on your input'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Item 1 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '১. মোট বিনিয়োগ মূলধন' : '1. Investment Capital'}</span>
              <Coins className="w-4 h-4 text-purple-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.investmentCapital || 0), lang)}
            </div>
          </div>

          {/* Item 2 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '২. মোট ঋণ বিতরণ' : '2. Loan Disbursed'}</span>
              <HandCoins className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.loanDisbursed || 0), lang)}
            </div>
          </div>

          {/* Item 3 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৩. মোট ঋণ আদায়' : '3. Loan Recovered'}</span>
              <ArrowUpRight className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.loanRecovered || 0), lang)}
            </div>
          </div>

          {/* Item 4 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৪. মোট সঞ্চয় জমা' : '4. Savings In'}</span>
              <PiggyBank className="w-4 h-4 text-sky-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.savingsIn || 0), lang)}
            </div>
          </div>

          {/* Item 5 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৫. মোট সঞ্চয় উত্তোলন' : '5. Savings Out'}</span>
              <ArrowDownLeft className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.savingsOut || 0), lang)}
            </div>
          </div>

          {/* Item 6 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৬. মোট বীমা জমা' : '6. Insurance In'}</span>
              <ShieldAlert className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.insuranceIn || 0), lang)}
            </div>
          </div>

          {/* Item 7 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৭. মোট ভর্তি ফি' : '7. Admission Fees'}</span>
              <CreditCard className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.admissionIn || 0), lang)}
            </div>
          </div>

          {/* Item 8 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৮. মোট খরচ' : '8. Total Expenses'}</span>
              <Receipt className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.expenses || 0), lang)}
            </div>
          </div>

          {/* Item 9 */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span className="font-bold font-bengali">{isBn ? '৯. বর্তমান ব্যাংক ব্যালেন্স' : '9. Bank Balance'}</span>
              <Landmark className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl font-extrabold text-slate-900 font-mono">
              {formatCurrency(Number(inputs.bankBalance || 0), lang)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
