import React from 'react';
import {
  PiggyBank,
  ArrowDownLeft,
  Scale,
  CircleDollarSign,
  TrendingDown,
  Clock,
  Calendar,
  FileSpreadsheet,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface SavingsDpsCardsProps {
  state: FinancialState;
  lang: Language;
}

export const SavingsDpsCards: React.FC<SavingsDpsCardsProps> = ({ state, lang }) => {
  const isBn = lang === 'bn';

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'সদস্যদের সঞ্চয় ও DPS দায় (Savings & DPS Liabilities)' : 'Member Savings & DPS Portfolio'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? 'সঞ্চয় আমানত সমিতির নিজস্ব আয় নয় — সদস্যদের আমানত ও উত্তোলন লেজার অনুযায়ী সমিতির দায় হিসেবে সংরক্ষিত'
              : 'Deposits are strictly recorded as balance sheet liabilities; never recognized as operating income'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {/* 1. Total Savings Deposits */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১. মোট সঞ্চয় জমা' : '1. Savings Inflow'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <PiggyBank className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.totalSavingsDeposits, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সদস্যদের সাধারণ সঞ্চয় জমা' : 'Member general savings inflows'}
          </p>
        </div>

        {/* 2. Total Savings Withdrawals */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '২. মোট সঞ্চয় উত্তোলন' : '2. Savings Withdrawals'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-rose-800 font-mono tabular-nums">
            {formatCurrency(state.totalSavingsWithdrawals, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'অনুমোদিত সদস্য সঞ্চয় উত্তোলন' : 'Approved member payouts'}
          </p>
        </div>

        {/* 3. Member Savings Liability */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-blue-50 to-indigo-50/50 border border-blue-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-blue-900 uppercase tracking-wider font-bengali">
              {isBn ? '৩. সঞ্চয় বর্তমান দায়' : '3. Savings Liability'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-blue-950 font-mono tabular-nums">
            {formatCurrency(state.memberSavingsLiability, lang)}
          </div>
          <p className="text-[11px] text-blue-800/80 font-bengali">
            {isBn ? 'জমা − উত্তোলন = প্রকৃত দায়' : 'Deposits − Withdrawals = Net'}
          </p>
        </div>

        {/* 4. Total DPS Deposits */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৪. মোট DPS জমা' : '4. Total DPS Inflow'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
              <CircleDollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatCurrency(state.totalDpsDeposits, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'মাসিক মেয়াদী স্কিমে জমাকৃত কিস্তি' : 'Term scheme installment balance'}
          </p>
        </div>

        {/* 5. DPS Withdrawals */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৫. DPS উত্তোলন ও মেয়াদপূর্তি' : '5. DPS Maturity Payout'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-900 font-mono tabular-nums">
            {formatCurrency(state.totalDpsWithdrawals, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'মেয়াদপূর্তি বা ক্লোজিং পরিশোধ' : 'Matured/closed scheme payouts'}
          </p>
        </div>

        {/* 6. DPS Liability */}
        <div className="rounded-2xl p-4 sm:p-5 bg-purple-50/60 border border-purple-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-purple-900 uppercase tracking-wider font-bengali">
              {isBn ? '৬. DPS-এর বর্তমান দায়' : '6. DPS Net Liability'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-700 text-white flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-purple-950 font-mono tabular-nums">
            {formatCurrency(state.dpsLiability, lang)}
          </div>
          <p className="text-[11px] text-purple-800 font-bengali">
            {isBn ? 'চলমান ডিপিএস মেয়াদী দায়' : 'Active term scheme balance'}
          </p>
        </div>

        {/* 7. Today Savings Collection */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৭. আজকের সঞ্চয় আদায়' : '7. Today Savings In'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatCurrency(state.todaySavingsCollection, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'আজ সংগৃহীত সঞ্চয় আমানত' : 'Savings received today'}
          </p>
        </div>

        {/* 8. This Month Savings Collection */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৮. এই মাসের সঞ্চয় আদায়' : '8. Month Savings In'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatCurrency(state.thisMonthSavingsCollection, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'চলতি মাসের মোট সঞ্চয় সংগ্রহ' : 'Current month savings pool'}
          </p>
        </div>

        {/* 9. Pending Savings Withdrawals */}
        <div className="rounded-2xl p-4 sm:p-5 bg-amber-50/60 border border-amber-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider font-bengali">
              {isBn ? '৯. সঞ্চয় উত্তোলন Pending' : '9. Pending Withdrawals'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-950 font-mono tabular-nums">
            {formatNumber(state.pendingSavingsWithdrawalsCount, lang)} {isBn ? 'টি আবেদন' : 'Requests'}
          </div>
          <p className="text-[11px] text-amber-800 font-bengali">
            {isBn ? 'সুপার এডমিনের অনুমোদন অপেক্ষমাণ' : 'Awaiting admin review & token'}
          </p>
        </div>

        {/* 10. Savings & DPS Statements */}
        <div className="rounded-2xl p-4 sm:p-5 bg-slate-900 text-white shadow-2xs space-y-1.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-emerald-400 font-bold uppercase tracking-wider font-bengali">
                {isBn ? '১০. সঞ্চয় ও ডিপিএস লেজার' : '10. Ledger Statement'}
              </span>
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-xs text-slate-300 font-bengali mt-2">
              {isBn
                ? 'সদস্যভিত্তিক সঞ্চয় ও ডিপিএস খতিয়ান রেজিস্টার প্রস্তুত'
                : 'Individual member passbooks & ledger verified'}
            </p>
          </div>
          <div className="text-[11px] text-emerald-300 font-semibold flex items-center gap-1 font-bengali">
            <span>{isBn ? 'লেজার হিসাব সক্রিয়' : 'Ledger Active'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
