import React, { useState } from 'react';
import {
  FinancialState,
  Language,
  DateRange,
  DataMode,
  TransactionRecord,
  ApprovalRequest,
} from '../../types/dashboard';
import { FormulaCalculatorPanel } from './FormulaCalculatorPanel';
import { ChevronDown, ChevronUp, Layers, PlusCircle, Inbox } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface DashboardMainViewProps {
  financialState: FinancialState;
  onUpdateFinancialState: (updated: FinancialState) => void;
  transactions: TransactionRecord[];
  approvals: ApprovalRequest[];
  lang: Language;
  dateRange: DateRange;
  dataMode: DataMode;
  onOpenQuickActions: () => void;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  onRevisionRequest: (id: string) => void;
}

export const DashboardMainView: React.FC<DashboardMainViewProps> = ({
  financialState,
  onUpdateFinancialState,
  transactions,
  approvals,
  lang,
  onOpenQuickActions,
  onApproveRequest,
  onRejectRequest,
  onRevisionRequest,
}) => {
  const isBn = lang === 'bn';
  const [showExtendedDetails, setShowExtendedDetails] = useState(false);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. MAIN FORMULA SYSTEM & LIVE CALCULATOR (EXACTLY MATCHING USER FRONT) */}
      <FormulaCalculatorPanel
        financialState={financialState}
        onUpdateFinancialState={onUpdateFinancialState}
        lang={lang}
      />

      {/* 2. TRANSACTION AND APPROVAL LOG (CLEAN EMPTY STATE — ZERO FAKE DATA) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h4 className="text-sm font-bold text-slate-900 font-display">
                {isBn ? 'সর্বশেষ লেনদেন বিবরণী' : 'Recent Transactions'}
              </h4>
              <p className="text-[11px] text-slate-500 font-bengali">
                {isBn ? 'দৈনিক জমা ও উত্তোলনের তালিকা' : 'Real transaction records'}
              </p>
            </div>
            <button
              onClick={onOpenQuickActions}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs font-bengali cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{isBn ? 'নতুন এন্ট্রি' : 'New Entry'}</span>
            </button>
          </div>

          {transactions.length === 0 ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                <Inbox className="w-5 h-5" />
              </div>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn ? 'বর্তমানে কোনো লেনদেন নেই। নতুন হিসাব যোগ করতে "নতুন এন্ট্রি" চাপুন।' : 'No transactions recorded yet.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 text-xs font-bengali">
              {transactions.map((trx) => (
                <div key={trx.id} className="py-2.5 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-slate-900 block">{trx.transactionType}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{trx.id} · {trx.date}</span>
                  </div>
                  <span className="font-mono font-bold text-slate-900">
                    {formatCurrency(trx.amount, lang)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Approvals Queue */}
        <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h4 className="text-sm font-bold text-slate-900 font-display">
                {isBn ? 'অনুমোদনের তালিকা' : 'Pending Approvals'}
              </h4>
              <p className="text-[11px] text-slate-500 font-bengali">
                {isBn ? 'অনুমোদনের অপেক্ষায় থাকা আবেদনসমূহ' : 'Pending administrative requests'}
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold font-mono">
              {approvals.filter((a) => a.status === 'PENDING').length}
            </span>
          </div>

          {approvals.filter((a) => a.status === 'PENDING').length === 0 ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-10 h-10 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                <Inbox className="w-5 h-5" />
              </div>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn ? 'বর্তমানে কোনো আবেদন অপেক্ষমাণ নেই।' : 'No pending approval tickets.'}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 text-xs font-bengali">
              {approvals
                .filter((a) => a.status === 'PENDING')
                .map((req) => (
                  <div key={req.id} className="py-2.5 flex justify-between items-center gap-2">
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate">{req.applicantName}</span>
                      <span className="text-[10px] text-slate-500">{req.details}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {req.amount && (
                        <span className="font-mono font-bold text-slate-900">
                          {formatCurrency(req.amount, lang)}
                        </span>
                      )}
                      <button
                        onClick={() => onApproveRequest(req.id)}
                        className="px-2 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold cursor-pointer"
                      >
                        {isBn ? 'অনুমোদন' : 'Approve'}
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
