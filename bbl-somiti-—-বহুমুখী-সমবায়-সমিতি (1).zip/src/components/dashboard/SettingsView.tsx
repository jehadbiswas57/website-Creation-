import React, { useState } from 'react';
import {
  Settings,
  Upload,
  RotateCcw,
  Check,
  Palette,
  Calculator,
  Percent,
  Hash,
  Shield,
  Save,
  Building,
  Phone,
  Mail,
  MapPin,
  Image as ImageIcon,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { BrandingSettings, FinancialFormulaConfig, Language } from '../../types/dashboard';

interface SettingsViewProps {
  branding: BrandingSettings;
  formulaConfig: FinancialFormulaConfig;
  onSaveBranding: (updated: BrandingSettings) => void;
  onSaveFormulaConfig: (updated: FinancialFormulaConfig) => void;
  lang: Language;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  branding,
  formulaConfig,
  onSaveBranding,
  onSaveFormulaConfig,
  lang,
}) => {
  const isBn = lang === 'bn';

  const [activeTab, setActiveTab] = useState<'branding' | 'rates' | 'formulas' | 'ids' | 'security'>('branding');
  const [formData, setFormData] = useState<BrandingSettings>({ ...branding });
  const [formConfig, setFormConfig] = useState<FinancialFormulaConfig>({ ...formulaConfig });
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Security Credentials State
  const [adminUserId, setAdminUserId] = useState<string>(() => {
    try {
      return localStorage.getItem('bbl_admin_userid') || 'admin';
    } catch {
      return 'admin';
    }
  });
  const [adminPassword, setAdminPassword] = useState<string>(() => {
    try {
      return localStorage.getItem('bbl_admin_password') || 'admin123';
    } catch {
      return 'admin123';
    }
  });
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [passwordFeedback, setPasswordFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormData((prev) => ({ ...prev, logoUrl: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setFormData((prev) => ({ ...prev, bannerUrl: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveBranding(formData);
    onSaveFormulaConfig(formConfig);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'সুপার এডমিন কনফিগারেশন সেটিংস (System Settings)' : 'Super Admin System Configuration'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? 'কোড পরিবর্তন ছাড়াই ব্র্যান্ডিং, লোগো, রং, সুদের হার ও আর্থিক সূত্র কনফিগার করার সম্পূর্ণ নিয়ন্ত্রণ'
              : 'Zero-code runtime management of branding, logos, colors, fees, interest rates, and financial formulas'}
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md shadow-emerald-700/20 transition-all cursor-pointer font-bengali self-start sm:self-auto"
        >
          {saveSuccess ? (
            <>
              <Check className="w-4 h-4 text-emerald-300" />
              <span>{isBn ? 'সংরক্ষিত হয়েছে!' : 'Saved Successfully!'}</span>
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>{isBn ? 'সমস্ত পরিবর্তন সংরক্ষণ করুন' : 'Save All Changes'}</span>
            </>
          )}
        </button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-3 text-xs font-semibold font-bengali">
        <button
          onClick={() => setActiveTab('branding')}
          className={`px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'branding'
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>{isBn ? 'ব্র্যান্ডিং ও পরিচিতি' : 'Branding & Identity'}</span>
        </button>

        <button
          onClick={() => setActiveTab('rates')}
          className={`px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'rates'
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>{isBn ? 'ফি ও মুনাফার হার' : 'Fees & Rates'}</span>
        </button>

        <button
          onClick={() => setActiveTab('formulas')}
          className={`px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'formulas'
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>{isBn ? 'ক্যাশ ফর্মুলা পলিসি' : 'Cash Formula Policy'}</span>
        </button>

        <button
          onClick={() => setActiveTab('ids')}
          className={`px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'ids'
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Hash className="w-4 h-4" />
          <span>{isBn ? 'আইডি প্রিফিক্স ও সিকোয়েন্স' : 'ID Prefixes'}</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-4 py-2 rounded-xl border transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'security'
              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>{isBn ? 'নিরাপত্তা ও পাসওয়ার্ড' : 'Security & Password'}</span>
        </button>
      </div>

      {/* Tab 1: Branding & Identity */}
      {activeTab === 'branding' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Logo & Banner Section */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-5">
            <h3 className="text-sm font-bold text-slate-900 font-bengali flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-emerald-700" />
              <span>{isBn ? 'সমিতির লোগো ও ব্যানার ইমেজ' : 'Society Logo & Banner Assets'}</span>
            </h3>

            {/* Logo Upload Card */}
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="w-20 h-20 rounded-2xl bg-white p-1 border border-slate-300 shadow-sm flex items-center justify-center overflow-hidden shrink-0">
                {formData.logoUrl ? (
                  <img src={formData.logoUrl} alt="Logo" className="w-full h-full object-contain" />
                ) : (
                  <span className="text-xs font-bold text-emerald-800">Default Logo</span>
                )}
              </div>
              <div className="space-y-2 text-xs font-bengali flex-1">
                <span className="font-bold text-slate-900 block">
                  {isBn ? 'অফিসিয়াল লোগো পরিবর্তন' : 'Official Logo Upload'}
                </span>
                <div className="flex flex-wrap gap-2">
                  <label className="cursor-pointer py-1.5 px-3 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isBn ? 'লোগো ফাইল আপলোড' : 'Upload File'}</span>
                    <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                  </label>
                  <button
                    type="button"
                    onClick={() => setFormData((p) => ({ ...p, logoUrl: null }))}
                    className="py-1.5 px-3 rounded-lg border border-slate-300 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors"
                  >
                    {isBn ? 'রিসেট' : 'Reset'}
                  </button>
                </div>
              </div>
            </div>

            {/* Palette Colors */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-bengali flex items-center gap-2">
                <Palette className="w-4 h-4 text-blue-700" />
                <span>{isBn ? 'থিম কালার কনফিগারেশন' : 'Theme Color Codes'}</span>
              </h4>
              <div className="grid grid-cols-2 gap-3 text-xs font-bengali">
                <div>
                  <label className="block text-slate-600 mb-1">{isBn ? 'Primary Blue:' : 'Primary Blue:'}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formData.primaryBlue}
                      onChange={(e) => setFormData({ ...formData, primaryBlue: e.target.value })}
                      className="w-8 h-8 rounded border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.primaryBlue}
                      onChange={(e) => setFormData({ ...formData, primaryBlue: e.target.value })}
                      className="w-full px-2 py-1.5 rounded-lg border text-xs font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">{isBn ? 'Primary Green:' : 'Primary Green:'}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formData.primaryGreen}
                      onChange={(e) => setFormData({ ...formData, primaryGreen: e.target.value })}
                      className="w-8 h-8 rounded border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.primaryGreen}
                      onChange={(e) => setFormData({ ...formData, primaryGreen: e.target.value })}
                      className="w-full px-2 py-1.5 rounded-lg border text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Names & Contact Details */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 font-bengali">
              {isBn ? 'সমিতির নাম ও যোগাযোগের তথ্য' : 'Society Identity & Contact Info'}
            </h3>

            <div className="space-y-3 text-xs font-bengali">
              <div>
                <label className="block font-bold text-slate-700 mb-1">{isBn ? 'ইংরেজি নাম' : 'English Name'}</label>
                <input
                  type="text"
                  value={formData.englishName}
                  onChange={(e) => setFormData({ ...formData, englishName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{isBn ? 'বাংলা নাম' : 'Bangla Name'}</label>
                <input
                  type="text"
                  value={formData.banglaName}
                  onChange={(e) => setFormData({ ...formData, banglaName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{isBn ? 'স্লোগান / ট্যাগলাইন' : 'Tagline / Slogan'}</label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{isBn ? 'প্রতিষ্ঠা তারিখ' : 'Established Date'}</label>
                  <input
                    type="text"
                    value={formData.establishmentDate}
                    onChange={(e) => setFormData({ ...formData, establishmentDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">{isBn ? 'হটলাইন ফোন' : 'Contact Phone'}</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{isBn ? 'অফিসিয়াল ইমেইল' : 'Email Address'}</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">{isBn ? 'প্রধান কার্যালয়ের ঠিকানা' : 'Head Office Address'}</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Fees & Rates */}
      {activeTab === 'rates' && (
        <div className="max-w-2xl p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 font-bengali">
            {isBn ? 'সমবায় ফি, সঞ্চয় ও ঋণের সুদের হার' : 'Cooperative Fees, Savings & Loan Rates'}
          </h3>

          <div className="space-y-4 text-xs font-bengali">
            {/* Admission Fee */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-900">
                {isBn ? 'সদস্য ভর্তি ফি (Default Admission Fee)' : 'Member Admission Fee (Default 100 BDT)'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={formData.admissionFeeDefault}
                  onChange={(e) => setFormData({ ...formData, admissionFeeDefault: Number(e.target.value) })}
                  className="w-48 px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
                <span className="font-bold text-slate-700">BDT / টাকা</span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn
                  ? 'নতুন সদস্যের প্রাথমিক নিবন্ধন ফি। ডিফল্ট মান ১০০ টাকা।'
                  : 'Default onboarding fee assessed for each new applicant.'}
              </p>
            </div>

            {/* Insurance Rate */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-900">
                {isBn ? 'ঋণ ইনস্যুরেন্স প্রিমিয়াম হার (Insurance Rate %)' : 'Loan Insurance Rate (%)'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="0"
                  max="10"
                  step="0.1"
                  value={formData.insuranceRatePercent}
                  onChange={(e) => setFormData({ ...formData, insuranceRatePercent: Number(e.target.value) })}
                  className="w-48 px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
                <span className="font-bold text-slate-700">%</span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isBn
                  ? 'ঋণ বিতরণের সময় ইনস্যুরেন্স ফান্ডে কর্তনযোগ্য শতাংশ।'
                  : 'Percentage retained from loan sanction towards member risk safety fund.'}
              </p>
            </div>

            {/* Initial Savings Rate */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-900">
                {isBn ? 'প্রাথমিক বাধ্যতামূলক সঞ্চয় হার (Initial Savings Rate %)' : 'Mandatory Initial Savings (%)'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="0"
                  max="25"
                  step="0.5"
                  value={formData.initialSavingsRatePercent}
                  onChange={(e) => setFormData({ ...formData, initialSavingsRatePercent: Number(e.target.value) })}
                  className="w-48 px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
                <span className="font-bold text-slate-700">%</span>
              </div>
            </div>

              {/* Loan Profit Rate */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-900">
                {isBn ? 'ঋণের বার্ষিক সার্ভিস চার্জ / মুনাফার হার (Loan Rate %)' : 'Annual Loan Profit / Service Charge (%)'}
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="30"
                  step="0.5"
                  value={formData.loanProfitRatePercent}
                  onChange={(e) => setFormData({ ...formData, loanProfitRatePercent: Number(e.target.value) })}
                  className="w-48 px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
                <span className="font-bold text-slate-700">% বার্ষিক / p.a.</span>
              </div>
            </div>

            {/* Allowed Loan Installment Options */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <label className="block font-bold text-slate-900">
                {isBn ? 'অনুমোদিত ঋণের কিস্তির সংখ্যা বিকল্পসমূহ (Allowed Installment Options)' : 'Allowed Loan Installment Options'}
              </label>
              <p className="text-[11px] text-slate-500">
                {isBn
                  ? 'লোন ক্যালকুলেটরে ড্রপডাউন ও বাটনে প্রদর্শিত কিস্তির সংখ্যা (কমা দিয়ে পৃথককৃত সংখ্যা, যেমন ১১, ১১.৫, ১২, ১২.৫, ১৩, ১৫, ১৮, ২৪)'
                  : 'Comma-separated list of allowed installment counts (e.g. 11, 11.5, 12, 12.5, 13, 15, 18, 24).'}
              </p>
              <input
                type="text"
                value={(formData.allowedLoanInstallments || [11, 11.5, 12, 12.5, 13, 15, 18, 24]).join(', ')}
                onChange={(e) => {
                  const raw = e.target.value;
                  const parsed = raw
                    .split(',')
                    .map((s) => parseFloat(s.trim()))
                    .filter((n) => !isNaN(n) && n > 0);
                  setFormData({ ...formData, allowedLoanInstallments: parsed });
                }}
                placeholder="11, 11.5, 12, 12.5, 13, 15, 18, 24"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-blue-900 bg-white"
              />
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(formData.allowedLoanInstallments || [11, 11.5, 12, 12.5, 13, 15, 18, 24]).map((inst) => (
                  <span
                    key={inst}
                    className="px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-700 shadow-2xs"
                  >
                    {inst} কিস্তি
                  </span>
                ))}
              </div>
            </div>

            {/* Default Calculation Method */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
              <label className="block font-bold text-slate-900">
                {isBn ? 'মুনাফা গণনার প্রাথমিক পদ্ধতি (Default Calculation Method)' : 'Default Profit Calculation Method'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className={`flex items-center gap-2 p-3 rounded-xl border cursor-pointer ${
                  (formData.defaultLoanCalculationMethod || 'FLAT') === 'FLAT'
                    ? 'border-blue-600 bg-blue-50 text-blue-950 font-bold'
                    : 'border-slate-200 bg-white text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="calcMethod"
                    value="FLAT"
                    checked={(formData.defaultLoanCalculationMethod || 'FLAT') === 'FLAT'}
                    onChange={() => setFormData({ ...formData, defaultLoanCalculationMethod: 'FLAT' })}
                    className="accent-blue-600"
                  />
                  <span>{isBn ? 'সরল মুনাফা পদ্ধতি (Flat Method)' : 'Flat Rate Method'}</span>
                </label>

                <label className={`flex items-center gap-2 p-3 rounded-xl border cursor-pointer ${
                  formData.defaultLoanCalculationMethod === 'REDUCING'
                    ? 'border-blue-600 bg-blue-50 text-blue-950 font-bold'
                    : 'border-slate-200 bg-white text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="calcMethod"
                    value="REDUCING"
                    checked={formData.defaultLoanCalculationMethod === 'REDUCING'}
                    onChange={() => setFormData({ ...formData, defaultLoanCalculationMethod: 'REDUCING' })}
                    className="accent-blue-600"
                  />
                  <span>{isBn ? 'হ্রাসমান ব্যালেন্স (Reducing Balance EMI)' : 'Reducing Balance EMI'}</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Financial Formulas */}
      {activeTab === 'formulas' && (
        <div className="max-w-3xl p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-5">
          <div className="flex items-center gap-3">
            <Calculator className="w-5 h-5 text-blue-700" />
            <h3 className="text-sm font-bold text-slate-900 font-bengali">
              {isBn ? 'ব্যবহারকারী-সংজ্ঞায়িত ক্যাশ ফর্মুলা কনফিগারেশন' : 'User-Defined Cash Formula Governance'}
            </h3>
          </div>

          <div className="space-y-4 text-xs font-bengali">
            {/* Formula A */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-950 text-sm">{isBn ? 'User Formula A (বর্তমান ক্যাশ)' : 'User Formula A (Present Cash)'}</span>
                <span className="px-2 py-0.5 rounded bg-blue-200 text-blue-900 font-bold text-[10px]">অপরিবর্তনীয় সূত্র</span>
              </div>
              <p className="font-mono text-slate-800 text-[11px] bg-white p-2.5 rounded-xl border border-blue-200 leading-relaxed">
                বর্তমান ক্যাশ = মোট বিনিয়োগ মূলধন − মোট ঋণ বিতরণ + মোট ঋণ আদায় + মোট সঞ্চয় আদায় − মোট সঞ্চয় উত্তোলন + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায়
              </p>
            </div>

            {/* Formula B */}
            <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-950 text-sm">{isBn ? 'User Formula B (টোটাল ক্যাশ)' : 'User Formula B (Total Cash)'}</span>
                <span className="px-2 py-0.5 rounded bg-indigo-200 text-indigo-900 font-bold text-[10px]">অপরিবর্তনীয় সূত্র</span>
              </div>
              <p className="font-mono text-slate-800 text-[11px] bg-white p-2.5 rounded-xl border border-indigo-200 leading-relaxed">
                টোটাল ক্যাশ = মোট বিনিয়োগ মূলধন + মোট সঞ্চয় আদায় + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায় − মোট সঞ্চয় উত্তোলন − মোট খরচ
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-emerald-950">
                <Shield className="w-4 h-4 text-emerald-700" />
                <span>{isBn ? 'ডাবল এন্ট্রি সাধারণ লেজার এনফোর্সমেন্ট' : 'Double-Entry General Ledger Balance'}</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {isBn
                  ? 'আপনার দেওয়া ফর্মুলার পাশাপাশি সিস্টেম সবসময় অনুমোদিত ডেবিট ও ক্রেডিটের সমন্বয়ে প্রকৃত লেজার ক্যাশ ব্যালেন্স প্রদর্শন করবে এবং উভয়ের মধ্যে পার্থক্য থাকলে স্বয়ংক্রিয় রিকনসিলিয়েশন রিপোর্ট উপস্থাপন করবে।'
                  : 'Alongside your formulas, the system continuously tracks posted double-entry journal items and flags any variances in the reconciliation bridge.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: ID Prefixes */}
      {activeTab === 'ids' && (
        <div className="max-w-2xl p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900 font-bengali">
            {isBn ? 'আইডি প্রিফিক্স ও সিকোয়েন্স ফরম্যাট' : 'Sequential Identifier Prefix Rules'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-bengali">
            <div>
              <label className="block font-bold text-slate-700 mb-1">{isBn ? 'সদস্য আইডি প্রিফিক্স' : 'Member ID Prefix'}</label>
              <input
                type="text"
                value={formData.memberIdPrefix}
                onChange={(e) => setFormData({ ...formData, memberIdPrefix: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 font-mono mt-1 block">Example: {formData.memberIdPrefix}001</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">{isBn ? 'পার্টনার আইডি প্রিফিক্স' : 'Partner ID Prefix'}</label>
              <input
                type="text"
                value={formData.partnerIdPrefix}
                onChange={(e) => setFormData({ ...formData, partnerIdPrefix: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 font-mono mt-1 block">Example: {formData.partnerIdPrefix}1</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">{isBn ? 'ঋণ আইডি প্রিফিক্স' : 'Loan ID Prefix'}</label>
              <input
                type="text"
                value={formData.loanIdPrefix}
                onChange={(e) => setFormData({ ...formData, loanIdPrefix: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 font-mono mt-1 block">Example: {formData.loanIdPrefix}000001</span>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">{isBn ? 'লেনদেন আইডি প্রিফিক্স' : 'Transaction Prefix'}</label>
              <input
                type="text"
                value={formData.transactionIdPrefix}
                onChange={(e) => setFormData({ ...formData, transactionIdPrefix: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold"
              />
              <span className="text-[10px] text-slate-400 font-mono mt-1 block">Example: {formData.transactionIdPrefix}000001</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Security & Password */}
      {activeTab === 'security' && (
        <div className="max-w-2xl p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 font-display">
                {isBn ? 'সুপার এডমিন লগইন আইডি ও পাসওয়ার্ড সেট করুন' : 'Set Super Admin Login Credentials'}
              </h3>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn ? 'ড্যাশবোর্ড ও লগইন পেজে প্রবেশের মাস্টার পাসওয়ার্ড নিয়ন্ত্রণ' : 'Configure master authentication credentials for system access'}
              </p>
            </div>
          </div>

          {passwordFeedback && (
            <div
              className={`p-3 rounded-xl text-xs font-bengali flex items-center gap-2 ${
                passwordFeedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}
            >
              {passwordFeedback.type === 'success' ? (
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{passwordFeedback.msg}</span>
            </div>
          )}

          <div className="space-y-4 text-xs font-bengali">
            {/* Super Admin User ID */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {isBn ? 'সুপার এডমিন ইউজার আইডি / মোবাইল নম্বর' : 'Super Admin User ID / Mobile'} *
              </label>
              <input
                type="text"
                value={adminUserId}
                onChange={(e) => setAdminUserId(e.target.value)}
                placeholder="admin"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                {isBn ? 'ডিফল্ট আইডি: admin (অথবা আপনার ফোন নম্বর ব্যবহার করতে পারেন)' : 'Default ID: admin (or your mobile number)'}
              </span>
            </div>

            {/* Current Active Password display */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block text-[11px]">{isBn ? 'বর্তমানে সক্রিয় পাসওয়ার্ড:' : 'Current Active Password:'}</span>
                <span className="font-mono font-extrabold text-blue-900 text-sm">
                  {showPassword ? adminPassword : '• • • • • • • •'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="px-2.5 py-1 text-slate-600 hover:text-slate-900 text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showPassword ? (isBn ? 'লুকান' : 'Hide') : (isBn ? 'দেখুন' : 'Show')}</span>
              </button>
            </div>

            {/* New Password input */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {isBn ? 'নতুন পাসওয়ার্ড নির্ধারণ করুন' : 'Set New Password'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder={isBn ? 'নতুন পাসওয়ার্ড লিখুন (কমপক্ষে ৬ অক্ষর)' : 'Enter new password (min 6 chars)'}
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-300 font-mono text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                />
              </div>
            </div>

            {/* Confirm Password input */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={isBn ? 'পুনরায় নতুন পাসওয়ার্ড লিখুন' : 'Re-enter new password'}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
              />
            </div>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  if (!adminUserId.trim()) {
                    setPasswordFeedback({
                      type: 'error',
                      msg: isBn ? 'ইউজার আইডি খালি রাখা যাবে না।' : 'User ID cannot be empty.',
                    });
                    return;
                  }
                  if (newPassword) {
                    if (newPassword.length < 6) {
                      setPasswordFeedback({
                        type: 'error',
                        msg: isBn ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.',
                      });
                      return;
                    }
                    if (newPassword !== confirmPassword) {
                      setPasswordFeedback({
                        type: 'error',
                        msg: isBn ? 'উভয় পাসওয়ার্ড হুবহু মিলতে হবে।' : 'Passwords do not match.',
                      });
                      return;
                    }
                    try {
                      localStorage.setItem('bbl_admin_password', newPassword);
                      setAdminPassword(newPassword);
                    } catch {}
                  }

                  try {
                    localStorage.setItem('bbl_admin_userid', adminUserId.trim());
                  } catch {}

                  setNewPassword('');
                  setConfirmPassword('');
                  setPasswordFeedback({
                    type: 'success',
                    msg: isBn
                      ? 'সুপার এডমিন আইডি ও পাসওয়ার্ড সফলভাবে সংরক্ষিত হয়েছে!'
                      : 'Super Admin credentials saved successfully!',
                  });
                  setTimeout(() => setPasswordFeedback(null), 3000);
                }}
                className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-md shadow-blue-700/20 transition-all cursor-pointer font-bengali"
              >
                {isBn ? 'পাসওয়ার্ড ও আইডি সংরক্ষণ করুন' : 'Save ID & Password'}
              </button>

              <button
                type="button"
                onClick={() => {
                  try {
                    localStorage.setItem('bbl_admin_userid', 'admin');
                    localStorage.setItem('bbl_admin_password', 'admin123');
                    setAdminUserId('admin');
                    setAdminPassword('admin123');
                    setNewPassword('');
                    setConfirmPassword('');
                    setPasswordFeedback({
                      type: 'success',
                      msg: isBn ? 'ডিফল্ট ক্রিডেনশিয়ালে রিসেট হয়েছে (admin / admin123)।' : 'Reset to default (admin / admin123).',
                    });
                  } catch {}
                }}
                className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs transition-colors cursor-pointer font-bengali"
              >
                {isBn ? 'ডিফল্ট ক্রিডেনশিয়ালে রিসেট (admin / admin123)' : 'Reset to Default'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
