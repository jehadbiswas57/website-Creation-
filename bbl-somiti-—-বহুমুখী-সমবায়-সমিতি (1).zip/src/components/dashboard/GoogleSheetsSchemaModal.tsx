import React, { useState } from 'react';
import {
  Database,
  FileSpreadsheet,
  Table,
  CheckCircle2,
  Copy,
  Check,
  Code,
  ShieldCheck,
  ChevronRight,
  X,
} from 'lucide-react';
import { PROPOSED_SHEETS, WORKBOOK_NAME } from '../../data/sheetsSchema';
import { Language } from '../../types/dashboard';

interface GoogleSheetsSchemaModalProps {
  lang: Language;
  onClose: () => void;
}

export const GoogleSheetsSchemaModal: React.FC<GoogleSheetsSchemaModalProps> = ({
  lang,
  onClose,
}) => {
  const isBn = lang === 'bn';
  const [selectedSheetIndex, setSelectedSheetIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const currentSheet = PROPOSED_SHEETS[selectedSheetIndex] || PROPOSED_SHEETS[0];

  const appsScriptSnippet = `/**
 * Google Apps Script Web App Endpoint for BBL SOMITI
 * Handles Double-Entry Journaling & Sheet Append Operations
 */
function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000); // Prevent duplicate concurrency
  try {
    var payload = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(payload.sheetName);
    
    if (!sheet) {
      return ContentService.createTextOutput(JSON.stringify({
        success: false, 
        message: "Sheet table not found: " + payload.sheetName
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Append row with timestamp and unique sequential ID
    sheet.appendRow(payload.rowData);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true, 
      id: payload.generatedId,
      postedAt: new Date().toISOString()
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false, 
      error: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(appsScriptSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                  WORKBOOK: {WORKBOOK_NAME}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold font-display mt-0.5">
                {isBn ? 'Google Sheets ও সেন্ট্রাল ডাটাবেজ স্কিমা' : 'Google Sheets & Central DB Architecture'}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Top Info Banner */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs text-slate-700 font-bengali space-y-1">
            <div className="flex items-center gap-2 font-bold text-emerald-950">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>{isBn ? '২৬টি সেন্ট্রাল ডাটা টেবিল ও আইডি কনভেনশন স্ট্যান্ডার্ড' : '26 Proposed Tables & Strict ID Convention Standards'}</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {isBn
                ? 'আইডি কনভেনশন: Member (BBL-001), Partner (BBL1001), Loan (LN-000001), Savings (SAV-000001), Transaction (TRX-000001), Receipt (RCP-000001), Business (BUS-001)। কোনো আইডি কখনো পুনরায় ব্যবহৃত হবে না।'
                : 'ID Conventions: Member (BBL-001), Partner (BBL1001), Loan (LN-000001), Savings (SAV-000001), Transaction (TRX-000001), Receipt (RCP-000001), Business (BUS-001). IDs are strictly monotonic and never reused.'}
            </p>
          </div>

          {/* Table Selector Tabs */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 font-bengali">
              {isBn ? 'স্কিমা টেবিল নির্বাচন করুন:' : 'Select Sheet Table to Inspect:'}
            </span>
            <div className="flex flex-wrap gap-1.5 text-xs font-mono">
              {PROPOSED_SHEETS.map((sheet, idx) => (
                <button
                  key={sheet.tableName}
                  onClick={() => setSelectedSheetIndex(idx)}
                  className={`px-3 py-1.5 rounded-lg border font-bold transition-all cursor-pointer ${
                    selectedSheetIndex === idx
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {sheet.tableName}
                </button>
              ))}
            </div>
          </div>

          {/* Selected Table Detail */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div>
                <h4 className="text-base font-extrabold text-slate-900 font-mono">
                  Table: {currentSheet.tableName}
                </h4>
                <p className="text-xs text-slate-600 font-bengali mt-0.5">
                  {isBn ? currentSheet.descriptionBn : currentSheet.descriptionEn}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="px-2.5 py-1 rounded bg-slate-100 text-slate-700">
                  PK: {currentSheet.primaryKey}
                </span>
                <span className="px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                  Example: {currentSheet.idExample}
                </span>
              </div>
            </div>

            {/* Column Schema Grid */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold font-mono">
                    <th className="py-2.5 px-3">Column Name</th>
                    <th className="py-2.5 px-3">Data Type</th>
                    <th className="py-2.5 px-3">Required</th>
                    <th className="py-2.5 px-3">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {currentSheet.columns.map((col) => (
                    <tr key={col.name} className="hover:bg-slate-50/60">
                      <td className="py-2 px-3 font-bold text-slate-900">{col.name}</td>
                      <td className="py-2 px-3 text-blue-700 font-semibold">{col.type}</td>
                      <td className="py-2 px-3">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${col.required ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'}`}>
                          {col.required ? 'YES' : 'OPTIONAL'}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-slate-600 font-sans">{col.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Validation Rules */}
            <div className="pt-2">
              <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider font-bengali">
                {isBn ? 'ডাটা ভ্যালিডেশন নিয়মাবলী:' : 'Data Validation & Integrity Rules:'}
              </span>
              <ul className="mt-1 space-y-1 text-xs text-slate-600 font-bengali">
                {currentSheet.validationRules.map((rule, rIdx) => (
                  <li key={rIdx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{rule}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Google Apps Script Boilerplate Code */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 font-bengali flex items-center gap-1.5">
                <Code className="w-4 h-4 text-emerald-700" />
                <span>{isBn ? 'Google Apps Script Web App কোড স্নিপেট:' : 'Google Apps Script Integration Handler:'}</span>
              </span>
              <button
                onClick={handleCopyCode}
                className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কোড কপি করুন' : 'Copy Code')}</span>
              </button>
            </div>
            <pre className="p-4 bg-slate-900 text-emerald-400 rounded-2xl text-xs font-mono overflow-x-auto leading-relaxed">
              {appsScriptSnippet}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer font-bengali"
          >
            {isBn ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
