import React, { useState } from 'react';
import {
  Calculator,
  Scale,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Info,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { calculateFinancialFormulas } from '../../utils/financialFormulas';
import { formatCurrency } from '../../utils/formatters';

interface FormulaReconciliationCardProps {
  state: FinancialState;
  lang: Language;
}

export const FormulaReconciliationCard: React.FC<FormulaReconciliationCardProps> = ({
  state,
  lang,
}) => {
  const isBn = lang === 'bn';
  const [showBridge, setShowBridge] = useState(false);

  const result = calculateFinancialFormulas(state);

  const hasVariance = result.formulaAVsLedgerDiff !== 0;

  return (
    <div className="rounded-3xl bg-white border border-slate-200/90 shadow-sm p-6 lg:p-7 space-y-6">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-700 to-indigo-800 text-white flex items-center justify-center shadow-md shadow-blue-700/20 shrink-0">
            <Calculator className="w-6 h-6 stroke-[2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
                {isBn ? 'ক্যাশ ফর্মুলা ও লেজার রিকনসিলিয়েশন প্যানেল' : 'Cash Formula & Ledger Reconciliation Panel'}
              </h2>
            </div>
            <p className="text-xs text-slate-500 font-bengali">
              {isBn
                ? 'আপনার প্রদত্ত মূল সূত্র A ও B অপরিবর্তিত রেখে ডাবল-এন্ট্রি লেজার ব্যালেন্সের সাথে স্বচ্ছ তুলনা'
                : 'Unaltered User Formula A & B evaluation mapped against audited double-entry ledger balance'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasVariance ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-300 text-amber-900 text-xs font-bold font-bengali">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>{isBn ? 'রিকনসিলিয়েশন ব্যবধান বিদ্যমান' : 'Variance Reconciled'}</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-bold font-bengali">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isBn ? 'শতভাগ সামঞ্জস্যপূর্ণ' : '100% In Agreement'}</span>
            </span>
          )}
        </div>
      </div>

      {/* 3 Core Results in Comparison Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* User Formula A */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-blue-50/70 via-sky-50/50 to-white border border-blue-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-blue-900 font-bengali">
            <span>{isBn ? 'সূত্র A: বর্তমান ক্যাশ' : 'Formula A: Present Cash'}</span>
            <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px]">User Formula</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-blue-950 font-mono tracking-tight tabular-nums">
            {formatCurrency(result.formulaAValue, lang)}
          </div>
          <p className="text-[11px] text-blue-800/80 font-bengali leading-relaxed pt-1 border-t border-blue-200/60">
            {isBn
              ? 'সূত্র: মোট বিনিয়োগ মূলধন − মোট ঋণ বিতরণ + মোট ঋণ আদায় + মোট সঞ্চয় আদায় − মোট সঞ্চয় উত্তোলন + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায়'
              : 'Formula: Capital − Loan Disbursed + Loan Recovered + Savings In − Savings Out + Insurance + Admission'}
          </p>
        </div>

        {/* User Formula B */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-indigo-50/70 via-purple-50/50 to-white border border-indigo-200/80 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-indigo-900 font-bengali">
            <span>{isBn ? 'সূত্র B: টোটাল ক্যাশ' : 'Formula B: Total Cash'}</span>
            <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 text-[10px]">User Formula</span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-indigo-950 font-mono tracking-tight tabular-nums">
            {formatCurrency(result.formulaBValue, lang)}
          </div>
          <p className="text-[11px] text-indigo-800/80 font-bengali leading-relaxed pt-1 border-t border-indigo-200/60">
            {isBn
              ? 'সূত্র: মোট বিনিয়োগ মূলধন + মোট সঞ্চয় আদায় + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায় − মোট সঞ্চয় উত্তোলন − মোট খরচ'
              : 'Formula: Capital + Savings In + Insurance + Admission − Savings Out − Approved Expenses'}
          </p>
        </div>

        {/* System Double-Entry Ledger Cash */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-emerald-50/80 via-teal-50/50 to-white border border-emerald-300 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-emerald-950 font-bengali">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>{isBn ? 'যাচাইকৃত লেজার ক্যাশ ব্যালেন্স' : 'Verified Ledger Cash Balance'}</span>
            </span>
            <span className="px-2 py-0.5 rounded-md bg-emerald-200/80 text-emerald-950 text-[10px] font-bold">
              Double-Entry Ledger
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-950 font-mono tracking-tight tabular-nums">
            {formatCurrency(result.ledgerCashValue, lang)}
          </div>
          <p className="text-[11px] text-emerald-900/80 font-bengali leading-relaxed pt-1 border-t border-emerald-200/70">
            {isBn
              ? 'ভল্ট নগদ (A/C 1001) + সকল ব্যাংক একাউন্ট (A/C 1002/1003)-এ সফলভাবে পোস্ট হওয়া ডেবিট ও ক্রেডিটের সঠিক জের।'
              : 'Sum of physically verified Cash-in-Hand (1001) and Bank Assets (1002/1003) from posted double-entry journal items.'}
          </p>
        </div>
      </div>

      {/* Variance Alert Banner & Reconciliation Bridge Toggle */}
      <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-700 font-bengali">
              <span className="font-bold text-slate-900 block">
                {isBn ? 'আর্থিক স্বচ্ছতা ও রিকনসিলিয়েশন প্রতিবেদন:' : 'Financial Transparency & Reconciliation Notes:'}
              </span>
              <p className="mt-0.5 leading-relaxed text-slate-600">
                {isBn
                  ? 'আপনার মূল সূত্রদ্বয় অক্ষত রেখে সিস্টেম-লেজার ব্যালেন্সের সাথে তুলনা করা হচ্ছে। অনুমোদিত খরচ, ঋণের মুনাফা এবং ব্যবসায়িক প্রকল্প বরাদ্দের কারণে যে পার্থক্যের উপাদান সৃষ্টি হয় তা নিচে দৃশ্যমান।'
                  : 'User-defined formulas are evaluated alongside double-entry cash ledger. The bridge items below account for operational expenditures, loan profit splits, and project capital.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowBridge(!showBridge)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-800 text-xs font-bold transition-colors cursor-pointer shrink-0 font-bengali"
          >
            <span>{isBn ? (showBridge ? 'ব্রিজ সংক্ষেপ করুন' : 'রিকনসিলিয়েশন ব্রিজ দেখুন') : (showBridge ? 'Hide Bridge' : 'Show Bridge Items')}</span>
            {showBridge ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {/* Detailed Reconciliation Bridge Items */}
        {showBridge && (
          <div className="mt-4 pt-4 border-t border-slate-200 space-y-2.5 animate-fadeIn">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider font-bengali">
              {isBn ? 'ব্যবধানে প্রভাব ফেলা উপাদানের তালিকা (Bridge Items):' : 'Reconciliation Adjusting Components:'}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-bengali">
              {result.reconciliationItems.map((item, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-white border border-slate-200/90 shadow-2xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{isBn ? item.labelBn : item.labelEn}</span>
                    <span className={`font-mono font-bold ${item.impact === 'DECREASE' ? 'text-rose-600' : 'text-emerald-700'}`}>
                      {item.impact === 'DECREASE' ? '− ' : '+ '}
                      {formatCurrency(item.amount, lang)}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {isBn ? item.noteBn : item.noteEn}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
