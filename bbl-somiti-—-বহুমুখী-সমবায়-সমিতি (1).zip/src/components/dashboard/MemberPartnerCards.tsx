import React from 'react';
import {
  Users,
  UserCheck,
  UserX,
  UserPlus,
  Briefcase,
  Award,
  Coins,
  ArrowDownRight,
  FileSpreadsheet,
  Clock,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface MemberPartnerCardsProps {
  state: FinancialState;
  lang: Language;
}

export const MemberPartnerCards: React.FC<MemberPartnerCardsProps> = ({ state, lang }) => {
  const isBn = lang === 'bn';

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'সদস্য ও পার্টনার পরিসংখ্যান (Members & Partners Register)' : 'Members & Partners Portfolio'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? 'সদস্য সংখ্যা, পার্টনার মূলধন, উত্তোলন ও অনুমোদন অপেক্ষমাণ প্রোফাইল'
              : 'Active member census, partner equity stakes, withdrawals, and probationary tickets'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {/* 1. Total Members */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '১. মোট নিবন্ধিত সদস্য' : '1. Total Members'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatNumber(state.totalMembersCount, lang)} {isBn ? 'জন' : ''}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সমিতির মোট নথিভুক্ত সদস্য' : 'Registered member count'}
          </p>
        </div>

        {/* 2. Active Members */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '২. সক্রিয় সদস্য' : '2. Active Members'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatNumber(state.activeMembersCount, lang)} {isBn ? 'জন' : ''}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'নিয়মিত সঞ্চয়/ঋণ চলমান' : 'Active transaction status'}
          </p>
        </div>

        {/* 3. Inactive Members */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৩. নিষ্ক্রিয় সদস্য' : '3. Inactive Members'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center">
              <UserX className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-700 font-mono tabular-nums">
            {formatNumber(state.inactiveMembersCount, lang)} {isBn ? 'জন' : ''}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'সাময়িক স্থবির অ্যাকাউন্ট' : 'Dormant member accounts'}
          </p>
        </div>

        {/* 4. New Member Applications */}
        <div className="rounded-2xl p-4 sm:p-5 bg-amber-50/60 border border-amber-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider font-bengali">
              {isBn ? '৪. নতুন সদস্য আবেদন' : '4. New Applications'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-950 font-mono tabular-nums">
            {formatNumber(state.newMemberApplicationsCount, lang)} {isBn ? 'টি' : ''}
          </div>
          <p className="text-[11px] text-amber-800 font-bengali">
            {isBn ? 'যাচাই ও অনুমোদনের অপেক্ষায়' : 'Awaiting onboarding approval'}
          </p>
        </div>

        {/* 5. Total Partners */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৫. মোট পার্টনার' : '5. Total Partners'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 font-mono tabular-nums">
            {formatNumber(state.totalPartnersCount, lang)} {isBn ? 'জন' : ''}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'ইকুইটি শেয়ার পার্টনার' : 'Equity capital stakeholders'}
          </p>
        </div>

        {/* 6. Active Partners */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৬. সক্রিয় পার্টনার' : '6. Active Partners'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
            {formatNumber(state.activePartnersCount, lang)} {isBn ? 'জন' : ''}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'চলমান অংশীদার' : 'Fully active partner stakes'}
          </p>
        </div>

        {/* 7. Total Partner Capital */}
        <div className="rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-indigo-50 to-purple-50/60 border border-indigo-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-indigo-900 uppercase tracking-wider font-bengali">
              {isBn ? '৭. মোট পার্টনার মূলধন' : '7. Partner Equity'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-700 text-white flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-indigo-950 font-mono tabular-nums">
            {formatCurrency(state.totalPartnerCapital, lang)}
          </div>
          <p className="text-[11px] text-indigo-800 font-bengali">
            {isBn ? 'পার্টনারদের মোট ইকুইটি' : 'Cumulative partner capital'}
          </p>
        </div>

        {/* 8. Partner Withdrawals */}
        <div className="rounded-2xl p-4 sm:p-5 bg-white border border-slate-200/90 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-bengali">
              {isBn ? '৮. পার্টনার উত্তোলন' : '8. Capital Outflow'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
              <ArrowDownRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-rose-800 font-mono tabular-nums">
            {formatCurrency(state.totalPartnerWithdrawals, lang)}
          </div>
          <p className="text-[11px] text-slate-500 font-bengali">
            {isBn ? 'অনুমোদিত মূলধন ফেরত' : 'Approved partner returns'}
          </p>
        </div>

        {/* 9. Partner Statements */}
        <div className="rounded-2xl p-4 sm:p-5 bg-slate-900 text-white shadow-2xs space-y-1.5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-purple-300 font-bold uppercase tracking-wider font-bengali">
                {isBn ? '৯. পার্টনার স্টেটমেন্ট' : '9. Partner Ledger'}
              </span>
              <FileSpreadsheet className="w-4 h-4 text-purple-300" />
            </div>
            <p className="text-xs text-slate-300 font-bengali mt-2">
              {isBn
                ? 'পার্টনারভিত্তিক ইনভেস্টমেন্ট ও লাভ বণ্টন বিবরণী প্রস্তুত'
                : 'Partner-wise equity statements verified'}
            </p>
          </div>
          <div className="text-[11px] text-purple-300 font-semibold font-bengali">
            {isBn ? 'পার্টনার লেজার রেডি' : 'Ledger Active'}
          </div>
        </div>

        {/* 10. Pending Requests */}
        <div className="rounded-2xl p-4 sm:p-5 bg-amber-50/60 border border-amber-200 shadow-2xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider font-bengali">
              {isBn ? '১০. পেন্ডিং আবেদনসমূহ' : '10. Pending Tickets'}
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-950 font-mono tabular-nums">
            {formatNumber(state.pendingPartnerRequestsCount + state.newMemberApplicationsCount, lang)} {isBn ? 'টি' : ''}
          </div>
          <p className="text-[11px] text-amber-800 font-bengali">
            {isBn ? 'সদস্য ও পার্টনার রিকোয়েস্ট' : 'Total membership & partner queues'}
          </p>
        </div>
      </div>
    </div>
  );
};
