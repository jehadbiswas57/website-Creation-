import React from 'react';
import {
  Menu,
  Globe,
  Bell,
  Search,
  PlusCircle,
  Database,
  Calendar,
  ShieldCheck,
} from 'lucide-react';
import { SidebarSection, Language, DateRange, DataMode, Role } from '../../types/dashboard';

interface HeaderBarProps {
  currentSection: SidebarSection;
  lang: Language;
  onToggleLang: () => void;
  dateRange: DateRange;
  onChangeDateRange: (range: DateRange) => void;
  dataMode: DataMode;
  onToggleDataMode: () => void;
  pendingCount: number;
  onOpenQuickActions: () => void;
  onOpenMobileMenu: () => void;
  onOpenApprovals: () => void;
  currentRole: Role;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentSection,
  lang,
  onToggleLang,
  dateRange,
  onChangeDateRange,
  dataMode,
  onToggleDataMode,
  pendingCount,
  onOpenQuickActions,
  onOpenMobileMenu,
  onOpenApprovals,
  currentRole,
}) => {
  const isBn = lang === 'bn';

  const sectionTitles: Record<SidebarSection, { bn: string; en: string }> = {
    dashboard: { bn: 'প্রধান ক্যাশ ও আর্থিক ড্যাশবোর্ড', en: 'Super Admin Financial Dashboard' },
    members: { bn: 'সদস্য তালিকা ও তথ্য', en: 'Member Management' },
    partners: { bn: 'অংশীদার / পার্টনার বিবরণী', en: 'Partner Management' },
    loans: { bn: 'ঋণ বিতরণ ও আদায় কার্যক্রম', en: 'Loan Disbursement & Recovery' },
    savings: { bn: 'সঞ্চয় হিসাব ও উত্তোলন', en: 'Savings & Withdrawal Management' },
    dps: { bn: 'ডিপিএস হিসাব ও স্কিম', en: 'DPS Schemes & Liabilities' },
    insurance: { bn: 'কল্যাণ ও বীমা তহবিল', en: 'Insurance Fund & Claims' },
    admission: { bn: 'সদস্য ভর্তি ফি হিসাব', en: 'Admission Fees & Arrears' },
    verification: { bn: 'পেমেন্ট যাচাইকরণ', en: 'Payment Verification & Matching' },
    approvals: { bn: 'অনুমোদন কেন্দ্র', en: 'Approval Center' },
    cashbook: { bn: 'ক্যাশ বই ও দৈনিক হিসাব', en: 'Daily Cashbook' },
    chart_of_accounts: { bn: 'হিসাবের কোড তালিকা (চার্ট অব অ্যাকাউন্টস)', en: 'Chart of Accounts' },
    general_ledger: { bn: 'সাধারণ খতিয়ান বিবরণী', en: 'General Ledger' },
    transactions: { bn: 'দৈনিক লেনদেন বিবরণী', en: 'Transaction Journal' },
    income_expense: { bn: 'আয় ও ব্যয় হিসাব বিবরণী', en: 'Income & Expense Statement' },
    business: { bn: 'সমিতির ব্যবসায়িক প্রকল্পসমূহ', en: 'Business Investment Enterprises' },
    partner_capital: { bn: 'পার্টনারদের মূলধন রেজিস্টার', en: 'Partner Capital Register' },
    member_deposit: { bn: 'সদস্যের জমা গ্রহণ', en: 'Direct Member Deposit' },
    reports: { bn: 'আর্থিক প্রতিবেদন ও রিপোর্ট', en: 'Financial Statements & Audit' },
    documents: { bn: 'নথিপত্র ও ফাইলপত্র', en: 'Documents & File Vault' },
    notices: { bn: 'নোটিশ বোর্ড ও বার্তা', en: 'Notices & Messaging' },
    users: { bn: 'ব্যবহারকারী ও রোল পারমিশন', en: 'Users & Permission Matrix' },
    audit_log: { bn: 'নিরাপত্তা ও অডিট লগ', en: 'System Audit Log' },
    settings: { bn: 'সিস্টেম ও ব্র্যান্ডিং সেটিংস', en: 'Super Admin Settings' },
    help: { bn: 'ব্যবহার নির্দেশিকা ও সহায়তা', en: 'Help & Operational Guide' },
    sheets_schema: { bn: 'স্প্রেডশিট ডেটাবেজ স্কিমা', en: 'Google Sheets / DB Schema' },
  };

  const title = sectionTitles[currentSection] || { bn: 'ড্যাশবোর্ড', en: 'Dashboard' };

  return (
    <header className="sticky top-0 z-20 bg-white border-b border-slate-200 shadow-xs">
      <div className="px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Left: Mobile Toggle & Title */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={onOpenMobileMenu}
              className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden cursor-pointer"
              aria-label="Open mobile navigation"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="min-w-0">
              <nav className="flex items-center gap-2 text-[11px] font-semibold text-slate-500 font-bengali">
                <span>BBL SOMITI</span>
                <span>/</span>
                <span className="text-blue-700 font-bold truncate">
                  {isBn ? title.bn : title.en}
                </span>
              </nav>
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight truncate font-display">
                {isBn ? title.bn : title.en}
              </h1>
            </div>
          </div>

          {/* Right: Controls & Profile */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick Action Button */}
            <button
              onClick={onOpenQuickActions}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm shadow-emerald-700/20 transition-all cursor-pointer font-bengali active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{isBn ? 'দ্রুত লেনদেন' : 'Quick Action'}</span>
            </button>

            {/* Data Mode Switcher (Empty State vs Audited Dataset) */}
            <button
              onClick={onToggleDataMode}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer font-bengali ${
                dataMode === 'empty'
                  ? 'bg-amber-50 text-amber-900 border-amber-300 shadow-xs'
                  : 'bg-blue-50 text-blue-900 border-blue-200'
              }`}
              title={
                isBn
                  ? 'ডাটা স্টেট টগল করুন: শূন্য রেকর্ড বনাম টেস্ট অডিট ডাটা'
                  : 'Toggle data state: Zero record empty state vs Audited reference dataset'
              }
            >
              <Database className="w-3.5 h-3.5" />
              <span className="hidden md:inline">
                {isBn ? 'ডাটা মোড:' : 'Data:'}
              </span>
              <span>
                {dataMode === 'empty'
                  ? (isBn ? 'শূন্য রেকর্ড (Empty)' : 'Empty (0 Rec)')
                  : (isBn ? 'অডিটেড ডাটা' : 'Audited')}
              </span>
            </button>

            {/* Date Range Selector */}
            <div className="hidden xl:flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
              {(['today', 'month', 'year', 'all'] as DateRange[]).map((range) => {
                const labels: Record<DateRange, { bn: string; en: string }> = {
                  today: { bn: 'আজ', en: 'Today' },
                  week: { bn: 'সপ্তাহ', en: 'Week' },
                  month: { bn: 'এই মাস', en: 'Month' },
                  quarter: { bn: 'কোয়ার্টার', en: 'Quarter' },
                  year: { bn: 'বছর', en: 'Year' },
                  all: { bn: 'সব', en: 'All' },
                };
                const isActive = dateRange === range;
                return (
                  <button
                    key={range}
                    onClick={() => onChangeDateRange(range)}
                    className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer font-bengali ${
                      isActive
                        ? 'bg-white text-slate-900 shadow-xs font-bold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {isBn ? labels[range].bn : labels[range].en}
                  </button>
                );
              })}
            </div>

            {/* Language Toggle */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-bold border border-slate-200 transition-colors cursor-pointer"
              title="Change Language (বাংলা / English)"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{isBn ? 'EN' : 'বাং'}</span>
            </button>

            {/* Notifications / Pending approvals */}
            <button
              onClick={onOpenApprovals}
              className="relative p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              title={isBn ? 'অনুমোদন তালিকা দেখুন' : 'View Pending Approvals'}
            >
              <Bell className="w-5 h-5" />
              {pendingCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white"></span>
              )}
            </button>

            {/* Profile Avatar / Role Tag */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-700 to-indigo-600 text-white font-bold flex items-center justify-center text-xs shadow-xs">
                SA
              </div>
              <div className="hidden lg:block text-left">
                <span className="block text-xs font-bold text-slate-900 leading-none">
                  {isBn ? 'সুপার এডমিন' : 'Super Admin'}
                </span>
                <span className="block text-[10px] text-emerald-700 font-semibold mt-0.5">
                  Verified Authority
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
