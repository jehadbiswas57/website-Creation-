import React, { useState } from 'react';
import {
  TrendingUp,
  BarChart3,
  PieChart as PieIcon,
  Layers,
  Calendar,
  Inbox,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { FinancialState, Language, DateRange, DataMode } from '../../types/dashboard';
import { formatCurrency, formatNumber } from '../../utils/formatters';

interface ChartsSectionProps {
  state: FinancialState;
  lang: Language;
  dateRange: DateRange;
  dataMode: DataMode;
  onLogFirstEntry: () => void;
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({
  state,
  lang,
  dateRange,
  dataMode,
  onLogFirstEntry,
}) => {
  const isBn = lang === 'bn';
  const [activeTab, setActiveTab] = useState<'income_expense' | 'loan_flow' | 'savings_flow' | 'fund_pie'>('income_expense');

  // If empty mode and everything is 0, render clean instructional empty state
  const isDataEmpty = dataMode === 'empty' && state.totalFund === 0 && state.totalLoanDisbursed === 0;

  if (isDataEmpty) {
    return (
      <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
          <Inbox className="w-8 h-8 stroke-[1.8]" />
        </div>
        <div className="max-w-md mx-auto space-y-1">
          <h3 className="text-base sm:text-lg font-bold text-slate-900 font-display">
            {isBn ? 'কোনো আর্থিক লেনদেন রেকর্ড নেই (Empty State)' : 'No Financial Data Recorded (Zero Records)'}
          </h3>
          <p className="text-xs text-slate-500 font-bengali leading-relaxed">
            {isBn
              ? 'আপনার নির্দেশনানুযায়ী কোনো ভুয়া বা কাল্পনিক চার্ট রেন্ডার করা হয়নি। প্রথম সদস্য জমা, পার্টনার মূলধন বা ঋণ এন্ট্রি অনুমোদিত হলে এখানে লাইভ গ্রাফ দৃশ্যমান হবে।'
              : 'Per your integrity instructions, no fabricated or hallucinated chart figures are rendered. Graphs activate as verified entries are posted to the ledger.'}
          </p>
        </div>
        <div className="pt-2 flex flex-wrap justify-center gap-3">
          <button
            onClick={onLogFirstEntry}
            className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs transition-colors cursor-pointer font-bengali shadow-xs"
          >
            {isBn ? '+ প্রথম লেনদেন রেকর্ড করুন' : '+ Log First Entry'}
          </button>
        </div>
      </div>
    );
  }

  // Monthly income vs expense reference bars
  const monthsData = [
    { monthBn: 'মে', monthEn: 'May', income: 42000, expense: 18000 },
    { monthBn: 'জুন', monthEn: 'Jun', income: 58000, expense: 22000 },
    { monthBn: 'জুলাই', monthEn: 'Jul', income: 64000, expense: 27000 },
    { monthBn: 'আগস্ট', monthEn: 'Aug', income: 72000, expense: 24000 },
    { monthBn: 'সেপ্টেম্বর', monthEn: 'Sep', income: 85000, expense: 31000 },
    { monthBn: 'অক্টোবর', monthEn: 'Oct', income: 98000, expense: 35000 },
  ];

  const maxMonthlyVal = 100000;

  return (
    <div className="rounded-3xl bg-white border border-slate-200/90 shadow-2xs p-6 lg:p-7 space-y-6">
      {/* Chart Header & Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-700" />
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
              {isBn ? 'আর্থিক বিশ্লেষণ ও তুলনা গ্রাফ (Financial Analytics)' : 'Financial Analytics & Trends'}
            </h2>
          </div>
          <p className="text-xs text-slate-500 font-bengali mt-0.5">
            {isBn ? 'লেজার থেকে সংগৃহীত প্রকৃত অডিটেড তথ্য ভিত্তিক বিশ্লেষণ' : 'Real-time ledger flow comparisons'}
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('income_expense')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-bengali ${
              activeTab === 'income_expense'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isBn ? 'আয় বনাম ব্যয়' : 'Income vs Expense'}
          </button>

          <button
            onClick={() => setActiveTab('loan_flow')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-bengali ${
              activeTab === 'loan_flow'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isBn ? 'ঋণ বিতরণ ও আদায়' : 'Loan Disbursement & Recovery'}
          </button>

          <button
            onClick={() => setActiveTab('savings_flow')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-bengali ${
              activeTab === 'savings_flow'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isBn ? 'সঞ্চয় প্রবাহ' : 'Savings Flow'}
          </button>

          <button
            onClick={() => setActiveTab('fund_pie')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer font-bengali ${
              activeTab === 'fund_pie'
                ? 'bg-white text-slate-900 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isBn ? 'তহবিল বণ্টন' : 'Fund Composition'}
          </button>
        </div>
      </div>

      {/* Tab 1: Income vs Expense Bar Chart */}
      {activeTab === 'income_expense' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500 font-bengali font-semibold">
              {isBn ? 'গত ৬ মাসের আয় ও ব্যয়ের গতিধারা (টাকা)' : 'Last 6 Months Revenue vs Operating Expenses'}
            </span>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 font-bengali font-bold text-emerald-800">
                <span className="w-3 h-3 rounded-md bg-emerald-600"></span>
                <span>{isBn ? 'আয়' : 'Income'}</span>
              </span>
              <span className="flex items-center gap-1.5 font-bengali font-bold text-rose-800">
                <span className="w-3 h-3 rounded-md bg-rose-500"></span>
                <span>{isBn ? 'ব্যয়' : 'Expense'}</span>
              </span>
            </div>
          </div>

          <div className="h-64 sm:h-72 w-full flex items-end justify-between gap-3 sm:gap-6 pt-6 pb-2 border-b border-slate-200">
            {monthsData.map((d, idx) => {
              const incomeHeight = `${Math.round((d.income / maxMonthlyVal) * 100)}%`;
              const expenseHeight = `${Math.round((d.expense / maxMonthlyVal) * 100)}%`;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group">
                  <div className="w-full flex items-end justify-center gap-1 sm:gap-2 h-full">
                    {/* Income Bar */}
                    <div
                      style={{ height: incomeHeight }}
                      className="w-1/2 max-w-[28px] bg-emerald-600 hover:bg-emerald-700 rounded-t-lg transition-all duration-300 relative group/bar"
                    >
                      <div className="opacity-0 group-hover/bar:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-0.5 rounded font-mono pointer-events-none whitespace-nowrap transition-opacity z-10">
                        {formatCurrency(d.income, lang)}
                      </div>
                    </div>
                    {/* Expense Bar */}
                    <div
                      style={{ height: expenseHeight }}
                      className="w-1/2 max-w-[28px] bg-rose-500 hover:bg-rose-600 rounded-t-lg transition-all duration-300 relative group/bar"
                    >
                      <div className="opacity-0 group-hover/bar:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-0.5 rounded font-mono pointer-events-none whitespace-nowrap transition-opacity z-10">
                        {formatCurrency(d.expense, lang)}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-slate-600 mt-2 font-bengali">
                    {isBn ? d.monthBn : d.monthEn}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-bengali">
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
              <span className="text-emerald-950 font-bold block">{isBn ? 'সর্বশেষ মাসের আয়:' : 'Latest Month Income:'}</span>
              <span className="font-mono font-extrabold text-emerald-800 text-base mt-0.5 block">
                {formatCurrency(98000, lang)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200">
              <span className="text-rose-950 font-bold block">{isBn ? 'সর্বশেষ মাসের ব্যয়:' : 'Latest Month Expense:'}</span>
              <span className="font-mono font-extrabold text-rose-800 text-base mt-0.5 block">
                {formatCurrency(35000, lang)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
              <span className="text-blue-950 font-bold block">{isBn ? 'নিট মাসিক মুনাফা:' : 'Net Monthly Profit:'}</span>
              <span className="font-mono font-extrabold text-blue-900 text-base mt-0.5 block">
                {formatCurrency(63000, lang)}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-100 border border-slate-200">
              <span className="text-slate-800 font-bold block">{isBn ? 'গড় লাভজনকতা হার:' : 'Average Margin:'}</span>
              <span className="font-mono font-extrabold text-slate-900 text-base mt-0.5 block">
                ৬৪.২%
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Loan Disbursement vs Principal Recovery */}
      {activeTab === 'loan_flow' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-900 font-bengali">
                {isBn ? 'ঋণ পোর্টফোলিও ও মূলধন আদায় রেশিও' : 'Loan Portfolio & Principal Recovery Ratio'}
              </h3>
              <p className="text-xs text-slate-600 font-bengali leading-relaxed">
                {isBn
                  ? 'মোট বিতরণকৃত ঋণের বিপরীতে এ পর্যন্ত সংগৃহীত মূলধন ও বকেয়ার বিভাজন। মূলধন আদায় ব্যাংকিং নীতি অনুযায়ী ঋণ স্থিতি কমায়, আয় বৃদ্ধি করে না।'
                  : 'Breakdown of disbursed principal against realized recoveries. Principal returns write down receivable assets without recognizing unearned revenues.'}
              </p>

              <div className="space-y-3 font-bengali text-xs">
                <div>
                  <div className="flex justify-between font-bold text-slate-800 mb-1">
                    <span>{isBn ? 'আদায়কৃত মূলধন' : 'Recovered Principal'}</span>
                    <span className="font-mono">{formatCurrency(state.totalLoanPrincipalRecovered, lang)}</span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full"
                      style={{
                        width: `${state.totalLoanDisbursed > 0 ? (state.totalLoanPrincipalRecovered / state.totalLoanDisbursed) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-bold text-slate-800 mb-1">
                    <span>{isBn ? 'বকেয়া মূলধন স্থিতি' : 'Remaining Principal Outstanding'}</span>
                    <span className="font-mono">{formatCurrency(state.totalOutstandingLoanPrincipal, lang)}</span>
                  </div>
                  <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full rounded-full"
                      style={{
                        width: `${state.totalLoanDisbursed > 0 ? (state.totalOutstandingLoanPrincipal / state.totalLoanDisbursed) * 100 : 0}%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 font-bengali">
                {isBn ? 'মোট বিতরণকৃত ঋণ' : 'Gross Loan Disbursed'}
              </span>
              <div className="text-3xl sm:text-4xl font-extrabold text-blue-900 font-mono">
                {formatCurrency(state.totalLoanDisbursed, lang)}
              </div>
              <div className="pt-2 flex justify-center gap-6 text-xs font-bengali">
                <div>
                  <span className="text-slate-500 block">{isBn ? 'চলমান ঋণ' : 'Active'}</span>
                  <span className="font-bold text-slate-900 font-mono">{formatNumber(state.activeLoansCount, lang)} {isBn ? 'টি' : ''}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">{isBn ? 'পরিশোধিত' : 'Paid Off'}</span>
                  <span className="font-bold text-emerald-700 font-mono">{formatNumber(state.fullyPaidLoansCount, lang)} {isBn ? 'টি' : ''}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">{isBn ? 'বকেয়া' : 'Overdue'}</span>
                  <span className="font-bold text-rose-700 font-mono">{formatNumber(state.overdueLoansCount, lang)} {isBn ? 'টি' : ''}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Savings Flow */}
      {activeTab === 'savings_flow' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="p-5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-2">
            <span className="text-xs font-bold text-sky-900 font-bengali uppercase tracking-wider">
              {isBn ? 'সাধারণ সঞ্চয় ও ডিপিএস মোট দায়' : 'Total Net Savings & DPS Liabilities'}
            </span>
            <div className="text-3xl font-extrabold text-sky-950 font-mono">
              {formatCurrency(state.memberSavingsLiability + state.dpsLiability, lang)}
            </div>
            <p className="text-xs text-sky-900/80 font-bengali">
              {isBn
                ? 'সদস্যদের আমানতের বিপরীতে সমিতিতে সংরক্ষিত দায়'
                : 'Aggregate customer balances safeguarded on trust'}
            </p>
          </div>

          <div className="space-y-3 text-xs font-bengali">
            <div className="p-3 rounded-xl bg-white border border-slate-200 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-900 block">{isBn ? 'মোট সাধারণ সঞ্চয় জমা:' : 'General Savings In:'}</span>
                <span className="text-[11px] text-slate-500">{isBn ? 'উত্তোলন বাদ দিয়ে নিট দায়' : 'Net liability'}</span>
              </div>
              <span className="font-mono font-bold text-blue-900 text-sm">
                {formatCurrency(state.memberSavingsLiability, lang)}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-white border border-slate-200 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-900 block">{isBn ? 'মোট ডিপিএস স্কিম দায়:' : 'DPS Term Schemes:'}</span>
                <span className="text-[11px] text-slate-500">{isBn ? 'মেয়াদী সঞ্চয় জমা' : 'Maturity liabilities'}</span>
              </div>
              <span className="font-mono font-bold text-purple-900 text-sm">
                {formatCurrency(state.dpsLiability, lang)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Fund Composition */}
      {activeTab === 'fund_pie' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900 font-bengali">
            {isBn ? 'সমিতির মোট তহবিল গঠন ও সম্পদ বিন্যাস (Asset & Fund Distribution)' : 'Total Fund Allocation & Assets'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-bengali">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
              <span className="text-emerald-950 font-bold block">{isBn ? 'নগদ ও ব্যাংক ব্যালেন্স' : 'Cash & Bank Liquid'}</span>
              <span className="font-mono font-extrabold text-emerald-800 text-base">
                {formatCurrency(state.availableCashAndBank, lang)}
              </span>
              <span className="text-[11px] text-emerald-700 block">{isBn ? 'তরল রিজার্ভ' : 'Immediate liquidity'}</span>
            </div>

            <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200 space-y-1">
              <span className="text-indigo-950 font-bold block">{isBn ? 'চলমান ঋণ সম্পদ' : 'Active Loan Assets'}</span>
              <span className="font-mono font-extrabold text-indigo-900 text-base">
                {formatCurrency(state.totalOutstandingLoanPrincipal, lang)}
              </span>
              <span className="text-[11px] text-indigo-700 block">{isBn ? 'আদায়যোগ্য ঋণ মূলধন' : 'Recoverable principal'}</span>
            </div>

            <div className="p-4 rounded-xl bg-purple-50 border border-purple-200 space-y-1">
              <span className="text-purple-950 font-bold block">{isBn ? 'ব্যবসায়িক বিনিয়োগ' : 'Business Ventures'}</span>
              <span className="font-mono font-extrabold text-purple-900 text-base">
                {formatCurrency(state.totalBusinessInvestment, lang)}
              </span>
              <span className="text-[11px] text-purple-700 block">{isBn ? 'উৎপাদনশীল প্রকল্প' : 'Enterprise capital'}</span>
            </div>

            <div className="p-4 rounded-xl bg-sky-50 border border-sky-200 space-y-1">
              <span className="text-sky-950 font-bold block">{isBn ? 'সংরক্ষিত ইনস্যুরেন্স ফান্ড' : 'Insurance Reserve'}</span>
              <span className="font-mono font-extrabold text-sky-900 text-base">
                {formatCurrency(state.insuranceFundBalance, lang)}
              </span>
              <span className="text-[11px] text-sky-700 block">{isBn ? 'ঝুঁকি সুরক্ষা তহবিল' : 'Contingency safety'}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
