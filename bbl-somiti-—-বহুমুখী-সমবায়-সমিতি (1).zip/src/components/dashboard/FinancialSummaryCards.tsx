import React from 'react';
import {
  Banknote,
  Landmark,
  Wallet,
  ShieldCheck,
  Building,
  Users,
  PiggyBank,
  UserCheck,
  ShieldAlert,
  FolderPlus,
  Receipt,
  BriefcaseBusiness,
  Scale,
  TrendingUp,
  TrendingDown,
  Coins,
  CheckCircle,
} from 'lucide-react';
import { FinancialState, Language } from '../../types/dashboard';
import { formatCurrency } from '../../utils/formatters';

interface FinancialSummaryCardsProps {
  state: FinancialState;
  lang: Language;
  onCardClick?: (cardKey: string) => void;
}

export const FinancialSummaryCards: React.FC<FinancialSummaryCardsProps> = ({
  state,
  lang,
  onCardClick,
}) => {
  const isBn = lang === 'bn';

  const cards = [
    // 1. Present Cash
    {
      key: 'presentCash',
      titleBn: '১. বর্তমান নগদ টাকা',
      titleEn: '1. Present Cash in Hand',
      value: state.presentCash,
      icon: Banknote,
      color: 'emerald',
      categoryBn: 'নগদ সম্পদ (A/C 1001)',
      categoryEn: 'Liquid Cash Asset',
      noteBn: 'ভল্ট ও ক্যাশ ড্রয়ারে রক্ষিত যাচাইকৃত নগদ টাকা',
      noteEn: 'Physically audited cash in vault and drawers',
    },
    // 2. Bank Balance
    {
      key: 'bankBalance',
      titleBn: '২. বর্তমান ব্যাংক ব্যালেন্স',
      titleEn: '2. Bank Account Balance',
      value: state.bankBalance,
      icon: Landmark,
      color: 'blue',
      categoryBn: 'ব্যাংক হিসাব (A/C 1002/1003)',
      categoryEn: 'Verified Bank Assets',
      noteBn: 'সমিতির বাণিজ্যিক ও সমবায় ব্যাংক হিসাবের ব্যালেন্স',
      noteEn: 'Current & savings balances across bank accounts',
    },
    // 3. Available Cash & Bank
    {
      key: 'availableCashAndBank',
      titleBn: '৩. মোট উপলব্ধ অর্থ (নগদ + ব্যাংক)',
      titleEn: '3. Total Available Cash & Bank',
      value: state.availableCashAndBank,
      icon: Wallet,
      color: 'teal',
      categoryBn: 'মোট তরল সম্পদ',
      categoryEn: 'Total Liquid Liquidity',
      highlight: true,
      noteBn: 'নগদ ও ব্যাংকের সমন্বিত কার্যকরী ব্যালেন্স',
      noteEn: 'Net active liquidity immediately accessible',
    },
    // 4. Total Fund
    {
      key: 'totalFund',
      titleBn: '৪. মোট তহবিল (Total Fund)',
      titleEn: '4. Total Fund',
      value: state.totalFund,
      icon: ShieldCheck,
      color: 'indigo',
      categoryBn: 'সংরক্ষিত মূল তহবিল',
      categoryEn: 'Reserved Core Fund',
      noteBn: 'সমিতির সংরক্ষিত মূল ও জরুরি তহবিল পোর্টফোলিও',
      noteEn: 'Statutory reserve & member welfare pool',
    },
    // 5. Total Investment Capital
    {
      key: 'totalInvestmentCapital',
      titleBn: '৫. মোট বিনিয়োগ মূলধন',
      titleEn: '5. Total Investment Capital',
      value: state.totalInvestmentCapital,
      icon: Coins,
      color: 'purple',
      categoryBn: 'ইকুইটি ও মূলধন (A/C 3001)',
      categoryEn: 'Core Equity Capital',
      noteBn: 'প্রতিষ্ঠাতা ও উদ্যোক্তা ইকুইটি মূলধন',
      noteEn: 'Core equity capital invested into the society',
    },
    // 6. Total Partner Deposits
    {
      key: 'totalPartnerDeposits',
      titleBn: '৬. মোট পার্টনার জমা',
      titleEn: '6. Total Partner Deposits',
      value: state.totalPartnerDeposits,
      icon: Building,
      color: 'blue',
      categoryBn: 'পার্টনার মূলধন হিসাব',
      categoryEn: 'Partner Capital Inflow',
      noteBn: 'পার্টনারদের অনুমোদিত বিনিয়োগকৃত ইকুইটি',
      noteEn: 'Equity deposits contributed by partners',
    },
    // 7. Total Member Savings Deposits
    {
      key: 'totalMemberSavingsDeposits',
      titleBn: '৭. মোট সদস্য সঞ্চয় জমা',
      titleEn: '7. Total Member Savings Deposits',
      value: state.totalMemberSavingsDeposits,
      icon: PiggyBank,
      color: 'sky',
      categoryBn: 'সদস্য সঞ্চয় আমানত (দায়)',
      categoryEn: 'Member Savings Liability',
      noteBn: 'সদস্যদের জমাকৃত মোট আমানত (আয় হিসেবে গণ্য নয়)',
      noteEn: 'Cumulative member deposits; classified as liability',
    },
    // 8. Total Admission Fees Collected
    {
      key: 'totalAdmissionFeesCollected',
      titleBn: '৮. মোট ভর্তি ফি আদায়',
      titleEn: '8. Admission Fees Collected',
      value: state.totalAdmissionFeesCollected,
      icon: UserCheck,
      color: 'emerald',
      categoryBn: 'সমবায় রাজস্ব আয়',
      categoryEn: 'Direct Operational Revenue',
      noteBn: 'প্রতি সদস্য ১০০ টাকা হারে জমাকৃত প্রাথমিক ভর্তি ফি',
      noteEn: 'Standard 100 BDT onboarding fee per member',
    },
    // 9. Total Insurance Collected
    {
      key: 'totalInsuranceCollected',
      titleBn: '৯. মোট ইনস্যুরেন্স আদায়',
      titleEn: '9. Total Insurance Collected',
      value: state.totalInsuranceCollected,
      icon: ShieldAlert,
      color: 'emerald',
      categoryBn: 'ইনস্যুরেন্স ও নিরাপত্তা তহবিল',
      categoryEn: 'Insurance Safety Reserve',
      noteBn: 'সদস্য ও ঋণ সুরক্ষার জন্য সংগৃহীত প্রিমিয়াম তহবিল',
      noteEn: 'Dedicated risk coverage reserve fund',
    },
    // 10. Other Collections
    {
      key: 'otherCollections',
      titleBn: '১০. অন্যান্য জমা ও বিবিধ আদায়',
      titleEn: '10. Other Collections',
      value: state.otherCollections,
      icon: FolderPlus,
      color: 'slate',
      categoryBn: 'বিবিধ প্রাপ্তি',
      categoryEn: 'Miscellaneous Receipts',
      noteBn: 'বিলম্ব ফি, পাসবই ফি ও বিবিধ সমবায় চার্জ',
      noteEn: 'Passbook, penalty, and incidental revenues',
    },
    // 11. Total Approved Expenses
    {
      key: 'totalApprovedExpenses',
      titleBn: '১১. মোট অনুমোদিত খরচ',
      titleEn: '11. Total Approved Expenses',
      value: state.totalApprovedExpenses,
      icon: Receipt,
      color: 'rose',
      categoryBn: 'অনুমোদিত পরিচালন ব্যয়',
      categoryEn: 'Approved Operational Cost',
      noteBn: 'ভাউচার ও সুপার এডমিন কর্তৃক অনুমোদিত মোট ব্যয়',
      noteEn: 'Voucher-verified operating expenditure',
    },
    // 12. Total Business Investment
    {
      key: 'totalBusinessInvestment',
      titleBn: '১২. মোট ব্যবসায়িক বিনিয়োগ',
      titleEn: '12. Total Business Investment',
      value: state.totalBusinessInvestment,
      icon: BriefcaseBusiness,
      color: 'indigo',
      categoryBn: 'প্রকল্প সম্পদ বিনিয়োগ',
      categoryEn: 'Enterprise Capital Outlay',
      noteBn: 'সমিতির উদ্যোগে পরিচালিত লাভজনক ব্যবসায়িক প্রকল্পে বরাদ্দ',
      noteEn: 'Capital deployed in cooperative business projects',
    },
    // 13. Business Income & Expense
    {
      key: 'businessIncomeAndExpense',
      titleBn: '১৩. ব্যবসা থেকে মোট আয় ও ব্যয়',
      titleEn: '13. Business Gross Revenue & Cost',
      value: state.businessIncome,
      subValue: state.businessExpense,
      icon: Scale,
      color: 'amber',
      isDual: true,
      categoryBn: 'ব্যবসা কার্যক্রম',
      categoryEn: 'Enterprise Operations',
      noteBn: `আয়: ${formatCurrency(state.businessIncome, lang)} | ব্যয়: ${formatCurrency(state.businessExpense, lang)}`,
      noteEn: `Income: ${formatCurrency(state.businessIncome, lang)} | Expense: ${formatCurrency(state.businessExpense, lang)}`,
    },
    // 14. Business Net Profit / Loss
    {
      key: 'businessNetProfit',
      titleBn: '১৪. ব্যবসার নিট লাভ বা ক্ষতি',
      titleEn: '14. Business Net Profit / Loss',
      value: state.businessNetProfit,
      icon: state.businessNetProfit >= 0 ? TrendingUp : TrendingDown,
      color: state.businessNetProfit >= 0 ? 'emerald' : 'rose',
      categoryBn: 'প্রকল্প নিট ফলাফল',
      categoryEn: 'Net Project Yield',
      noteBn: 'ব্যবসায়িক কার্যক্রম থেকে মোট নিট উদ্বৃত্ত',
      noteEn: 'Net operational earnings from cooperative ventures',
    },
    // 15. Somiti Total Income
    {
      key: 'somitiTotalIncome',
      titleBn: '১৫. সমিতির মোট আয়',
      titleEn: '15. Somiti Total Revenue',
      value: state.somitiTotalIncome,
      icon: TrendingUp,
      color: 'emerald',
      categoryBn: 'সার্বিক সমবায় রাজস্ব',
      categoryEn: 'Aggregate Cooperative Income',
      noteBn: 'ঋণের মুনাফা + ভর্তি ফি + ইনস্যুরেন্স + অন্যান্য আয়',
      noteEn: 'Loan interest + admission + insurance fees + enterprise',
    },
    // 16. Somiti Total Expense
    {
      key: 'somitiTotalExpense',
      titleBn: '১৬. সমিতির মোট ব্যয়',
      titleEn: '16. Somiti Total Expenditure',
      value: state.somitiTotalExpense,
      icon: TrendingDown,
      color: 'rose',
      categoryBn: 'সার্বিক সমবায় ব্যয়',
      categoryEn: 'Total Operating Expenses',
      noteBn: 'পরিচালন ব্যয় + বেতন + অফিস খরচ + প্রকল্প ব্যয়',
      noteEn: 'Administrative + logistics + facility outlays',
    },
    // 17. Somiti Net Profit / Loss
    {
      key: 'somitiNetProfit',
      titleBn: '১৭. সমিতির প্রকৃত নিট লাভ বা ক্ষতি',
      titleEn: '17. Somiti True Net Profit / Loss',
      value: state.somitiNetProfit,
      icon: CheckCircle,
      color: state.somitiNetProfit >= 0 ? 'emerald' : 'rose',
      categoryBn: 'চূড়ান্ত অডিটেড নিট ফল',
      categoryEn: 'Audited Final Surplus',
      highlight: true,
      noteBn: 'সমগ্র সমিতির কর-পূর্ববর্তী প্রকৃত উদ্বৃত্ত / নিট লাভ',
      noteEn: 'Bottom-line surplus available for member dividends',
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight font-display">
            {isBn ? 'সমিতির মূল আর্থিক অবস্থা (Core Financial State)' : 'Core Financial State Summary'}
          </h2>
          <p className="text-xs text-slate-500 font-bengali">
            {isBn
              ? '১৭টি পৃথক অডিটেড আর্থিক কার্ড — মূলধন, নগদ, দায় ও লাভ-ক্ষতির সম্পূর্ণ নির্ভুল চিত্র'
              : '17 distinct audited financial cards with zero double counting across capital and liabilities'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            {isBn ? 'ডাবল এন্ট্রি ব্যালেন্সড' : 'Double-Entry Verified'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {cards.map((card) => {
          const Icon = card.icon;
          const isHighlight = card.highlight;
          return (
            <div
              key={card.key}
              onClick={() => onCardClick?.(card.key)}
              className={`relative rounded-2xl p-5 border transition-all duration-200 cursor-pointer hover:shadow-md flex flex-col justify-between ${
                isHighlight
                  ? 'bg-gradient-to-br from-emerald-50 via-teal-50/40 to-white border-emerald-300 shadow-xs ring-1 ring-emerald-200/60'
                  : 'bg-white border-slate-200/90 hover:border-slate-300 shadow-2xs'
              }`}
            >
              <div>
                {/* Header line */}
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-bengali">
                    {isBn ? card.categoryBn : card.categoryEn}
                  </span>
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      card.color === 'emerald'
                        ? 'bg-emerald-100 text-emerald-700'
                        : card.color === 'blue'
                        ? 'bg-blue-100 text-blue-700'
                        : card.color === 'purple'
                        ? 'bg-purple-100 text-purple-700'
                        : card.color === 'rose'
                        ? 'bg-rose-100 text-rose-700'
                        : card.color === 'amber'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    <Icon className="w-5 h-5 stroke-[2]" />
                  </div>
                </div>

                {/* Card Title */}
                <h3 className="text-xs sm:text-sm font-bold text-slate-800 mt-2 font-bengali line-clamp-1">
                  {isBn ? card.titleBn : card.titleEn}
                </h3>

                {/* Amount Display */}
                <div className="mt-2.5">
                  <span className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight font-mono tabular-nums block">
                    {formatCurrency(card.value, lang)}
                  </span>
                </div>
              </div>

              {/* Explanatory Note Footer */}
              <div className="mt-4 pt-3 border-t border-slate-100/90 text-[11px] text-slate-500 font-bengali leading-relaxed">
                {isBn ? card.noteBn : card.noteEn}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
