import React, { useState, useMemo } from 'react';
import { Calculator, X, Calendar, ChevronDown, ChevronUp, FileText, CheckCircle2, Info } from 'lucide-react';
import { Language } from '../types';
import { calculateLoan, toBnNumber, LoanCalculationMethod } from '../services/loanCalculator';
import { formatCurrency } from '../utils/formatters';

interface LoanCalculatorModalProps {
  lang: Language;
  onClose: () => void;
  allowedInstallments?: number[];
  defaultMethod?: LoanCalculationMethod;
}

export const LoanCalculatorModal: React.FC<LoanCalculatorModalProps> = ({
  lang,
  onClose,
  allowedInstallments = [11, 11.5, 12, 12.5, 13, 15, 18, 24],
  defaultMethod = 'FLAT',
}) => {
  const isBn = lang === 'bn';

  const [principal, setPrincipal] = useState<number>(55000);
  const [profitRate, setProfitRate] = useState<number>(10);
  const [installmentCount, setInstallmentCount] = useState<number>(11.5);
  const [calculationMethod, setCalculationMethod] = useState<LoanCalculationMethod>(defaultMethod);
  const [firstInstallmentDate, setFirstInstallmentDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 30);
    return d.toISOString().split('T')[0];
  });
  const [showSchedule, setShowSchedule] = useState<boolean>(false);

  // Compute live calculations
  const calcResult = useMemo(() => {
    return calculateLoan({
      principal,
      profitRatePercent: profitRate,
      installmentCount,
      calculationMethod,
      firstInstallmentDate,
    });
  }, [principal, profitRate, installmentCount, calculationMethod, firstInstallmentDate]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto animate-fadeIn font-bengali">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-gradient-to-r from-blue-900 to-indigo-900 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20">
              <Calculator className="w-5 h-5 text-blue-200" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                {isBn ? 'BBL SOMITI লোন ক্যালকুলেটর' : 'BBL SOMITI Loan Calculator'}
              </h3>
              <p className="text-xs text-blue-200">
                {isBn
                  ? 'মাসিক কিস্তির সুনির্দিষ্ট ও সহজ হিসাব'
                  : 'Clean monthly installment calculation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white rounded-xl hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto">
          {/* Principal Input */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800">
                {isBn ? 'ঋণের আসল পরিমাণ (টাকা) *' : 'Loan Principal Amount (BDT) *'}
              </label>
              <span className="text-sm font-bold text-blue-700 font-mono">
                {formatCurrency(principal)}
              </span>
            </div>
            <input
              type="number"
              min={1000}
              step={1000}
              value={principal}
              onChange={(e) => setPrincipal(Math.max(0, Number(e.target.value)))}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-none"
            />
            {/* Quick Presets */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[20000, 30000, 50000, 55000, 100000, 200000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setPrincipal(amt)}
                  className={`px-2.5 py-1 text-xs rounded-lg border font-mono font-semibold transition-all ${
                    principal === amt
                      ? 'bg-blue-700 text-white border-blue-700'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ৳ {amt.toLocaleString()}
                </button>
              ))}
            </div>
          </div>

          {/* Rates & Calculation Method */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Profit Rate */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 block">
                {isBn ? 'বার্ষিক মুনাফার হার / সার্ভিস চার্জ (%)' : 'Annual Profit Rate (%)'}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={0}
                  max={30}
                  step={0.5}
                  value={profitRate}
                  onChange={(e) => setProfitRate(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-xs bg-slate-50 focus:bg-white outline-none"
                />
                <span className="text-xs font-bold text-slate-600 shrink-0">%</span>
              </div>
              <div className="flex flex-wrap gap-1 pt-0.5">
                {[0, 5, 8, 10, 12].map((rt) => (
                  <button
                    key={rt}
                    type="button"
                    onClick={() => setProfitRate(rt)}
                    className={`px-2 py-0.5 text-[11px] rounded-md border font-mono font-semibold ${
                      profitRate === rt
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {rt}%
                  </button>
                ))}
              </div>
            </div>

            {/* Calculation Method */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 block">
                {isBn ? 'গণনার পদ্ধতি' : 'Calculation Method'}
              </label>
              <select
                value={calculationMethod}
                onChange={(e) => setCalculationMethod(e.target.value as LoanCalculationMethod)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-slate-50 focus:bg-white outline-none"
              >
                <option value="FLAT">{isBn ? 'সরল মুনাফা (Flat Rate)' : 'Flat Rate'}</option>
                <option value="REDUCING">{isBn ? 'হ্রাসমান ব্যালেন্স (Reducing Balance EMI)' : 'Reducing Balance EMI'}</option>
              </select>
            </div>
          </div>

          {/* Installment Count Selection (11, 11.5, 12, 12.5, etc.) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800">
                {isBn ? 'কিস্তির সংখ্যা নির্বাচন করুন *' : 'Select Number of Installments *'}
              </label>
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200">
                {toBnNumber(installmentCount)} কিস্তি
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
              {allowedInstallments.map((inst) => {
                const isSelected = installmentCount === inst;
                return (
                  <button
                    key={inst}
                    type="button"
                    onClick={() => setInstallmentCount(inst)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-blue-700 text-white border-blue-700 shadow-sm ring-2 ring-blue-600/30'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="font-mono font-bold text-xs">{inst}</div>
                    <div className={`text-[9px] mt-0.5 ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                      কিস্তি
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* First Installment Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-800 block">
              {isBn ? 'প্রথম কিস্তির সম্ভাব্য তারিখ' : 'First Installment Expected Date'}
            </label>
            <div className="relative">
              <input
                type="date"
                value={firstInstallmentDate}
                onChange={(e) => setFirstInstallmentDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-semibold bg-slate-50 focus:bg-white outline-none"
              />
              <Calendar className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
            </div>
          </div>

          {/* Calculation Output Cards */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white space-y-4 shadow-md">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[11px] text-slate-300 block">মোট ঋণ (আসল)</span>
                <span className="text-sm font-bold font-mono text-white mt-1 block">
                  {formatCurrency(calcResult.principal)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-white/5 border border-white/10">
                <span className="text-[11px] text-emerald-300 block">মোট মুনাফা</span>
                <span className="text-sm font-bold font-mono text-emerald-400 mt-1 block">
                  + {formatCurrency(calcResult.totalProfitAmount)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-blue-500/20 border border-blue-400/30">
                <span className="text-[11px] text-blue-200 block">মোট পরিশোধযোগ্য</span>
                <span className="text-sm font-extrabold font-mono text-blue-300 mt-1 block">
                  {formatCurrency(calcResult.totalPayableAmount)}
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-indigo-500/20 border border-indigo-400/30">
                <span className="text-[11px] text-indigo-200 block">মোট কিস্তি সংখ্যা</span>
                <span className="text-sm font-bold font-mono text-indigo-300 mt-1 block">
                  {toBnNumber(installmentCount)} কিস্তি
                </span>
              </div>
            </div>

            {/* Installment Breakdown Highlight — Single Monthly Installment Option Only */}
            <div className="p-4 rounded-xl bg-white/10 border border-white/15 text-center">
              <span className="text-xs text-slate-300 block font-medium">
                {isBn ? 'মাসিক কিস্তি' : 'Monthly Installment'}
              </span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-300 mt-1">
                {formatCurrency(calcResult.regularInstallmentAmount)}
              </div>
            </div>
          </div>

          {/* Toggle Schedule Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden">
            <button
              type="button"
              onClick={() => setShowSchedule(!showSchedule)}
              className="w-full p-3.5 bg-slate-50 hover:bg-slate-100 flex items-center justify-between text-xs font-bold text-slate-800 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>পরিশোধের সম্পূর্ণ কিস্তি সময়সূচি ({toBnNumber(calcResult.schedule.length)}টি কিস্তি)</span>
              </div>
              {showSchedule ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
            </button>

            {showSchedule && (
              <div className="p-3 overflow-x-auto">
                <table className="w-full text-left text-xs font-bengali">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 text-[11px]">
                      <th className="py-2 px-2">ক্রম নং</th>
                      <th className="py-2 px-2">কিস্তির তারিখ</th>
                      <th className="py-2 px-2 text-right">আসল অংশ</th>
                      <th className="py-2 px-2 text-right">মুনাফা অংশ</th>
                      <th className="py-2 px-2 text-right">কিস্তির টাকা</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {calcResult.schedule.map((item) => (
                      <tr key={item.installmentNumber} className={item.isFractional ? 'bg-amber-50/60' : ''}>
                        <td className="py-2 px-2 font-bold text-slate-800 font-bengali">
                          {item.label}
                        </td>
                        <td className="py-2 px-2 text-slate-600">
                          {item.dueDate}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-700">
                          ৳ {item.principalAmount.toLocaleString()}
                        </td>
                        <td className="py-2 px-2 text-right text-emerald-700">
                          ৳ {item.profitAmount.toLocaleString()}
                        </td>
                        <td className="py-2 px-2 text-right font-bold text-blue-900">
                          ৳ {item.totalAmount.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500">
            * মোট পরিশোধযোগ্য অর্থ: <strong className="text-slate-800">{formatCurrency(calcResult.totalPayableAmount)}</strong>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-xs cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
