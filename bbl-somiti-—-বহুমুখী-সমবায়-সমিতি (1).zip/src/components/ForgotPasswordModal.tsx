import React, { useState } from 'react';
import { KeyRound, X, CheckCircle2, ArrowRight, Phone, ShieldCheck, Lock, Eye, EyeOff } from 'lucide-react';
import { Language } from '../types';

interface ForgotPasswordModalProps {
  lang: Language;
  onClose: () => void;
  onPasswordReset?: (newPassword: string) => void;
}

export const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({
  lang,
  onClose,
  onPasswordReset,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [identifier, setIdentifier] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const isBn = lang === 'bn';

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setError(isBn ? 'অনুগ্রহ করে আপনার মোবাইল নম্বর বা ইউজার আইডি দিন।' : 'Please enter your mobile or User ID.');
      return;
    }
    setError('');
    setStep(2);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim() || otp.length < 4) {
      setError(isBn ? 'অনুগ্রহ করে ৪ বা ৬ ডিজিটের ওটিপি কোড দিন।' : 'Please enter a valid 4-6 digit OTP.');
      return;
    }
    setError('');
    setStep(3);
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword) {
      setError(isBn ? 'অনুগ্রহ করে নতুন পাসওয়ার্ড দিন।' : 'Please enter a new password.');
      return;
    }
    if (newPassword.length < 6) {
      setError(isBn ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError(isBn ? 'উভয় পাসওয়ার্ড হুবহু মিলতে হবে।' : 'Passwords do not match.');
      return;
    }

    setError('');
    try {
      localStorage.setItem('bbl_admin_password', newPassword);
      if (identifier) {
        localStorage.setItem('bbl_admin_userid', identifier);
      }
    } catch {
      // ignore
    }
    onPasswordReset?.(newPassword);
    setStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shadow-xs">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'পাসওয়ার্ড পরিবর্তন ও সেট' : 'Change / Reset Password'}
              </h3>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn ? 'নতুন পাসওয়ার্ড দিয়ে নিরাপদে প্রবেশ করুন' : 'Set a new password to access your account'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-medium border border-rose-200 font-bengali">
              {error}
            </div>
          )}

          {/* STEP 1: Enter Identifier */}
          {step === 1 && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <p className="text-sm text-slate-600 font-bengali">
                {isBn
                  ? 'আপনার সমবায় অ্যাকাউন্টের সাথে নিবন্ধিত মোবাইল নম্বর অথবা ইউজার আইডি (যেমন: admin) দিন। আমরা ভেরিফিকেশন কোড পাঠাবো।'
                  : 'Enter your registered mobile number or User ID (e.g. admin). A verification code will be dispatched.'}
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'নিবন্ধিত মোবাইল / ইউজার আইডি' : 'Registered Mobile / User ID'}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder={isBn ? 'admin বা ০১XXXXXXXXX' : 'admin or 01XXXXXXXXX'}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all font-bengali cursor-pointer"
              >
                <span>{isBn ? 'ভেরিফিকেশন কোড পাঠান' : 'Send Verification Code'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 2: Enter OTP */}
          {step === 2 && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <p className="text-sm text-slate-600 font-bengali">
                {isBn
                  ? `${identifier} নম্বরে প্রেরিত ৬ ডিজিটের ওটিপি (OTP) কোডটি লিখুন:`
                  : `Enter the 6-digit verification OTP sent to ${identifier}:`}
              </p>

              <div>
                <input
                  type="text"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="• • • • • •"
                  className="w-full py-3 text-center text-xl font-bold tracking-widest rounded-xl border border-slate-300 focus:border-blue-600 focus:ring-2 focus:ring-blue-100 font-mono"
                />
                <p className="text-[11px] text-slate-500 font-bengali text-center mt-1.5">
                  {isBn ? '(টেস্ট ওটিপি: যেকোনো ৪-৬ ডিজিট লিখুন, যেমন: 123456)' : '(Demo OTP: enter any 4-6 digits, e.g. 123456)'}
                </p>
              </div>

              <div className="text-center">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs text-blue-600 hover:underline font-bengali cursor-pointer"
                >
                  {isBn ? 'ভুল নম্বর? পরিবর্তন করুন' : 'Wrong number? Edit'}
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all font-bengali cursor-pointer"
              >
                <span>{isBn ? 'যাচাই করুন ও পাসওয়ার্ড সেট করুন' : 'Verify & Set Password'}</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 3: Set New Password */}
          {step === 3 && (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <p className="text-xs sm:text-sm text-slate-600 font-bengali">
                {isBn
                  ? 'আপনার অ্যাকাউন্টের জন্য নতুন একটি শক্তিশালী পাসওয়ার্ড নির্ধারণ করুন:'
                  : 'Create a new secure password for your account:'}
              </p>

              {/* New Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'} *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder={isBn ? 'কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড' : 'Minimum 6 characters'}
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 font-bengali">
                  {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'} *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder={isBn ? 'পুনরায় পাসওয়ার্ড লিখুন' : 'Re-enter password'}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-700/20 transition-all font-bengali cursor-pointer"
              >
                <span>{isBn ? 'নতুন পাসওয়ার্ড সংরক্ষণ করুন' : 'Save New Password'}</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 4: Success Confirmation */}
          {step === 4 && (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-base font-bold text-slate-900 font-bengali">
                {isBn ? 'পাসওয়ার্ড সফলভাবে সেট হয়েছে!' : 'Password Set Successfully!'}
              </h4>
              <p className="text-xs text-slate-600 font-bengali leading-relaxed">
                {isBn
                  ? 'আপনার নতুন পাসওয়ার্ড সিস্টেমে সংরক্ষিত হয়েছে। এখন আপনি নতুন পাসওয়ার্ড দিয়ে নিরাপদে লগইন করতে পারবেন।'
                  : 'Your new password has been securely updated. You can now log in using your new credentials.'}
              </p>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-colors font-bengali cursor-pointer"
              >
                {isBn ? 'লগইন পেজে যান' : 'Proceed to Login'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
