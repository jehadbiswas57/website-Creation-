import React, { useState } from 'react';
import { SlidersHorizontal, X, Upload, RotateCcw, Check, Image as ImageIcon, Link as LinkIcon, Server } from 'lucide-react';
import { Language } from '../types';
import defaultLogoImg from '../assets/images/bbl_somiti_crest_logo_1792600597030.jpg';

interface LogoSettingsModalProps {
  lang: Language;
  currentLogoUrl: string | null;
  currentApiUrl: string;
  onSaveLogo: (url: string | null) => void;
  onSaveApiUrl: (url: string) => void;
  onClose: () => void;
}

export const LogoSettingsModal: React.FC<LogoSettingsModalProps> = ({
  lang,
  currentLogoUrl,
  currentApiUrl,
  onSaveLogo,
  onSaveApiUrl,
  onClose,
}) => {
  const isBn = lang === 'bn';
  const [logoPreview, setLogoPreview] = useState<string | null>(currentLogoUrl);
  const [urlInput, setUrlInput] = useState('');
  const [apiUrl, setApiUrl] = useState(currentApiUrl);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setLogoPreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyUrl = () => {
    if (urlInput.trim()) {
      setLogoPreview(urlInput.trim());
      setUrlInput('');
    }
  };

  const handleResetDefault = () => {
    setLogoPreview(null);
  };

  const handleSave = () => {
    onSaveLogo(logoPreview);
    onSaveApiUrl(apiUrl.trim());
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shadow-xs">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 font-display">
                {isBn ? 'সমিতির লোগো ও ব্যাকএন্ড সেটিংস' : 'Somiti Logo & Backend Settings'}
              </h3>
              <p className="text-xs text-slate-500 font-bengali">
                {isBn ? 'লোগো পরিবর্তন ও গুগল স্ক্রিপ্ট ব্যাকএন্ড কনফিগারেশন' : 'Change logo & configure Apps Script URL'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Logo Preview & Selection */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider font-bengali">
              {isBn ? 'বর্তমান সক্রিয় লোগো প্রিভিউ' : 'Active Logo Preview'}
            </label>
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200/70">
              <div className="w-20 h-20 rounded-2xl bg-white p-1 border border-emerald-300 shadow-md flex items-center justify-center overflow-hidden shrink-0">
                <img
                  src={logoPreview || defaultLogoImg}
                  alt="Logo Preview"
                  className="w-full h-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-xs text-slate-600 font-bengali space-y-1">
                <span className="font-bold text-slate-900 block">
                  {logoPreview ? (isBn ? 'কাস্টম লোগো নির্বাচিত' : 'Custom Logo Selected') : (isBn ? 'অফিসিয়াল গোল্ডেন-এমেরাল্ড সিল (ডিফল্ট)' : 'Official Golden-Emerald Crest (Default)')}
                </span>
                <p className="text-slate-500 leading-relaxed text-[11px]">
                  {isBn
                    ? 'আপনার ডিভাইস থেকে নতুন লোগো আপলোড করতে পারেন অথবা ডিফল্ট সিল ব্যবহার করতে পারেন।'
                    : 'You can upload an image from your computer or switch back to the official default crest.'}
                </p>
              </div>
            </div>

            {/* Actions for Logo */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <label className="cursor-pointer py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors">
                <Upload className="w-4 h-4 text-emerald-600" />
                <span className="font-bengali">{isBn ? 'লোগো ফাইল আপলোড' : 'Upload File'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={handleResetDefault}
                className="py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition-colors font-bengali"
              >
                <RotateCcw className="w-4 h-4 text-slate-500" />
                <span>{isBn ? 'ডিফল্ট সিমে ফিরুন' : 'Reset to Default'}</span>
              </button>
            </div>
          </div>

          {/* Backend API Configuration */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider font-bengali">
              {isBn ? 'Google Apps Script / Backend API URL' : 'Google Apps Script / Backend API URL'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Server className="w-4 h-4" />
              </div>
              <input
                type="url"
                value={apiUrl}
                onChange={(e) => setApiUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full pl-9 pr-3 py-2.5 text-xs rounded-xl border border-slate-300 font-mono text-slate-800 focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
              />
            </div>
            <p className="text-[11px] text-slate-500 font-bengali">
              {isBn
                ? 'আপনার Google Apps Script Web App URL এখানে দিলে লগইন রিকোয়েস্ট সরাসরি আপনার শিট বা ডাটাবেজে যাবে।'
                : 'Enter your live Google Apps Script deployment URL to route authentication requests directly.'}
            </p>
          </div>

          {/* Submit */}
          <button
            type="button"
            onClick={handleSave}
            className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 font-bengali"
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'সংরক্ষিত হয়েছে!' : 'Saved Successfully!'}</span>
              </>
            ) : (
              <span>{isBn ? 'পরিবর্তন সংরক্ষণ করুন' : 'Save Changes'}</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
