import React, { useState, useEffect } from 'react';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  LogIn,
  ShieldCheck,
  Globe,
  Loader2,
  AlertCircle,
  UserPlus
} from 'lucide-react';
import { Language } from '../types';
import { BrandingSettings } from '../types/dashboard';
import { getT } from '../translations';

interface LoginCardProps {
  lang: Language;
  branding?: BrandingSettings;
  onToggleLang: () => void;
  onOpenForgotPassword: () => void;
  onOpenRegister: () => void;
  onLoginAttempt: (credentials: { userId: string; password: string; rememberMe: boolean }) => void;
}

export const LoginCard: React.FC<LoginCardProps> = ({
  lang,
  branding,
  onToggleLang,
  onOpenForgotPassword,
  onOpenRegister,
  onLoginAttempt,
}) => {
  const t = getT(lang);

  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load remembered user ID if exists
  useEffect(() => {
    try {
      const savedUser = localStorage.getItem('bbl_somiti_saved_user');
      if (savedUser) {
        setUserId(savedUser);
        setRememberMe(true);
      }
    } catch {
      // localStorage may be disabled
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    const cleanUserId = userId.trim();
    if (!cleanUserId) {
      setErrorMessage(t.errorEmptyUserId);
      return;
    }
    if (!password) {
      setErrorMessage(t.errorEmptyPassword);
      return;
    }
    if (cleanUserId.length < 4) {
      setErrorMessage(t.errorInvalidLength);
      return;
    }

    // Remember me persistence
    try {
      if (rememberMe) {
        localStorage.setItem('bbl_somiti_saved_user', cleanUserId);
      } else {
        localStorage.removeItem('bbl_somiti_saved_user');
      }
    } catch {
      // ignore storage errors
    }

    // Trigger loading state and forward to parent
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginAttempt({ userId: cleanUserId, password, rememberMe });
    }, 600);
  };

  return (
    <div className="relative w-full max-w-lg mx-auto rounded-3xl bg-white p-6 sm:p-9 shadow-xl shadow-slate-900/10 border border-slate-200">
      {/* Top Header: Somiti Identity & Language Switcher */}
      <div className="pb-5 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-emerald-700 text-white font-extrabold flex items-center justify-center text-sm shadow-md shadow-emerald-700/20 shrink-0 overflow-hidden">
            {branding?.logoUrl ? (
              <img src={branding.logoUrl} alt="Logo" className="w-full h-full object-contain" />
            ) : (
              'BBL'
            )}
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900 tracking-tight font-display leading-tight">
              {branding?.englishName || 'BBL SOMITI'}
            </h1>
            <p className="text-xs font-semibold text-emerald-800 font-bengali">
              {branding?.banglaName || 'বহুমুখী সমবায় সমিতি লিঃ'}
            </p>
          </div>
        </div>

        {/* Language Toggle */}
        <button
          type="button"
          onClick={onToggleLang}
          className="group flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-semibold transition-all border border-slate-200 cursor-pointer"
          title="ভাষা পরিবর্তন করুন"
        >
          <Globe className="w-3.5 h-3.5 text-slate-600 group-hover:text-emerald-700" />
          <span className="font-bold text-emerald-800">
            {lang === 'bn' ? 'বাংলা' : 'EN'}
          </span>
        </button>
      </div>

      {/* Login Greeting */}
      <div className="mt-5 text-center sm:text-left">
        <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight font-display">
          {t.welcomeTitle}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1 font-bengali">
          {t.welcomeDesc}
        </p>
      </div>

      {/* Validation Error Banner */}
      {errorMessage && (
        <div className="mt-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <span className="font-bengali">{errorMessage}</span>
        </div>
      )}

      {/* Login Form */}
      <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Field 1: User ID / Mobile Number */}
          <div className="space-y-1.5">
            <label
              htmlFor="userId"
              className="block text-xs sm:text-sm font-bold text-slate-800 font-bengali"
            >
              {t.userIdLabel}
            </label>
            <div className="relative rounded-xl shadow-xs">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <User className="w-5 h-5" />
              </div>
              <input
                id="userId"
                type="text"
                autoComplete="username"
                value={userId}
                onChange={(e) => {
                  setUserId(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder={t.userIdPlaceholder}
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 text-sm placeholder:text-slate-400 focus:border-blue-600 focus:ring-3 focus:ring-blue-100 transition-all font-bengali"
              />
            </div>
          </div>

          {/* Field 2: Password */}
          <div className="space-y-1.5">
            <label
              htmlFor="password"
              className="block text-xs sm:text-sm font-bold text-slate-800 font-bengali"
            >
              {t.passwordLabel}
            </label>
            <div className="relative rounded-xl shadow-xs">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-5 h-5" />
              </div>
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder={t.passwordPlaceholder}
                className="w-full pl-11 pr-11 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 text-sm placeholder:text-slate-400 focus:border-blue-600 focus:ring-3 focus:ring-blue-100 transition-all font-bengali"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between pt-1 text-xs sm:text-sm">
            <label className="flex items-center gap-2 cursor-pointer select-none text-slate-700 font-medium font-bengali">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
              />
              <span>{t.rememberMe}</span>
            </label>

            <button
              type="button"
              onClick={onOpenForgotPassword}
              className="text-xs sm:text-sm font-bold text-blue-700 hover:text-blue-800 hover:underline transition-colors font-bengali"
            >
              {t.forgotPassword}
            </button>
          </div>

          {/* Big Blue Login Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full relative py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-800 hover:via-blue-700 hover:to-indigo-800 text-white font-bold text-base shadow-lg shadow-blue-700/25 active:scale-[0.99] transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-75 disabled:cursor-not-allowed cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="font-bengali">{t.loggingIn}</span>
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  <span className="font-bengali tracking-wide">{t.loginBtn}</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Divider with "অথবা" */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-3 text-slate-500 font-semibold font-bengali">
              {t.orDivider}
            </span>
          </div>
        </div>

        {/* Green-Bordered Button: Create New Account */}
        <button
          type="button"
          onClick={onOpenRegister}
          className="w-full py-3.5 px-6 rounded-xl border-2 border-emerald-600 hover:border-emerald-700 text-emerald-800 hover:bg-emerald-50/80 font-bold text-sm sm:text-base transition-all duration-200 flex items-center justify-center gap-2 active:scale-[0.99] cursor-pointer"
        >
          <UserPlus className="w-5 h-5 text-emerald-700" />
          <span className="font-bengali">{t.createAccountBtn}</span>
        </button>

        {/* Credentials & Password Guidance Callout */}
        <div className="mt-4 p-3 rounded-2xl bg-blue-50/80 border border-blue-200 text-xs text-blue-950 font-bengali space-y-1">
          <div className="flex items-center justify-between font-bold">
            <span className="flex items-center gap-1.5 text-blue-900">
              <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              <span>{lang === 'bn' ? 'এডমিন লগইন তথ্য:' : 'Admin Access:'}</span>
            </span>
            <button
              type="button"
              onClick={onOpenForgotPassword}
              className="text-blue-700 hover:underline text-[11px] cursor-pointer"
            >
              {lang === 'bn' ? 'পাসওয়ার্ড পরিবর্তন' : 'Change Password'}
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-blue-900/90 font-mono">
            <span>ইউজার আইডি: <strong>admin</strong></span>
            <span>·</span>
            <span>পাসওয়ার্ড: <strong>admin123</strong></span>
          </div>
          <p className="text-[10px] text-slate-500 font-bengali">
            {lang === 'bn'
              ? 'এডমিন (admin / admin123) অথবা সমিতির সম্মানিত সদস্যগণ তাদের নির্ধারিত ইউজার আইডি ও পাসওয়ার্ড দিয়ে লগইন করতে পারেন।'
              : 'Admin (admin / admin123) or members can log in with their assigned User ID & Password.'}
          </p>
        </div>

      {/* Security Message Box at bottom of card */}
      <div className="mt-8 pt-5 border-t border-slate-100 flex items-center gap-3 bg-slate-50/80 rounded-2xl p-3.5 border border-slate-200/60">
        <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
          <ShieldCheck className="w-5 h-5 stroke-[2.2]" />
        </div>
        <div>
          <h4 className="text-xs sm:text-sm font-bold text-slate-800 font-bengali">
            {t.securityTitle}
          </h4>
          <p className="text-xs text-slate-500 font-bengali leading-relaxed">
            {t.securityDesc}
          </p>
        </div>
      </div>
    </div>
  );
};
