import React, { useState, useMemo } from 'react';
import {
  User,
  LogOut,
  CreditCard,
  PiggyBank,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowRight,
  FileText,
  Printer,
  ShieldCheck,
  Send,
  Plus,
  X,
  Loader2,
  AlertCircle,
  HelpCircle,
  Calendar,
  Phone,
  Wallet,
  FileCheck,
  Download,
  Building,
} from 'lucide-react';
import { Language } from '../../types';
import { MemberRecord, MemberLoan, PaymentRequest, ProfileUpdateRequest, OfficialReceipt } from '../../types/member';
import { memberService } from '../../services/memberService';
import { formatCurrency, formatNumber } from '../../utils/formatters';
import { ReceiptModal } from '../common/ReceiptModal';

interface MemberDashboardLayoutProps {
  memberId: string;
  lang: Language;
  onLogout: () => void;
  somitiNameBn?: string;
  somitiNameEn?: string;
  logoUrl?: string | null;
}

export const MemberDashboardLayout: React.FC<MemberDashboardLayoutProps> = ({
  memberId,
  lang,
  onLogout,
  somitiNameBn = 'বহুমুখী সমবায় সমিতি লিঃ',
  somitiNameEn = 'BBL SOMITI',
  logoUrl,
}) => {
  const isBn = lang === 'bn';

  // Member state loaded strictly for this member
  const [member, setMember] = useState<MemberRecord | undefined>(() => memberService.getMemberById(memberId));
  const [loans, setLoans] = useState<MemberLoan[]>(() => memberService.getLoansByMemberId(memberId));
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>(() => memberService.getPaymentRequestsByMember(memberId));
  const [profileRequests, setProfileRequests] = useState<ProfileUpdateRequest[]>(() => memberService.getProfileRequestsByMember(memberId));
  const [receipts, setReceipts] = useState<OfficialReceipt[]>(() => memberService.getReceiptsByMember(memberId));

  // Active view tab in Member Portal
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'PAYMENTS' | 'LOANS' | 'PROFILE_REQUEST' | 'RECEIPTS'>('OVERVIEW');

  // Modals
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showProfileUpdateModal, setShowProfileUpdateModal] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<OfficialReceipt | null>(null);

  // Payment Form State
  const [payType, setPayType] = useState<'LOAN_INSTALLMENT' | 'SAVINGS_DEPOSIT'>('LOAN_INSTALLMENT');
  const [payAmount, setPayAmount] = useState<number>(() => member?.nextInstallmentAmount || 1000);
  const [payMethod, setPayMethod] = useState<'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK' | 'CASH'>('BKASH');
  const [payTrxRef, setPayTrxRef] = useState('');
  const [payEvidenceUrl, setPayEvidenceUrl] = useState('');
  const [isSubmittingPay, setIsSubmittingPay] = useState(false);
  const [payMessage, setPayMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Loan Application State
  const [reqLoanAmount, setReqLoanAmount] = useState<number>(20000);
  const [reqLoanTenure, setReqLoanTenure] = useState<number>(12);
  const [reqLoanPurpose, setReqLoanPurpose] = useState<string>('ক্ষুদ্র ব্যবসা সম্প্রসারণ');
  const [isSubmittingLoan, setIsSubmittingLoan] = useState(false);
  const [loanAppMessage, setLoanAppMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Profile Update Request State
  const [updateType, setUpdateType] = useState<'PHOTO' | 'CONTACT_INFO' | 'NOMINEE' | 'NID'>('CONTACT_INFO');
  const [updateProposed, setUpdateProposed] = useState('');
  const [updateDocUrl, setUpdateDocUrl] = useState('');
  const [isSubmittingProfileReq, setIsSubmittingProfileReq] = useState(false);
  const [profileReqMessage, setProfileReqMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const refreshData = () => {
    setMember(memberService.getMemberById(memberId));
    setLoans(memberService.getLoansByMemberId(memberId));
    setPaymentRequests(memberService.getPaymentRequestsByMember(memberId));
    setProfileRequests(memberService.getProfileRequestsByMember(memberId));
    setReceipts(memberService.getReceiptsByMember(memberId));
  };

  const eligibility = useMemo(() => {
    return memberService.checkLoanEligibility(memberId);
  }, [memberId, member]);

  if (!member) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-100 font-bengali">
        <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center space-y-4 max-w-md">
          <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
          <h3 className="font-bold text-slate-900 text-base">সদস্য একাউন্ট খুঁজে পাওয়া যায়নি</h3>
          <button
            onClick={onLogout}
            className="px-5 py-2.5 rounded-xl bg-blue-700 text-white font-bold text-xs"
          >
            লগইন পেজে ফিরে যান
          </button>
        </div>
      </div>
    );
  }

  // Handle Installment Payment Submit with Idempotency Protection
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (payAmount <= 0) {
      setPayMessage({ type: 'error', text: 'সঠিক টাকার পরিমাণ লিখুন।' });
      return;
    }

    setIsSubmittingPay(true);
    setPayMessage(null);

    // Client-side unique idempotency key
    const idempotencyKey = `MEM-PAY-${member.id}-${Date.now()}-${Math.floor(Math.random() * 89999 + 10000)}`;

    const res = memberService.submitPaymentRequest({
      idempotencyKey,
      memberId: member.id,
      memberName: member.fullNameBn,
      memberUserId: member.userId,
      loanId: member.activeLoanId,
      type: payType,
      installmentNumber: (loans[0]?.installmentsPaidCount || 0) + 1,
      dueAmount: member.nextInstallmentAmount || payAmount,
      requestedAmount: payAmount,
      paymentMethod: payMethod,
      transactionReference: payTrxRef,
      paymentEvidenceUrl: payEvidenceUrl || undefined,
    });

    setIsSubmittingPay(false);
    if (res.success) {
      setPayMessage({ type: 'success', text: res.message });
      refreshData();
      setTimeout(() => {
        setShowPaymentModal(false);
        setPayMessage(null);
        setPayTrxRef('');
        setPayEvidenceUrl('');
      }, 1500);
    } else {
      setPayMessage({ type: 'error', text: res.message });
    }
  };

  // Handle Loan Application Submit
  const handleLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eligibility.isEligible) {
      setLoanAppMessage({
        type: 'error',
        text: `ঋণ আবেদনের পূর্বে বকেয়া ফি পরিশোধ করুন: ${eligibility.missingReasons.join(', ')}`,
      });
      return;
    }

    setIsSubmittingLoan(true);
    setLoanAppMessage(null);

    const res = memberService.applyLoan(member.id, reqLoanAmount, reqLoanTenure, reqLoanPurpose);
    setIsSubmittingLoan(false);

    if (res.success) {
      setLoanAppMessage({ type: 'success', text: res.message });
      refreshData();
      setTimeout(() => {
        setShowLoanModal(false);
        setLoanAppMessage(null);
      }, 1500);
    } else {
      setLoanAppMessage({ type: 'error', text: res.message });
    }
  };

  // Handle Profile Update Request Submit
  const handleProfileUpdateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateProposed.trim()) {
      setProfileReqMessage({ type: 'error', text: 'প্রস্তাবিত সংশোধিত তথ্য পূরণ করুন।' });
      return;
    }

    setIsSubmittingProfileReq(true);
    setProfileReqMessage(null);

    let oldVal = '';
    if (updateType === 'PHOTO') oldVal = member.photoUrl || 'ছবি নেই';
    else if (updateType === 'CONTACT_INFO') oldVal = `${member.mobileNumber} · ${member.address}`;
    else if (updateType === 'NID') oldVal = member.nidNumber || 'তথ্য নেই';
    else if (updateType === 'NOMINEE') oldVal = member.nominee?.name || 'তথ্য নেই';

    const res = memberService.submitProfileUpdateRequest({
      memberId: member.id,
      memberName: member.fullNameBn,
      requestType: updateType,
      oldValue: oldVal,
      proposedValue: updateProposed,
      supportingDocumentUrl: updateDocUrl || undefined,
    });

    setIsSubmittingProfileReq(false);
    if (res.success) {
      setProfileReqMessage({ type: 'success', text: res.message });
      refreshData();
      setTimeout(() => {
        setShowProfileUpdateModal(false);
        setProfileReqMessage(null);
        setUpdateProposed('');
        setUpdateDocUrl('');
      }, 1500);
    } else {
      setProfileReqMessage({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8FC] text-slate-900 font-sans antialiased font-bengali">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-700 text-white font-extrabold flex items-center justify-center text-sm shadow-sm overflow-hidden">
              {logoUrl ? <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" /> : 'BBL'}
            </div>
            <div>
              <h1 className="text-sm sm:text-base font-extrabold text-slate-900 leading-tight">
                {somitiNameBn}
              </h1>
              <p className="text-[10px] text-emerald-800 font-mono font-bold">
                {isBn ? 'সদস্য সেলফ-সার্ভিস পোর্টাল' : 'Member Portal'} · {member.id}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-600">
              <span className="font-bold text-slate-800">{member.fullNameBn}</span>
              <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 font-mono text-[10px] font-bold border border-emerald-200">
                {member.userId}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="px-3 py-1.5 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-700 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{isBn ? 'লগআউট' : 'Logout'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Profile Header Hero Card */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-4 sm:gap-5">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-slate-100 overflow-hidden shrink-0 flex items-center justify-center font-bold text-slate-600 text-xl border-2 border-slate-200 shadow-inner">
                {member.photoUrl ? (
                  <img src={member.photoUrl} alt={member.fullNameBn} className="w-full h-full object-cover" />
                ) : (
                  member.fullNameBn.slice(0, 1)
                )}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display">
                    {member.fullNameBn}
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-100 text-emerald-800">
                    {member.status}
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-mono">
                  {member.fullNameEn} · <span className="text-blue-700 font-bold">{member.id}</span>
                </p>
                <p className="text-xs text-slate-600 flex items-center gap-2 pt-0.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono">{member.mobileNumber}</span>
                  <span className="text-slate-300">·</span>
                  <span>{isBn ? 'ভর্তি:' : 'Joined:'} {member.admissionDate}</span>
                </p>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer transition-all active:scale-95"
              >
                <Send className="w-4 h-4" />
                <span>{isBn ? 'কিস্তি জমার অনুরোধ' : 'Pay Installment'}</span>
              </button>
              <button
                onClick={() => setShowLoanModal(true)}
                className="px-4 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center gap-2 shadow-sm cursor-pointer transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'ঋণ আবেদন' : 'Apply Loan'}</span>
              </button>
              <button
                onClick={() => setShowProfileUpdateModal(true)}
                className="px-3.5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>{isBn ? 'তথ্য সংশোধন' : 'Edit Request'}</span>
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-1 overflow-x-auto border-t border-slate-200 pt-4 scrollbar-none">
            {[
              { id: 'OVERVIEW', label: isBn ? 'আর্থিক বিবরণী' : 'Financial Overview' },
              { id: 'PAYMENTS', label: isBn ? `পেমেন্ট অনুরোধ (${paymentRequests.length})` : `Payment Requests (${paymentRequests.length})` },
              { id: 'LOANS', label: isBn ? `আমার ঋণ (${loans.length})` : `My Loans (${loans.length})` },
              { id: 'RECEIPTS', label: isBn ? `আমার রশিদ (${receipts.length})` : `Receipts (${receipts.length})` },
              { id: 'PROFILE_REQUEST', label: isBn ? `সংশোধন আবেদন (${profileRequests.length})` : `Update Requests (${profileRequests.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* TAB 1: FINANCIAL OVERVIEW */}
        {activeTab === 'OVERVIEW' && (
          <div className="space-y-6">
            {/* Financial Status Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Card 1: Loan Outstanding */}
              <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-bold text-amber-900">
                    {isBn ? 'বকেয়া ঋণ মূলধন' : 'Outstanding Loan'}
                  </span>
                  <CreditCard className="w-4 h-4 text-amber-600" />
                </div>
                <div className="text-2xl font-extrabold text-amber-900 font-mono">
                  {formatCurrency(member.currentLoanOutstanding, lang)}
                </div>
                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex justify-between">
                  <span>পরবর্তী কিস্তি:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {member.nextInstallmentDate || '—'}
                  </span>
                </div>
              </div>

              {/* Card 2: Savings Balance */}
              <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-bold text-emerald-800">
                    {isBn ? 'বর্তমান সঞ্চয় স্থিতি' : 'Savings Balance'}
                  </span>
                  <PiggyBank className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-extrabold text-emerald-800 font-mono">
                  {formatCurrency(member.currentSavingsBalance, lang)}
                </div>
                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex justify-between">
                  <span>মোট সঞ্চয় জমা:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {formatCurrency(member.totalSavingsDeposits, lang)}
                  </span>
                </div>
              </div>

              {/* Card 3: Total Repaid */}
              <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-bold text-blue-900">
                    {isBn ? 'মোট পরিশোধিত ঋণ' : 'Total Repaid'}
                  </span>
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                </div>
                <div className="text-2xl font-extrabold text-blue-900 font-mono">
                  {formatCurrency(member.totalLoanPrincipalPaid + member.totalLoanProfitPaid, lang)}
                </div>
                <div className="text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex justify-between">
                  <span>মোট ঋণ ছিল:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {formatCurrency(member.totalLoanDisbursedAmount, lang)}
                  </span>
                </div>
              </div>

              {/* Card 4: Loan Eligibility Status */}
              <div className="p-5 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="text-xs font-bold text-purple-900">
                    {isBn ? 'ঋণ আবেদনের যোগ্যতা' : 'Loan Eligibility'}
                  </span>
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                </div>
                <div className="text-base font-extrabold font-mono flex items-center gap-1.5">
                  {eligibility.isEligible ? (
                    <span className="text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-5 h-5" /> {isBn ? 'যোগ্য' : 'Eligible'}
                    </span>
                  ) : (
                    <span className="text-amber-700 flex items-center gap-1 text-xs">
                      <AlertTriangle className="w-4 h-4" /> {isBn ? 'বকেয়া পূরণ আবশ্যক' : 'Dues Pending'}
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                  {eligibility.isEligible
                    ? 'ভর্তি ফি, ইনস্যুরেন্স ও প্রাথমিক সঞ্চয় পরিশোধিত'
                    : eligibility.missingReasons.join(' · ')}
                </div>
              </div>
            </div>

            {/* Admission, Insurance & Mandatory Savings Details */}
            <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-2xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-3">
                {isBn ? 'বাধ্যতামূলক ফি ও আমানত স্থিতি' : 'Mandatory Reserves & Fees'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-700">ভর্তি ফি</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        member.admissionFeeStatus === 'PAID'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {member.admissionFeeStatus}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>জমা: ৳{member.admissionFeePaid}</span>
                    <span>নির্ধারিত: ৳{member.admissionFeeRequired}</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-700">ইনস্যুরেন্স ফান্ড</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        member.insuranceStatus === 'PAID'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {member.insuranceStatus}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>জমা: ৳{member.insuranceFeePaid}</span>
                    <span>নির্ধারিত: ৳{member.insuranceFeeRequired}</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-slate-700">প্রাথমিক সঞ্চয়</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        member.initialSavingsStatus === 'PAID'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {member.initialSavingsStatus}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>জমা: ৳{member.initialSavingsPaid}</span>
                    <span>নির্ধারিত: ৳{member.initialSavingsRequired}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PAYMENT REQUESTS */}
        {activeTab === 'PAYMENTS' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">
                {isBn ? 'আমার প্রেরিত কিস্তি ও জমার অনুরোধ' : 'Submitted Payment Requests'}
              </h3>
              <button
                onClick={() => setShowPaymentModal(true)}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ নতুন জমার অনুরোধ</span>
              </button>
            </div>

            {paymentRequests.length === 0 ? (
              <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center text-xs text-slate-400">
                কোনো পেমেন্ট অনুরোধ পাঠানো হয়নি।
              </div>
            ) : (
              <div className="rounded-3xl bg-white border border-slate-200 overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono">
                      <th className="py-3 px-4">Request ID</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Method</th>
                      <th className="py-3 px-4 text-right">Amount</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {paymentRequests.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="py-3 px-4 font-mono font-bold text-blue-700">{p.id}</td>
                        <td className="py-3 px-4 font-semibold text-slate-800">
                          {p.type === 'LOAN_INSTALLMENT' ? 'ঋণ কিস্তি' : 'সঞ্চয় জমা'}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-700">{p.paymentMethod}</td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(p.requestedAmount, lang)}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-500">{p.submittedDate}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                              p.status === 'PENDING'
                                ? 'bg-amber-100 text-amber-800'
                                : p.status === 'APPROVED'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono">
                          {p.generatedReceiptNumber ? (
                            <button
                              onClick={() => {
                                const r = memberService.getReceiptByNumber(p.generatedReceiptNumber!);
                                if (r) setSelectedReceipt(r);
                              }}
                              className="text-blue-700 hover:underline font-bold"
                            >
                              {p.generatedReceiptNumber}
                            </button>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: MY LOANS */}
        {activeTab === 'LOANS' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">আমার ঋণ বিবরণী</h3>
              <button
                onClick={() => setShowLoanModal(true)}
                className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ ঋণ আবেদন</span>
              </button>
            </div>

            {loans.length === 0 ? (
              <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center text-xs text-slate-400">
                বর্তমানে কোনো ঋণ ফাইল নেই।
              </div>
            ) : (
              <div className="space-y-4">
                {loans.map((l) => (
                  <div key={l.id} className="p-5 rounded-3xl bg-white border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-mono font-bold text-blue-700">{l.id}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          l.loanStatus === 'ACTIVE'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {l.loanStatus}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div>
                        <span className="text-slate-400 block">অনুমোদিত পরিমাণ:</span>
                        <span className="font-mono font-bold">৳{l.approvedAmount}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">বকেয়া ব্যালেন্স:</span>
                        <span className="font-mono font-bold text-amber-900">৳{l.outstandingPrincipal}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">কিস্তি সংখ্যা:</span>
                        <span className="font-mono font-bold">{l.installmentsPaidCount}/{l.totalInstallments}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">পরবর্তী কিস্তি:</span>
                        <span className="font-mono font-bold text-blue-700">{l.nextInstallmentDueDate || '—'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: MY RECEIPTS */}
        {activeTab === 'RECEIPTS' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900">অনুমোদিত মানি রিসিট ও ভাউচার</h3>
            {receipts.length === 0 ? (
              <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center text-xs text-slate-400">
                কোনো অনুমোদিত রিসিট পাওয়া যায়নি।
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {receipts.map((r) => (
                  <div key={r.receiptNumber} className="p-5 rounded-3xl bg-white border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-mono font-bold text-blue-700 text-xs">{r.receiptNumber}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{r.paymentDate}</span>
                    </div>
                    <div className="text-xs space-y-1">
                      <span className="font-bold text-slate-800 block">
                        {r.type === 'LOAN_INSTALLMENT' ? 'ঋণ কিস্তি আদায়' : 'সঞ্চয় আমানত'}
                      </span>
                      <span className="font-mono font-bold text-emerald-800 text-base block">
                        ৳{r.amount}
                      </span>
                      <span className="text-slate-500 text-[11px] block">পদ্ধতি: {r.paymentMethod}</span>
                    </div>
                    <button
                      onClick={() => setSelectedReceipt(r)}
                      className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>রশিদ দেখুন ও প্রিন্ট করুন</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: PROFILE UPDATE REQUESTS */}
        {activeTab === 'PROFILE_REQUEST' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900">প্রোফাইল সংশোধন আবেদনসমূহ</h3>
              <button
                onClick={() => setShowProfileUpdateModal(true)}
                className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ নতুন সংশোধন আবেদন</span>
              </button>
            </div>

            {profileRequests.length === 0 ? (
              <div className="p-8 rounded-3xl bg-white border border-slate-200 text-center text-xs text-slate-400">
                কোনো সংশোধন আবেদন পাঠানো হয়নি।
              </div>
            ) : (
              <div className="space-y-3">
                {profileRequests.map((req) => (
                  <div key={req.id} className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-blue-700">{req.id}</span>
                        <span className="font-bold text-slate-800">{req.requestType}</span>
                        <span className="text-slate-400 font-mono text-[11px]">{req.requestDate}</span>
                      </div>
                      <p className="text-slate-600">
                        প্রস্তাবিত মান: <strong className="text-slate-900">{req.proposedValue}</strong>
                      </p>
                    </div>
                    <div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                          req.status === 'PENDING'
                            ? 'bg-amber-100 text-amber-800'
                            : req.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* MODAL 1: SUBMIT PAYMENT REQUEST */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">কিস্তি বা সঞ্চয় জমার অনুরোধ</h3>
              <button onClick={() => setShowPaymentModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handlePaymentSubmit} className="p-6 space-y-4 text-xs font-bengali">
              {payMessage && (
                <div
                  className={`p-3 rounded-xl ${
                    payMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                  }`}
                >
                  {payMessage.text}
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">জমার খাত *</label>
                <select
                  value={payType}
                  onChange={(e) => setPayType(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="LOAN_INSTALLMENT">ঋণ কিস্তি পরিশোধ</option>
                  <option value="SAVINGS_DEPOSIT">সঞ্চয় আমানত জমা</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">টাকার পরিমাণ *</label>
                <input
                  type="number"
                  required
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">পেমেন্ট মেথড *</label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="BKASH">বিকাশ (bKash)</option>
                  <option value="NAGAD">নগদ (Nagad)</option>
                  <option value="ROCKET">রকেট (Rocket)</option>
                  <option value="BANK">ব্যাংক ট্রান্সফার (Bank)</option>
                  <option value="CASH">ক্যাশ (অফিসে নগদ জমা)</option>
                </select>
              </div>

              {payMethod !== 'CASH' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    ট্রানজেকশন / রেফারেন্স আইডি (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={payTrxRef}
                    onChange={(e) => setPayTrxRef(e.target.value)}
                    placeholder="উদাঃ 9A8B7C6D"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">পেমেন্ট স্লিপ / রসিদ লিঙ্ক (ঐচ্ছিক)</label>
                <input
                  type="url"
                  value={payEvidenceUrl}
                  onChange={(e) => setPayEvidenceUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                />
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
                পেমেন্ট অনুরোধ পাঠানোর পর এডমিন যাচাই করবেন। অনুমোদনের পরেই লেজারে পোস্ট হবে এবং রশিদ তৈরি হবে।
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPay}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold flex items-center gap-1.5 cursor-pointer disabled:opacity-75"
                >
                  {isSubmittingPay && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>অনুরোধ জমা দিন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: APPLY LOAN */}
      {showLoanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">ঋণের আবেদন</h3>
              <button onClick={() => setShowLoanModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleLoanSubmit} className="p-6 space-y-4 text-xs">
              {loanAppMessage && (
                <div
                  className={`p-3 rounded-xl ${
                    loanAppMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                  }`}
                >
                  {loanAppMessage.text}
                </div>
              )}

              {!eligibility.isEligible && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>ঋণ আবেদনের যোগ্যতা অপূর্ণ</span>
                  </div>
                  <p className="text-[11px] text-rose-800 leading-relaxed">
                    সমিতির নীতিমালা অনুযায়ী ঋণ আবেদন জমা দেওয়ার পূর্বে নিচের বকেয়া পরিশোধ করতে হবে:
                  </p>
                  <ul className="list-disc list-inside font-bold text-[11px] text-rose-900 pt-1">
                    {eligibility.missingReasons.map((m, idx) => (
                      <li key={idx}>{m}</li>
                    ))}
                  </ul>
                  <p className="text-[11px] text-rose-700 pt-1 font-mono">
                    মোট প্রদেয় বকেয়া: ৳{eligibility.totalDueAmount}
                  </p>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">আবেদনকৃত ঋণের পরিমাণ (টাকা) *</label>
                <input
                  type="number"
                  required
                  disabled={!eligibility.isEligible}
                  value={reqLoanAmount}
                  onChange={(e) => setReqLoanAmount(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold text-sm disabled:bg-slate-100"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">মেয়াদ (মাস) *</label>
                <select
                  disabled={!eligibility.isEligible}
                  value={reqLoanTenure}
                  onChange={(e) => setReqLoanTenure(Number(e.target.value))}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white disabled:bg-slate-100"
                >
                  <option value={6}>৬ মাস</option>
                  <option value={12}>১২ মাস (১ বছর)</option>
                  <option value={24}>২৪ মাস (২ বছর)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">ঋণের উদ্দেশ্য *</label>
                <input
                  type="text"
                  required
                  disabled={!eligibility.isEligible}
                  value={reqLoanPurpose}
                  onChange={(e) => setReqLoanPurpose(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 disabled:bg-slate-100"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowLoanModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={!eligibility.isEligible || isSubmittingLoan}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-bold cursor-pointer"
                >
                  {isSubmittingLoan ? 'দাখিল হচ্ছে...' : 'আবেদন দাখিল করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: PROFILE UPDATE REQUEST */}
      {showProfileUpdateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn font-bengali">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">প্রোফাইল তথ্য সংশোধনের আবেদন</h3>
              <button onClick={() => setShowProfileUpdateModal(false)} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleProfileUpdateSubmit} className="p-6 space-y-4 text-xs">
              {profileReqMessage && (
                <div
                  className={`p-3 rounded-xl ${
                    profileReqMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-800'
                  }`}
                >
                  {profileReqMessage.text}
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">কোন তথ্য পরিবর্তন করতে চান? *</label>
                <select
                  value={updateType}
                  onChange={(e) => setUpdateType(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 bg-white"
                >
                  <option value="CONTACT_INFO">মোবাইল বা ঠিকানা পরিবর্তন</option>
                  <option value="PHOTO">প্রোফাইল ছবি পরিবর্তন</option>
                  <option value="NID">জাতীয় পরিচয়পত্র নম্বর সংশোধন</option>
                  <option value="NOMINEE">নমিনী সংক্রান্ত পরিবর্তন</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">প্রস্তাবিত নতুন তথ্য *</label>
                <textarea
                  rows={2}
                  required
                  value={updateProposed}
                  onChange={(e) => setUpdateProposed(e.target.value)}
                  placeholder="আপনার নতুন সঠিক তথ্যটি লিখুন"
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">সাপোর্টিং ডকুমেন্ট লিঙ্ক (ঐচ্ছিক)</label>
                <input
                  type="url"
                  value={updateDocUrl}
                  onChange={(e) => setUpdateDocUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-mono"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowProfileUpdateModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingProfileReq}
                  className="px-5 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold"
                >
                  আবেদন জমা দিন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RECEIPT MODAL */}
      {selectedReceipt && (
        <ReceiptModal
          receipt={selectedReceipt}
          lang={lang}
          onClose={() => setSelectedReceipt(null)}
        />
      )}
    </div>
  );
};
