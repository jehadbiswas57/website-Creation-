export type Language = 'bn' | 'en';

export type ActiveModal = 
  | null 
  | 'forgot_password' 
  | 'register' 
  | 'about' 
  | 'rules' 
  | 'calculator' 
  | 'contact' 
  | 'backend_info' 
  | 'logo_settings';

export interface SomitiSettings {
  logoUrl: string;
  somitiNameBn: string;
  somitiNameEn: string;
  backendApiUrl: string;
}
