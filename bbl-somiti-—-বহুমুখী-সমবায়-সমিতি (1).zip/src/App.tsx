import React, { useState, useEffect } from 'react';
import { Language, ActiveModal } from './types';
import {
  BrandingSettings,
  FinancialFormulaConfig,
  FinancialState,
  TransactionRecord,
  ApprovalRequest,
  DataMode,
} from './types/dashboard';
import { DEFAULT_BRANDING, DEFAULT_FORMULA_CONFIG } from './data/defaultSettings';
import {
  EMPTY_FINANCIAL_STATE,
  AUDITED_FINANCIAL_STATE,
  INITIAL_TRANSACTIONS,
  INITIAL_APPROVALS,
} from './data/mockFinancialData';

import { LoginCard } from './components/LoginCard';
import { Footer } from './components/Footer';
import { ForgotPasswordModal } from './components/ForgotPasswordModal';
import { RegisterModal } from './components/RegisterModal';
import { AboutModal } from './components/AboutModal';
import { RulesModal } from './components/RulesModal';
import { LoanCalculatorModal } from './components/LoanCalculatorModal';
import { ContactModal } from './components/ContactModal';
import { BackendIntegrationModal } from './components/BackendIntegrationModal';
import { LogoSettingsModal } from './components/LogoSettingsModal';

import { DashboardLayout } from './components/dashboard/DashboardLayout';
import { MemberDashboardLayout } from './components/member/MemberDashboardLayout';
import { memberService } from './services/memberService';
import { ArrowLeftRight, User, ShieldCheck } from 'lucide-react';

export default function App() {
  // Navigation View State: 'DASHBOARD' | 'LOGIN' | 'MEMBER_PORTAL'
  const [currentView, setCurrentView] = useState<'DASHBOARD' | 'LOGIN' | 'MEMBER_PORTAL'>('DASHBOARD');
  const [loggedMemberId, setLoggedMemberId] = useState<string | null>(null);

  // Shared Core State
  const [lang, setLang] = useState<Language>('bn');
  const [branding, setBranding] = useState<BrandingSettings>(DEFAULT_BRANDING);
  const [formulaConfig, setFormulaConfig] = useState<FinancialFormulaConfig>(DEFAULT_FORMULA_CONFIG);
  const [dataMode, setDataMode] = useState<DataMode>('empty');
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [backendApiUrl, setBackendApiUrl] = useState<string>('');
  const [submittedUserId, setSubmittedUserId] = useState<string>('');

  // Financial Data State — Zero demo figures, load user calculation if saved
  const [financialState, setFinancialState] = useState<FinancialState>(() => {
    try {
      const saved = localStorage.getItem('bbl_user_financial_state');
      if (saved) return JSON.parse(saved);
    } catch {}
    return EMPTY_FINANCIAL_STATE;
  });
  const [transactions, setTransactions] = useState<TransactionRecord[]>(INITIAL_TRANSACTIONS);
  const [approvals, setApprovals] = useState<ApprovalRequest[]>(INITIAL_APPROVALS);

  // Sync data mode
  useEffect(() => {
    if (dataMode === 'empty') {
      try {
        const saved = localStorage.getItem('bbl_user_financial_state');
        if (saved) {
          setFinancialState(JSON.parse(saved));
          return;
        }
      } catch {}
      setFinancialState(EMPTY_FINANCIAL_STATE);
      setTransactions([]);
    } else {
      setFinancialState(AUDITED_FINANCIAL_STATE);
      setTransactions(INITIAL_TRANSACTIONS);
    }
  }, [dataMode]);

  // Load preferences from localStorage on mount
  useEffect(() => {
    try {
      const savedLang = localStorage.getItem('bbl_preferred_lang') as Language | null;
      if (savedLang === 'bn' || savedLang === 'en') {
        setLang(savedLang);
      }
      const savedBranding = localStorage.getItem('bbl_branding_settings');
      if (savedBranding) {
        setBranding(JSON.parse(savedBranding));
      }
      const savedFormulas = localStorage.getItem('bbl_formula_config');
      if (savedFormulas) {
        setFormulaConfig(JSON.parse(savedFormulas));
      }
      const savedView = localStorage.getItem('bbl_active_view') as 'DASHBOARD' | 'LOGIN' | null;
      if (savedView === 'DASHBOARD' || savedView === 'LOGIN') {
        setCurrentView(savedView);
      }
    } catch {
      // storage unavailable
    }
  }, []);

  const handleToggleLang = () => {
    const nextLang: Language = lang === 'bn' ? 'en' : 'bn';
    setLang(nextLang);
    try {
      localStorage.setItem('bbl_preferred_lang', nextLang);
    } catch {
      // ignore
    }
  };

  const handleSaveBranding = (updated: BrandingSettings) => {
    setBranding(updated);
    try {
      localStorage.setItem('bbl_branding_settings', JSON.stringify(updated));
    } catch {
      // ignore
    }
    memberService.syncAllMembersFeeSettings(updated);
  };

  const handleSaveFormulaConfig = (updated: FinancialFormulaConfig) => {
    setFormulaConfig(updated);
    try {
      localStorage.setItem('bbl_formula_config', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleSwitchView = (view: 'DASHBOARD' | 'LOGIN' | 'MEMBER_PORTAL') => {
    setCurrentView(view);
    try {
      localStorage.setItem('bbl_active_view', view);
    } catch {
      // ignore
    }
  };

  const handleToggleDataMode = () => {
    setDataMode((prev) => (prev === 'empty' ? 'audited' : 'empty'));
  };

  const handleLoginAttempt = async ({ userId, password }: { userId: string; password?: string; rememberMe: boolean }) => {
    setSubmittedUserId(userId);
    let currentAdminPass = 'admin123';
    let currentAdminUser = 'admin';
    try {
      currentAdminPass = localStorage.getItem('bbl_admin_password') || 'admin123';
      currentAdminUser = localStorage.getItem('bbl_admin_userid') || 'admin';
    } catch {}

    // 1. Super Admin Authentication
    if (
      password === currentAdminPass ||
      (password === 'admin123' && (userId === 'admin' || userId === currentAdminUser)) ||
      (userId === currentAdminUser && password === currentAdminPass)
    ) {
      handleSwitchView('DASHBOARD');
      return;
    }

    // 2. Member Portal Authentication (Hashed secure lookup)
    if (password) {
      const memberAuth = await memberService.verifyMemberLogin(userId, password);
      if (memberAuth.success && memberAuth.member) {
        setLoggedMemberId(memberAuth.member.id);
        handleSwitchView('MEMBER_PORTAL');
        return;
      }
    }

    setActiveModal('backend_info');
  };

  // Approval Workflow Handlers
  const handleApproveRequest = (id: string) => {
    setApprovals((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'APPROVED' as const } : item))
    );

    const approvedItem = approvals.find((a) => a.id === id);
    if (approvedItem && approvedItem.amount) {
      // Post to transactions journal
      const newTrx: TransactionRecord = {
        id: `TRX-${Math.floor(Math.random() * 899999 + 100000)}`,
        date: new Date().toISOString().split('T')[0],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        referenceType: 'LOAN',
        referenceId: approvedItem.applicantId,
        referenceName: approvedItem.applicantName,
        transactionType: approvedItem.details,
        amount: approvedItem.amount,
        paymentMethod: 'CASH',
        debitAccount: '1001-Cash in Hand',
        creditAccount: '1201-Principal Receivable',
        approvalStatus: 'POSTED',
        approvedBy: 'সুপার এডমিন (SA-01)',
        postedBy: 'সিস্টেম অটো-পোস্টিং',
        receiptNumber: `RCP-${Math.floor(Math.random() * 899999 + 100000)}`,
        auditTrail: `Approved and posted by Super Admin for ticket ${id}`,
      };
      setTransactions((prev) => [newTrx, ...prev]);
    }
  };

  const handleRejectRequest = (id: string) => {
    setApprovals((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'REJECTED' as const } : item))
    );
  };

  const handleRevisionRequest = (id: string) => {
    setApprovals((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'REVISION_NEEDED' as const } : item))
    );
  };

  const handleSubmitTransactionRequest = (data: {
    type: string;
    targetId: string;
    amount: number;
    paymentMethod: string;
    reference: string;
    notes: string;
  }) => {
    const newApproval: ApprovalRequest = {
      id: `APP-00${Math.floor(Math.random() * 899 + 100)}`,
      type: data.type as any,
      applicantName: data.reference || 'সদস্য / পার্টনার লেনদেন',
      applicantId: data.targetId,
      amount: data.amount,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'PENDING',
      details: `${data.type} (${data.notes || 'কুইক এন্ট্রি শর্টকাট'}) [পদ্ধতি: ${data.paymentMethod}]`,
      submittedBy: 'অফিস সহকারী (কুইক এন্ট্রি)',
    };
    setApprovals((prev) => [newApproval, ...prev]);
  };

  return (
    <div className="relative min-h-screen">
      {/* Floating View Switcher Pill (Always accessible for easy testing & presentation) */}
      <div className="fixed bottom-4 right-4 z-40 print:hidden flex items-center gap-1.5 bg-slate-900/95 p-1 rounded-full shadow-2xl border border-white/20 backdrop-blur-md">
        <button
          onClick={() => handleSwitchView('DASHBOARD')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold font-bengali cursor-pointer transition-all ${
            currentView === 'DASHBOARD' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
          title={lang === 'bn' ? 'সুপার এডমিন ড্যাশবোর্ড' : 'Super Admin'}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
          <span>{lang === 'bn' ? 'এডমিন' : 'Admin'}</span>
        </button>

        <button
          onClick={() => handleSwitchView('MEMBER_PORTAL')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold font-bengali cursor-pointer transition-all ${
            currentView === 'MEMBER_PORTAL' ? 'bg-emerald-600 text-white' : 'text-slate-300 hover:text-white'
          }`}
          title={lang === 'bn' ? 'সদস্য সেলফ-সার্ভিস পোর্টাল' : 'Member Portal'}
        >
          <User className="w-3.5 h-3.5 text-emerald-300" />
          <span>{lang === 'bn' ? 'সদস্য পোর্টাল' : 'Member'}</span>
        </button>

        <button
          onClick={() => handleSwitchView('LOGIN')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold font-bengali cursor-pointer transition-all ${
            currentView === 'LOGIN' ? 'bg-slate-700 text-white' : 'text-slate-300 hover:text-white'
          }`}
          title={lang === 'bn' ? 'লগইন পেজ' : 'Login'}
        >
          <span>{lang === 'bn' ? 'লগইন' : 'Login'}</span>
        </button>
      </div>

      {/* VIEW 1: SUPER ADMIN DASHBOARD */}
      {currentView === 'DASHBOARD' && (
        <DashboardLayout
          lang={lang}
          onToggleLang={handleToggleLang}
          branding={branding}
          formulaConfig={formulaConfig}
          onSaveBranding={handleSaveBranding}
          onSaveFormulaConfig={handleSaveFormulaConfig}
          financialState={financialState}
          onUpdateFinancialState={(updated) => setFinancialState(updated)}
          transactions={transactions}
          approvals={approvals}
          dataMode={dataMode}
          onToggleDataMode={handleToggleDataMode}
          onLogout={() => handleSwitchView('LOGIN')}
          onAddTransaction={(trx) => setTransactions((prev) => [trx, ...prev])}
          onApproveRequest={handleApproveRequest}
          onRejectRequest={handleRejectRequest}
          onRevisionRequest={handleRevisionRequest}
          onSubmitTransactionRequest={handleSubmitTransactionRequest}
        />
      )}

      {/* VIEW 2: MEMBER SELF-SERVICE PORTAL */}
      {currentView === 'MEMBER_PORTAL' && (
        <MemberDashboardLayout
          memberId={loggedMemberId || (memberService.getAllMembers()[0]?.id || '')}
          lang={lang}
          onLogout={() => {
            setLoggedMemberId(null);
            handleSwitchView('LOGIN');
          }}
          somitiNameBn={branding.banglaName}
          somitiNameEn={branding.englishName}
          logoUrl={branding.logoUrl}
        />
      )}

      {/* VIEW 3: AUTHENTIC LOGIN PAGE */}
      {currentView === 'LOGIN' && (
        <div className="min-h-screen flex flex-col justify-between bg-gradient-to-b from-slate-100 via-emerald-50/20 to-slate-100 text-slate-900 font-sans selection:bg-emerald-600 selection:text-white">
          {/* Main Viewport Content — Clean Centered Login (No Pictures/Illustrations) */}
          <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-10">
            <div className="w-full max-w-lg mx-auto">
              <LoginCard
                lang={lang}
                branding={branding}
                onToggleLang={handleToggleLang}
                onOpenForgotPassword={() => setActiveModal('forgot_password')}
                onOpenRegister={() => setActiveModal('register')}
                onLoginAttempt={handleLoginAttempt}
              />
            </div>
          </main>

          {/* Dark Green Cooperative Footer */}
          <Footer lang={lang} onOpenModal={(modal) => setActiveModal(modal)} />

          {/* Interactive Modals */}
          {activeModal === 'forgot_password' && (
            <ForgotPasswordModal
              lang={lang}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'register' && (
            <RegisterModal
              lang={lang}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'calculator' && (
            <LoanCalculatorModal
              lang={lang}
              allowedInstallments={branding.allowedLoanInstallments}
              defaultMethod={branding.defaultLoanCalculationMethod}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'about' && (
            <AboutModal
              lang={lang}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'rules' && (
            <RulesModal
              lang={lang}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'contact' && (
            <ContactModal
              lang={lang}
              onClose={() => setActiveModal(null)}
            />
          )}

          {activeModal === 'backend_info' && (
            <BackendIntegrationModal
              lang={lang}
              submittedUserId={submittedUserId}
              onClose={() => setActiveModal(null)}
              onEnterDashboard={() => handleSwitchView('DASHBOARD')}
            />
          )}

          {activeModal === 'logo_settings' && (
            <LogoSettingsModal
              lang={lang}
              currentLogoUrl={branding.logoUrl}
              currentApiUrl={backendApiUrl}
              onSaveLogo={(url) => handleSaveBranding({ ...branding, logoUrl: url })}
              onSaveApiUrl={(url) => setBackendApiUrl(url)}
              onClose={() => setActiveModal(null)}
            />
          )}
        </div>
      )}
    </div>
  );
}
