export interface SheetDefinition {
  tableName: string;
  descriptionBn: string;
  descriptionEn: string;
  idPrefix: string;
  idExample: string;
  primaryKey: string;
  columns: {
    name: string;
    type: 'STRING' | 'NUMBER' | 'DATE' | 'CURRENCY' | 'ENUM' | 'BOOLEAN';
    required: boolean;
    description: string;
  }[];
  validationRules: string[];
}

export const WORKBOOK_NAME = 'BBL SOMITI – Digital Management System';

export const PROPOSED_SHEETS: SheetDefinition[] = [
  {
    tableName: 'SYSTEM_INFO',
    descriptionBn: 'সমিতি ও সিস্টেম সংস্করণ পরিচিতি',
    descriptionEn: 'Core institution metadata & system build version',
    idPrefix: 'SYS-',
    idExample: 'SYS-01',
    primaryKey: 'SYSTEM_KEY',
    columns: [
      { name: 'KEY', type: 'STRING', required: true, description: 'Config key name' },
      { name: 'VALUE', type: 'STRING', required: true, description: 'Config value' },
      { name: 'UPDATED_AT', type: 'DATE', required: true, description: 'Last modified timestamp' },
      { name: 'UPDATED_BY', type: 'STRING', required: true, description: 'Editor Admin ID' },
    ],
    validationRules: ['Keys must be unique uppercase slugs', 'Immutable by non-super-admins'],
  },
  {
    tableName: 'SETTINGS',
    descriptionBn: 'ব্র্যান্ডিং, সুদের হার ও আর্থিক নীতিমালা',
    descriptionEn: 'Branding, interest rates, admission fees and system rules',
    idPrefix: 'SET-',
    idExample: 'SET-001',
    primaryKey: 'SETTING_ID',
    columns: [
      { name: 'SETTING_ID', type: 'STRING', required: true, description: 'Setting unique identifier' },
      { name: 'CATEGORY', type: 'ENUM', required: true, description: 'BRANDING, RATES, FORMULAS, ID_PREFIX' },
      { name: 'KEY_NAME', type: 'STRING', required: true, description: 'Parameter code' },
      { name: 'CURRENT_VALUE', type: 'STRING', required: true, description: 'Active value' },
      { name: 'EFFECTIVE_DATE', type: 'DATE', required: true, description: 'Activation effective date' },
    ],
    validationRules: ['Rate changes require audit trail', 'Historic formulas stay archived'],
  },
  {
    tableName: 'MEMBERS',
    descriptionBn: 'সমিতির সকল সাধারণ ও বিশেষ সদস্য তথ্য',
    descriptionEn: 'Registered cooperative society members master register',
    idPrefix: 'BBL-',
    idExample: 'BBL-001',
    primaryKey: 'MEMBER_ID',
    columns: [
      { name: 'MEMBER_ID', type: 'STRING', required: true, description: 'Unique Member ID (e.g. BBL-001)' },
      { name: 'FULL_NAME_BN', type: 'STRING', required: true, description: 'Full Name in Bengali' },
      { name: 'FULL_NAME_EN', type: 'STRING', required: true, description: 'Full Name in English' },
      { name: 'MOBILE_NUMBER', type: 'STRING', required: true, description: '11-digit Bangladesh Mobile' },
      { name: 'NID_NUMBER', type: 'STRING', required: true, description: 'National ID number' },
      { name: 'JOINING_DATE', type: 'DATE', required: true, description: 'Cooperative admission date' },
      { name: 'ADMISSION_FEE_PAID', type: 'BOOLEAN', required: true, description: 'Admission fee status (100 BDT)' },
      { name: 'STATUS', type: 'ENUM', required: true, description: 'ACTIVE, INACTIVE, SUSPENDED' },
    ],
    validationRules: ['NID and Mobile must be unique in system', 'Cannot be deleted once transactions exist'],
  },
  {
    tableName: 'PARTNERS',
    descriptionBn: 'মূলধন প্রদানকারী সম্মানিত পার্টনার তথ্য',
    descriptionEn: 'Capital investment partners registry',
    idPrefix: 'BBL100',
    idExample: 'BBL1001',
    primaryKey: 'PARTNER_ID',
    columns: [
      { name: 'PARTNER_ID', type: 'STRING', required: true, description: 'Partner unique code' },
      { name: 'PARTNER_NAME', type: 'STRING', required: true, description: 'Partner Name' },
      { name: 'CONTACT_PHONE', type: 'STRING', required: true, description: 'Phone number' },
      { name: 'TOTAL_CAPITAL_COMMITTED', type: 'CURRENCY', required: true, description: 'Committed equity' },
      { name: 'STATUS', type: 'ENUM', required: true, description: 'ACTIVE, INACTIVE' },
    ],
    validationRules: ['Partner capital is distinct from savings liabilities'],
  },
  {
    tableName: 'LOANS',
    descriptionBn: 'বিতরণকৃত ও চলমান ঋণ হিসাব',
    descriptionEn: 'Disbursed microcredit and member loan files',
    idPrefix: 'LN-',
    idExample: 'LN-000001',
    primaryKey: 'LOAN_ID',
    columns: [
      { name: 'LOAN_ID', type: 'STRING', required: true, description: 'Unique Loan identifier' },
      { name: 'MEMBER_ID', type: 'STRING', required: true, description: 'FK to MEMBERS table' },
      { name: 'PRINCIPAL_AMOUNT', type: 'CURRENCY', required: true, description: 'Approved loan principal' },
      { name: 'PROFIT_RATE_PERCENT', type: 'NUMBER', required: true, description: 'Agreed cooperative rate' },
      { name: 'TENURE_MONTHS', type: 'NUMBER', required: true, description: 'Installment tenure' },
      { name: 'DISBURSEMENT_DATE', type: 'DATE', required: true, description: 'Fund transfer date' },
      { name: 'LOAN_STATUS', type: 'ENUM', required: true, description: 'PENDING, ACTIVE, FULLY_PAID, OVERDUE' },
    ],
    validationRules: ['Requires 2 guarantor references', 'Cannot disburse without Super Admin approval'],
  },
  {
    tableName: 'TRANSACTIONS',
    descriptionBn: 'আর্থিক লেনদেনের প্রাথমিক জার্নাল লগ',
    descriptionEn: 'Master financial transaction event records',
    idPrefix: 'TRX-',
    idExample: 'TRX-000001',
    primaryKey: 'TRANSACTION_ID',
    columns: [
      { name: 'TRANSACTION_ID', type: 'STRING', required: true, description: 'Unique Transaction reference' },
      { name: 'DATE_TIME', type: 'DATE', required: true, description: 'Transaction timestamp' },
      { name: 'REF_TYPE', type: 'ENUM', required: true, description: 'MEMBER, PARTNER, LOAN, SAVINGS, EXPENSE' },
      { name: 'REF_ID', type: 'STRING', required: true, description: 'Source ID' },
      { name: 'AMOUNT', type: 'CURRENCY', required: true, description: 'Transaction amount' },
      { name: 'DEBIT_ACCOUNT', type: 'STRING', required: true, description: 'Debit ledger account code' },
      { name: 'CREDIT_ACCOUNT', type: 'STRING', required: true, description: 'Credit ledger account code' },
      { name: 'POSTING_STATUS', type: 'ENUM', required: true, description: 'PENDING, POSTED, REVERSED' },
      { name: 'RECEIPT_NO', type: 'STRING', required: true, description: 'Receipt voucher number' },
    ],
    validationRules: ['Debits must exactly equal credits', 'No direct physical delete, reversal only'],
  },
  {
    tableName: 'LEDGER_ENTRIES',
    descriptionBn: 'খতিয়ান ও ডাবল এন্ট্রি সাধারণ লেজার',
    descriptionEn: 'Double-entry general ledger posting items',
    idPrefix: 'LED-',
    idExample: 'LED-000001',
    primaryKey: 'ENTRY_ID',
    columns: [
      { name: 'ENTRY_ID', type: 'STRING', required: true, description: 'Ledger line item ID' },
      { name: 'TRANSACTION_ID', type: 'STRING', required: true, description: 'FK to TRANSACTIONS' },
      { name: 'ACCOUNT_CODE', type: 'STRING', required: true, description: 'Chart of accounts code' },
      { name: 'DEBIT_AMOUNT', type: 'CURRENCY', required: true, description: 'Debit flow' },
      { name: 'CREDIT_AMOUNT', type: 'CURRENCY', required: true, description: 'Credit flow' },
      { name: 'BALANCE_AFTER', type: 'CURRENCY', required: true, description: 'Running account balance' },
    ],
    validationRules: ['Immutable once posted', 'Sum of debits equals sum of credits'],
  },
  {
    tableName: 'APPROVALS',
    descriptionBn: 'সুপার এডমিন অনুমোদন কেন্দ্র ট্র্যাকার',
    descriptionEn: 'Workflow request approval and authorization tracking',
    idPrefix: 'APP-',
    idExample: 'APP-00001',
    primaryKey: 'APPROVAL_ID',
    columns: [
      { name: 'APPROVAL_ID', type: 'STRING', required: true, description: 'Approval ticket ID' },
      { name: 'REQUEST_TYPE', type: 'ENUM', required: true, description: 'LOAN, WITHDRAWAL, EXPENSE, MEMBER' },
      { name: 'SUBMITTED_BY', type: 'STRING', required: true, description: 'Originating staff/user ID' },
      { name: 'STATUS', type: 'ENUM', required: true, description: 'PENDING, APPROVED, REJECTED' },
      { name: 'DECIDED_BY', type: 'STRING', required: false, description: 'Super Admin ID' },
      { name: 'DECISION_NOTES', type: 'STRING', required: false, description: 'Notes or reasoning' },
    ],
    validationRules: ['Only SUPER_ADMIN and authorized ADMIN can approve financial disbursements'],
  },
];
