import { BrandingSettings, FinancialFormulaConfig } from '../types/dashboard';

export const DEFAULT_BRANDING: BrandingSettings = {
  primaryBlue: '#0B5DB3',
  primaryGreen: '#087443',
  lightBackground: '#F4F8FC',
  darkText: '#17212B',
  englishName: 'BBL SOMITI',
  banglaName: 'বহুমুখী সমবায় সমিতি',
  tagline: 'সততা, সেবা, একতা, প্রগতি',
  establishmentDate: '01 June 2026',
  logoUrl: null, // null defaults to official crest emblem
  bannerUrl: null,
  phone: '+880 1711-000000',
  email: 'info@bblsomiti.org.bd',
  address: 'প্লট-২৪, ব্লক-বি, সমবায় ভবন রোড, ঢাকা-১২১৬, বাংলাদেশ',
  footerText: 'BBL SOMITI — একটি আধুনিক ও দায়িত্বশীল বহুমুখী সমবায় প্রতিষ্ঠান।',
  copyrightText: '© ২০২৬। সর্বস্বত্ব সংরক্ষিত।',
  admissionFeeDefault: 100, // 100 BDT default as requested
  insuranceRatePercent: 0.5,
  initialSavingsRatePercent: 5.0,
  loanProfitRatePercent: 10.0,
  allowedLoanInstallments: [11, 11.5, 12, 12.5, 13, 15, 18, 24],
  defaultLoanCalculationMethod: 'FLAT',
  memberIdPrefix: 'BBL-',
  partnerIdPrefix: 'BBL100',
  loanIdPrefix: 'LN-',
  transactionIdPrefix: 'TRX-',
  receiptIdPrefix: 'RCP-',
};

export const DEFAULT_FORMULA_CONFIG: FinancialFormulaConfig = {
  formulaAEnabled: true,
  formulaAName: 'User Formula A (বর্তমান ক্যাশ)',
  formulaBEnabled: true,
  formulaBName: 'User Formula B (টোটাল ক্যাশ)',
  ledgerReconciliationStrict: true,
  effectiveDate: '2026-06-01',
};
