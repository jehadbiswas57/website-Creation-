import { FinancialState, TransactionRecord, ApprovalRequest } from '../types/dashboard';

/**
 * Clean Zero Initial State (No Demo Money)
 * All values start at 0, ready for real calculations.
 */
export const EMPTY_FINANCIAL_STATE: FinancialState = {
  presentCash: 0,
  bankBalance: 0,
  availableCashAndBank: 0,
  totalFund: 0,
  totalInvestmentCapital: 0,
  totalPartnerDeposits: 0,
  totalMemberSavingsDeposits: 0,
  totalAdmissionFeesCollected: 0,
  totalInsuranceCollected: 0,
  otherCollections: 0,
  totalApprovedExpenses: 0,
  totalBusinessInvestment: 0,
  businessIncome: 0,
  businessExpense: 0,
  businessNetProfit: 0,
  somitiTotalIncome: 0,
  somitiTotalExpense: 0,
  somitiNetProfit: 0,

  totalLoanDisbursed: 0,
  totalLoanPrincipalRecovered: 0,
  totalLoanProfitRecovered: 0,
  totalOutstandingLoanPrincipal: 0,
  pendingLoanApplicationsCount: 0,
  approvedUndisbursedLoansCount: 0,
  activeLoansCount: 0,
  fullyPaidLoansCount: 0,
  overdueLoansCount: 0,
  overdueInstallmentsAmount: 0,
  todayLoanCollection: 0,
  thisMonthLoanCollection: 0,

  totalSavingsDeposits: 0,
  totalSavingsWithdrawals: 0,
  memberSavingsLiability: 0,
  totalDpsDeposits: 0,
  totalDpsWithdrawals: 0,
  dpsLiability: 0,
  todaySavingsCollection: 0,
  thisMonthSavingsCollection: 0,
  pendingSavingsWithdrawalsCount: 0,

  insuranceFundBalance: 0,
  activeInsuranceMembersCount: 0,
  inactiveInsuranceMembersCount: 0,
  admissionFeesPending: 0,
  otherMemberFees: 0,

  totalMembersCount: 0,
  activeMembersCount: 0,
  inactiveMembersCount: 0,
  newMemberApplicationsCount: 0,
  totalPartnersCount: 0,
  activePartnersCount: 0,
  totalPartnerCapital: 0,
  totalPartnerWithdrawals: 0,
  pendingPartnerRequestsCount: 0,
};

// Zero initial state for audited mode as well (no demo figures)
export const AUDITED_FINANCIAL_STATE: FinancialState = { ...EMPTY_FINANCIAL_STATE };

// No demo transactions - start clean
export const INITIAL_TRANSACTIONS: TransactionRecord[] = [];

// No demo approvals - start clean
export const INITIAL_APPROVALS: ApprovalRequest[] = [];

