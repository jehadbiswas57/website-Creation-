export type Role = 
  | 'SUPER_ADMIN' 
  | 'ADMIN' 
  | 'MANAGER' 
  | 'ACCOUNTANT' 
  | 'STAFF' 
  | 'MEMBER' 
  | 'PARTNER';

export type Language = 'bn' | 'en';

export type DateRange = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'all';

export type DataMode = 'empty' | 'audited';

export interface BrandingSettings {
  primaryBlue: string;
  primaryGreen: string;
  lightBackground: string;
  darkText: string;
  englishName: string;
  banglaName: string;
  tagline: string;
  establishmentDate: string;
  logoUrl: string | null;
  bannerUrl: string | null;
  phone: string;
  email: string;
  address: string;
  footerText: string;
  copyrightText: string;
  admissionFeeDefault: number;
  insuranceRatePercent: number;
  initialSavingsRatePercent: number;
  loanProfitRatePercent: number;
  allowedLoanInstallments?: number[];
  defaultLoanCalculationMethod?: 'FLAT' | 'REDUCING';
  memberIdPrefix: string;
  partnerIdPrefix: string;
  loanIdPrefix: string;
  transactionIdPrefix: string;
  receiptIdPrefix: string;
}

export interface FinancialFormulaConfig {
  formulaAEnabled: boolean;
  formulaAName: string;
  formulaBEnabled: boolean;
  formulaBName: string;
  ledgerReconciliationStrict: boolean;
  effectiveDate: string;
}

export interface FinancialState {
  // A. Core Financials
  presentCash: number;
  bankBalance: number;
  availableCashAndBank: number;
  totalFund: number;
  totalInvestmentCapital: number;
  totalPartnerDeposits: number;
  totalMemberSavingsDeposits: number;
  totalAdmissionFeesCollected: number;
  totalInsuranceCollected: number;
  otherCollections: number;
  totalApprovedExpenses: number;
  totalBusinessInvestment: number;
  businessIncome: number;
  businessExpense: number;
  businessNetProfit: number;
  somitiTotalIncome: number;
  somitiTotalExpense: number;
  somitiNetProfit: number;

  // B. Loan Management
  totalLoanDisbursed: number;
  totalLoanPrincipalRecovered: number;
  totalLoanProfitRecovered: number;
  totalOutstandingLoanPrincipal: number;
  pendingLoanApplicationsCount: number;
  approvedUndisbursedLoansCount: number;
  activeLoansCount: number;
  fullyPaidLoansCount: number;
  overdueLoansCount: number;
  overdueInstallmentsAmount: number;
  todayLoanCollection: number;
  thisMonthLoanCollection: number;

  // C. Savings & DPS
  totalSavingsDeposits: number;
  totalSavingsWithdrawals: number;
  memberSavingsLiability: number;
  totalDpsDeposits: number;
  totalDpsWithdrawals: number;
  dpsLiability: number;
  todaySavingsCollection: number;
  thisMonthSavingsCollection: number;
  pendingSavingsWithdrawalsCount: number;

  // D. Insurance & Admission
  insuranceFundBalance: number;
  activeInsuranceMembersCount: number;
  inactiveInsuranceMembersCount: number;
  admissionFeesPending: number;
  otherMemberFees: number;

  // E. Members & Partners
  totalMembersCount: number;
  activeMembersCount: number;
  inactiveMembersCount: number;
  newMemberApplicationsCount: number;
  totalPartnersCount: number;
  activePartnersCount: number;
  totalPartnerCapital: number;
  totalPartnerWithdrawals: number;
  pendingPartnerRequestsCount: number;
}

export interface TransactionRecord {
  id: string;
  date: string;
  timestamp: string;
  referenceType: 'MEMBER' | 'PARTNER' | 'LOAN' | 'SAVINGS' | 'DPS' | 'INSURANCE' | 'ADMISSION' | 'EXPENSE' | 'BUSINESS';
  referenceId: string;
  referenceName: string;
  transactionType: string;
  amount: number;
  paymentMethod: 'CASH' | 'BANK' | 'BKASH' | 'NAGAD' | 'ROCKET';
  debitAccount: string;
  creditAccount: string;
  approvalStatus: 'PENDING' | 'APPROVED' | 'POSTED' | 'REJECTED' | 'CANCELLED';
  approvedBy?: string;
  postedBy?: string;
  receiptNumber: string;
  supportingDocument?: string;
  auditTrail: string;
}

export interface ApprovalRequest {
  id: string;
  type: 'MEMBER_APPLICATION' | 'PARTNER_APPLICATION' | 'LOAN_REQUEST' | 'INSTALLMENT_PAYMENT' | 'SAVINGS_WITHDRAWAL' | 'EXPENSE_REQUEST' | 'BUSINESS_FUNDING';
  applicantName: string;
  applicantId: string;
  amount?: number;
  requestDate: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'REVISION_NEEDED';
  details: string;
  submittedBy: string;
}

export type SidebarSection = 
  | 'dashboard'
  | 'members'
  | 'partners'
  | 'loans'
  | 'savings'
  | 'dps'
  | 'insurance'
  | 'admission'
  | 'verification'
  | 'approvals'
  | 'cashbook'
  | 'chart_of_accounts'
  | 'general_ledger'
  | 'transactions'
  | 'income_expense'
  | 'business'
  | 'partner_capital'
  | 'member_deposit'
  | 'reports'
  | 'documents'
  | 'notices'
  | 'users'
  | 'audit_log'
  | 'settings'
  | 'help'
  | 'sheets_schema';
