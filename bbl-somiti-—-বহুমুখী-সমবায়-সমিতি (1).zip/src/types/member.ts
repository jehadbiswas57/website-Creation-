export type MemberStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'ADMISSION_PENDING' | 'ARCHIVED';

export type AccountLoginStatus = 'ACTIVE' | 'INACTIVE' | 'LOCKED' | 'PASSWORD_RESET_REQUIRED';

export type FeePaymentStatus = 'PAID' | 'PARTIAL' | 'PENDING' | 'DUE' | 'WAIVED';

export type LoanStatus = 
  | 'DRAFT'
  | 'SUBMITTED'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'REJECTED'
  | 'READY_FOR_DISBURSEMENT'
  | 'ACTIVE'
  | 'COMPLETED'
  | 'OVERDUE'
  | 'CANCELLED';

export type PaymentMethod = 'CASH' | 'BKASH' | 'NAGAD' | 'ROCKET' | 'BANK';

export type PaymentRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export type ProfileUpdateRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface MemberDocument {
  id: string;
  type: 
    | 'MEMBER_PHOTO'
    | 'MEMBER_NID_FRONT'
    | 'MEMBER_NID_BACK'
    | 'MEMBER_AGREEMENT'
    | 'NOMINEE_PHOTO'
    | 'NOMINEE_NID_FRONT'
    | 'NOMINEE_NID_BACK'
    | 'GUARANTOR_PHOTO'
    | 'GUARANTOR_NID_FRONT'
    | 'GUARANTOR_NID_BACK'
    | 'LOAN_DOC'
    | 'OTHER';
  category: 'MEMBER' | 'NOMINEE' | 'GUARANTOR' | 'LOAN';
  title: string;
  fileUrl: string;
  uploadedAt: string;
  uploadedBy: string;
  fileSize?: string;
}

export interface NomineeInfo {
  name: string;
  relation: string;
  mobile: string;
  nid: string;
  address?: string;
  sharePercent: number;
  photoUrl?: string;
  nidFrontUrl?: string;
  nidBackUrl?: string;
  documentUrl?: string;
}

export interface GuarantorInfo {
  name: string;
  relation: string;
  mobile: string;
  nid: string;
  address?: string;
  occupation?: string;
  memberId?: string; // If guarantor is an existing BBL SOMITI member
  photoUrl?: string;
  nidFrontUrl?: string;
  nidBackUrl?: string;
  documentUrl?: string;
}

export interface MemberRecord {
  id: string; // Member ID, e.g. BBL-001
  userId?: string; // Unique Login User ID, e.g. mem_001
  hasLoginAccount: boolean;
  loginStatus?: AccountLoginStatus;
  passwordHash?: string; // SHA-256 hash (never stored or sent in plaintext)
  forcePasswordChange?: boolean;
  
  // Personal Info
  fullNameBn: string;
  fullNameEn: string;
  fatherOrHusbandName: string;
  motherName: string;
  dateOfBirth: string;
  mobileNumber: string;
  nidNumber: string;
  address: string;
  occupation: string;
  photoUrl?: string; // Member profile photo (automatically synced from admission upload)
  nidFrontUrl?: string;
  nidBackUrl?: string;
  agreementDocUrl?: string;
  admissionDate: string;
  status: MemberStatus;

  // Requested Initial Loan during admission
  requestedInitialLoanAmount?: number;

  // Admission & Initial Fees
  admissionFeeRequired: number; // default e.g. 100
  admissionFeePaid: number;
  admissionFeeStatus: FeePaymentStatus;
  admissionReceiptRef?: string;
  admissionFeeWaived?: boolean;

  insuranceFeeRequired: number;
  insuranceFeePaid: number;
  insuranceStatus: FeePaymentStatus;
  insuranceReceiptRef?: string;
  insuranceFeeWaived?: boolean;

  initialSavingsRequired: number;
  initialSavingsPaid: number;
  initialSavingsStatus: FeePaymentStatus;
  initialSavingsReceiptRef?: string;
  initialSavingsWaived?: boolean;

  // Nominee & Guarantor
  nominee?: NomineeInfo;
  guarantor?: GuarantorInfo;

  // Documents
  documents: MemberDocument[];

  // Loan Snapshot (derived or current active loan)
  activeLoanId?: string;
  totalLoansTakenCount: number;
  totalLoanDisbursedAmount: number;
  totalLoanPrincipalPaid: number;
  totalLoanProfitPaid: number;
  currentLoanOutstanding: number;
  nextInstallmentDate?: string;
  nextInstallmentAmount?: number;

  // Savings Snapshot
  totalSavingsDeposits: number;
  totalSavingsWithdrawals: number;
  currentSavingsBalance: number;

  createdAt: string;
  updatedAt: string;
}

export interface LoanScheduleInstallment {
  installmentNumber: number;
  label?: string; // e.g. "১ম কিস্তি", "শেষ কিস্তি (অর্ধেক কিস্তি)"
  dueDate: string;
  isFractional?: boolean;
  fractionWeight?: number; // 1 for full, 0.5 for half
  principalAmount: number;
  profitAmount: number;
  totalAmount: number;
  paidAmount: number;
  paidDate?: string;
  status: 'PENDING' | 'PAID' | 'OVERDUE' | 'PARTIAL';
}

export interface MemberLoan {
  id: string; // Loan ID, e.g. LN-000001
  memberId: string;
  memberName: string;
  requestedAmount: number;
  approvedAmount: number;
  tenureMonths: number;
  installmentCount: number; // e.g. 11, 11.5, 12, 12.5, 13, 15, 18, 24
  calculationMethod: 'FLAT' | 'REDUCING';
  profitRatePercent: number; // e.g. 10%
  totalProfitAmount: number;
  totalPayableAmount: number; // Principal + Profit
  monthlyInstallmentAmount: number; // regular installment amount
  regularInstallmentAmount?: number;
  lastInstallmentAmount?: number; // adjusted / fractional last installment
  totalInstallments: number; // count of installment payments
  installmentsPaidCount: number;
  firstInstallmentDate?: string;
  schedule?: LoanScheduleInstallment[];
  
  disbursementDate?: string;
  loanStatus: LoanStatus;
  purpose: string;
  
  // Member Consent
  memberConsentStatus?: 'PENDING' | 'CONSENTED' | 'REJECTED';
  memberConsentDate?: string;
  memberConsentNote?: string;
  memberConsentGivenBy?: string;

  // Super Admin Final Approval & Disbursement
  finalApprovedBy?: string;
  finalApprovalDate?: string;
  disbursedBy?: string;
  disbursementMethod?: PaymentMethod;
  disbursementRef?: string;

  totalPrincipalRepaid: number;
  totalProfitRepaid: number;
  outstandingPrincipal: number;
  outstandingTotal: number;
  
  nextInstallmentDueDate?: string;
  supportingDocuments?: string[];
  approvedBy?: string;
  approvalDate?: string;
  rejectionReason?: string;
}

export interface PaymentRequest {
  id: string; // e.g. REQ-PAY-001
  idempotencyKey: string; // Client-generated unique UUID to prevent double-submit
  memberId: string;
  memberName: string;
  memberUserId?: string;
  loanId?: string;
  type: 'LOAN_INSTALLMENT' | 'SAVINGS_DEPOSIT' | 'ADMISSION_FEE' | 'INSURANCE_FEE';
  installmentNumber?: number;
  dueAmount: number;
  requestedAmount: number;
  paymentMethod: PaymentMethod;
  transactionReference?: string; // Optional for bKash/Nagad/Rocket/Bank, not required for Cash
  paymentEvidenceUrl?: string; // Image/document of receipt/slip
  submittedDate: string;
  submittedTime: string;
  status: PaymentRequestStatus;
  
  // Review & Approval details
  adminReviewNote?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  postedTransactionId?: string;
  generatedReceiptNumber?: string;
}

export interface ProfileUpdateRequest {
  id: string; // e.g. REQ-PRF-001
  memberId: string;
  memberName: string;
  requestType: 'PHOTO' | 'NID' | 'CONTACT_INFO' | 'NOMINEE' | 'GUARANTOR' | 'DOCUMENT';
  oldValue: string;
  proposedValue: string;
  supportingDocumentUrl?: string;
  requestDate: string;
  status: ProfileUpdateRequestStatus;
  adminReviewNote?: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface OfficialReceipt {
  receiptNumber: string; // e.g. RCP-000123
  transactionId: string; // e.g. TRX-000456
  memberId: string;
  memberName: string;
  memberMobile?: string;
  type: 'LOAN_INSTALLMENT' | 'SAVINGS_DEPOSIT' | 'ADMISSION_FEE' | 'INSURANCE_FEE';
  loanId?: string;
  installmentNumber?: number;
  amount: number;
  paymentMethod: PaymentMethod;
  paymentDate: string;
  paymentTime: string;
  transactionReference?: string;
  receivedBy: string;
  postedStatus: 'POSTED' | 'REVERSED';
  detailsNote: string;
  principalComponent?: number;
  profitComponent?: number;
}
