import { Language } from '../types/dashboard';

const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function toBengaliDigits(num: number | string): string {
  return String(num).replace(/\d/g, (d) => BN_DIGITS[parseInt(d, 10)]);
}

export function formatCurrency(amount: number, lang: Language = 'bn'): string {
  const safeAmount = isNaN(amount) ? 0 : amount;
  const formattedEn = safeAmount.toLocaleString('en-US');
  
  if (lang === 'bn') {
    return `৳ ${toBengaliDigits(formattedEn)}`;
  }
  return `BDT ${formattedEn}`;
}

export function formatNumber(num: number, lang: Language = 'bn'): string {
  const safeNum = isNaN(num) ? 0 : num;
  const formattedEn = safeNum.toLocaleString('en-US');
  return lang === 'bn' ? toBengaliDigits(formattedEn) : formattedEn;
}
