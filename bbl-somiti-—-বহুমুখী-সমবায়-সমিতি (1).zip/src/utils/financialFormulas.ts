import { FinancialState } from '../types/dashboard';

export interface FormulaCalculationResult {
  formulaAValue: number;
  formulaBValue: number;
  ledgerCashValue: number;
  formulaAVsLedgerDiff: number;
  formulaBVsLedgerDiff: number;
  reconciliationItems: {
    labelBn: string;
    labelEn: string;
    amount: number;
    impact: 'INCREASE' | 'DECREASE' | 'NEUTRAL';
    noteBn: string;
    noteEn: string;
  }[];
}

/**
 * Calculates User Formula A, Formula B and System Verified Ledger Cash
 * 
 * Formula A:
 * বর্তমান ক্যাশ = মোট বিনিয়োগ মূলধন − মোট ঋণ বিতরণ + মোট ঋণ আদায় + মোট সঞ্চয় আদায় − মোট সঞ্চয় উত্তোলন + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায়
 * 
 * Formula B:
 * টোটাল ক্যাশ = মোট বিনিয়োগ মূলধন + মোট সঞ্চয় আদায় + মোট ইনস্যুরেন্স আদায় + মোট ভর্তি ফি আদায় − মোট সঞ্চয় উত্তোলন − মোট খরচ
 */
export function calculateFinancialFormulas(state: FinancialState): FormulaCalculationResult {
  // 1. User Formula A
  // Note: মোট ঋণ আদায় = (ঋণ মূলধন আদায় + ঋণের মুনাফা আদায়)
  const totalLoanRecovery = state.totalLoanPrincipalRecovered + state.totalLoanProfitRecovered;
  
  const formulaAValue = 
    state.totalInvestmentCapital 
    - state.totalLoanDisbursed 
    + totalLoanRecovery 
    + state.totalSavingsDeposits 
    - state.totalSavingsWithdrawals 
    + state.totalInsuranceCollected 
    + state.totalAdmissionFeesCollected;

  // 2. User Formula B
  const formulaBValue =
    state.totalInvestmentCapital
    + state.totalSavingsDeposits
    + state.totalInsuranceCollected
    + state.totalAdmissionFeesCollected
    - state.totalSavingsWithdrawals
    - state.totalApprovedExpenses;

  // 3. System Verified Ledger Cash & Bank
  // In a double-entry ledger, Cash & Bank Asset accounts equal Present Cash + Bank Balance
  const ledgerCashValue = state.presentCash + state.bankBalance;

  // 4. Reconciliation Bridge
  const formulaAVsLedgerDiff = formulaAValue - ledgerCashValue;
  const formulaBVsLedgerDiff = formulaBValue - ledgerCashValue;

  const reconciliationItems = [
    {
      labelBn: 'মোট অনুমোদিত পরিচালন খরচ',
      labelEn: 'Total Approved Operating Expenses',
      amount: state.totalApprovedExpenses,
      impact: 'DECREASE' as const,
      noteBn: 'Formula A-তে সাধারণ খরচ বিয়োগ করা হয়নি; লেজারে খরচ অনুমোদিত হয়ে ক্যাশ থেকে বিয়োগ হয়েছে।',
      noteEn: 'Operating expenses are accounted in the ledger upon approval but not deducted in Formula A.',
    },
    {
      labelBn: 'ঋণের মুনাফা আদায় (আলাদা শ্রেণিকরণ)',
      labelEn: 'Loan Profit Recovery (Separated)',
      amount: state.totalLoanProfitRecovered,
      impact: 'INCREASE' as const,
      noteBn: 'ঋণ মূলধন ও মুনাফা আদায় ব্যাংকিং নীতিতে পৃথক রাখা হয়েছে।',
      noteEn: 'Cooperative banking standards separate loan principal recovery from earned profit.',
    },
    {
      labelBn: 'মোট ব্যবসায়িক প্রকল্প বিনিয়োগ',
      labelEn: 'Total Business Project Investment',
      amount: state.totalBusinessInvestment,
      impact: 'DECREASE' as const,
      noteBn: 'ব্যবসার বিনিয়োগ ক্যাশ আউটফ্লো হিসেবে সংরক্ষিত, সাধারণ খরচ নয়।',
      noteEn: 'Direct business enterprise funding is an asset allocation, not an operational expense.',
    },
    {
      labelBn: 'অন্যান্য সদস্য ফি ও বিবিধ আয়',
      labelEn: 'Other Miscellaneous Collections',
      amount: state.otherCollections,
      impact: 'INCREASE' as const,
      noteBn: 'ভর্তি ফি ও ইনস্যুরেন্স বাদে অন্যান্য সমবায় ফি।',
      noteEn: 'Miscellaneous fees received outside base admission and insurance funds.',
    },
  ];

  return {
    formulaAValue,
    formulaBValue,
    ledgerCashValue,
    formulaAVsLedgerDiff,
    formulaBVsLedgerDiff,
    reconciliationItems,
  };
}
