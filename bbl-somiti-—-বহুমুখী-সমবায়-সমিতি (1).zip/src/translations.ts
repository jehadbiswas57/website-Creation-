import { Language } from './types';

export const translations = {
  bn: {
    // Branding
    orgName: 'BBL SOMITI',
    orgType: 'বহুমুখী সমবায় সমিতি লিঃ',
    slogan: 'সততা · সেবা · একতা · প্রগতি',
    establishedDate: '০১ জুন ২০২৬',
    establishedLabel: 'প্রতিষ্ঠা:',
    nationwideLabel: 'সারা দেশে সমবায় ব্যাংকিং সেবা',
    empoweringMotto: 'সঞ্চয়ে সমৃদ্ধি, সমবায়ে অগ্রগতি',
    trustMarker: 'বাংলাদেশ সমবায় অধিদপ্তর কর্তৃক নিবন্ধিত',
    
    // Login Card
    welcomeTitle: 'লগইন করুন',
    welcomeSub: 'বিবিএল বহুমুখী সমবায় সমিতি',
    welcomeDesc: 'আপনার অ্যাকাউন্টে প্রবেশ করতে নিচের তথ্য দিন।',
    
    // Form fields
    userIdLabel: 'ইউজার আইডি অথবা মোবাইল নম্বর',
    userIdPlaceholder: 'আপনার আইডি বা মোবাইল নম্বর লিখুন',
    passwordLabel: 'গোপন পাসওয়ার্ড',
    passwordPlaceholder: 'আপনার পাসওয়ার্ড লিখুন',
    
    // Form options
    rememberMe: 'আইডি মনে রাখুন',
    forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?',
    loginBtn: 'লগইন করুন',
    loggingIn: 'যাচাই করা হচ্ছে...',
    orDivider: 'অথবা',
    createAccountBtn: 'নতুন অ্যাকাউন্ট খুলুন',
    
    // Security box
    securityTitle: 'নিরাপদ সমবায় সেবা',
    securityDesc: 'আপনার অ্যাকাউন্টের তথ্য ও প্রতিটি লেনদেন সুরক্ষিত এবং সম্পূর্ণ গোপনীয়।',
    
    // Validation
    errorEmptyUserId: 'অনুগ্রহ করে ইউজার আইডি বা মোবাইল নম্বর দিন।',
    errorEmptyPassword: 'অনুগ্রহ করে পাসওয়ার্ড প্রদান করুন।',
    errorInvalidLength: 'আইডি বা মোবাইল নম্বর কমপক্ষে ৫ অক্ষরের হতে হবে।',
    
    // Footer
    footerAbout: 'আমাদের পরিচিতি',
    footerRules: 'নীতিমালা ও নিয়মাবলী',
    footerCalculator: 'ঋণের কিস্তি হিসাব',
    footerContact: 'যোগাযোগ ও সহায়তা',
    copyright: '© ২০২৬ বিবিএল বহুমুখী সমবায় সমিতি লিঃ। সর্বস্বত্ব সংরক্ষিত।',
    
    // Logo settings
    settingsBtn: 'সেটিংস',
    changeLogo: 'লোগো পরিবর্তন',

    // Modals
    close: 'বন্ধ করুন',
    submit: 'দাখিল করুন',
    cancel: 'বাতিল',
  },
  en: {
    // Branding
    orgName: 'BBL SOMITI',
    orgType: 'Multipurpose Cooperative Society Ltd.',
    slogan: 'Honesty, Service, Unity, Progress',
    establishedDate: '01 June 2026',
    establishedLabel: 'Established:',
    nationwideLabel: 'Across All Bangladesh',
    empoweringMotto: 'Building a Prosperous Future Together',
    trustMarker: 'Govt. Registered Cooperative Society',
    
    // Login Card
    welcomeTitle: 'Welcome',
    welcomeSub: 'Login to BBL SOMITI Web Portal',
    welcomeDesc: 'Enter your credentials below to access your account.',
    
    // Form fields
    userIdLabel: 'Mobile Number / User ID',
    userIdPlaceholder: 'Enter mobile number or User ID',
    passwordLabel: 'Password',
    passwordPlaceholder: 'Enter your password',
    
    // Form options
    rememberMe: 'Remember me',
    forgotPassword: 'Forgot password?',
    loginBtn: 'Log In',
    loggingIn: 'Authenticating...',
    orDivider: 'OR',
    createAccountBtn: 'Create New Account',
    
    // Security box
    securityTitle: 'Secure & Reliable',
    securityDesc: 'Your data is protected with 256-bit bank-grade encryption',
    
    // Validation
    errorEmptyUserId: 'Please enter your mobile number or User ID.',
    errorEmptyPassword: 'Please enter your password.',
    errorInvalidLength: 'User ID or mobile must be at least 5 characters.',
    
    // Footer
    footerAbout: 'About Us',
    footerRules: 'Rules & Terms',
    footerCalculator: 'Loan Calculator',
    footerContact: 'Contact',
    copyright: '© 2026. All rights reserved.',
    
    // Logo settings
    settingsBtn: 'Logo & Settings',
    changeLogo: 'Change Logo',

    // Modals
    close: 'Close',
    submit: 'Submit',
    cancel: 'Cancel',
  }
} as const;

export function getT(lang: Language) {
  return translations[lang];
}
